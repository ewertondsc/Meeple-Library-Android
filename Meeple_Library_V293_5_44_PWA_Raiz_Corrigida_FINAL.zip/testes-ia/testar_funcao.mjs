// Testes offline do backend REAL da Meeple IA: Cloudflare Worker.
// Não depende de rede, Groq, Tavily ou secrets.
import assert from 'node:assert/strict';
import fs from 'node:fs';
import path from 'node:path';
import vm from 'node:vm';
import {fileURLToPath} from 'node:url';
const here=path.dirname(fileURLToPath(import.meta.url));
const source=fs.readFileSync(path.resolve(here,'../pesquisa-externa/worker.js'),'utf8');
assert.match(source,/export\s+default\s*\{/,'Worker deve expor o handler padrão do Cloudflare');
const sandbox={URL,Request,Response,Headers,console,TextEncoder,TextDecoder,Uint8Array,ArrayBuffer,AbortController, setTimeout, clearTimeout};
vm.createContext(sandbox);
vm.runInContext(source.replace(/export\s+default\s*\{/,'globalThis.__worker = {')+'\n;',sandbox,{filename:'worker.js'});
const worker=sandbox.__worker;
assert.equal(typeof worker.fetch,'function','handler fetch deve existir');
let passed=0,failed=0;
async function test(name,fn){try{await fn();passed++;console.log('✓ '+name)}catch(e){failed++;console.error('✗ '+name+' — '+e.message)}}
const req=(method='GET',body)=>new Request('https://meeple-ai.test/'+(method==='POST'?'ask':''),{method,...(body===undefined?{}:{headers:{'content-type':'application/json'},body})});
await test('Worker exporta handler compatível com Cloudflare',async()=>assert.equal(typeof worker.fetch,'function'));
await test('OPTIONS responde 204 com CORS',async()=>{const r=await worker.fetch(req('OPTIONS'),{});assert.equal(r.status,204);assert.equal(r.headers.get('access-control-allow-origin'),'*')});
await test('GET informa serviço, versão e provedor',async()=>{const r=await worker.fetch(req('GET'),{}),d=await r.json();assert.equal(r.status,200);assert.equal(d.service,'Meeple AI');assert.equal(d.version,'5.9.0');assert.equal(d.provider,'Groq');assert.equal(d.searchProvider,'Tavily')});
await test('método não permitido retorna 405',async()=>{const r=await worker.fetch(req('PUT'),{});assert.equal(r.status,405)});
await test('POST sem secret Groq retorna erro explícito',async()=>{const r=await worker.fetch(req('POST','{}'),{TAVILY_API_KEY:'teste'}),d=await r.json();assert.equal(r.status,500);assert.match(d.error,/GROQ_API_KEY/)});
await test('POST sem secret Tavily retorna erro explícito',async()=>{const r=await worker.fetch(req('POST','{}'),{GROQ_API_KEY:'teste'}),d=await r.json();assert.equal(r.status,500);assert.match(d.error,/TAVILY_API_KEY/)});
await test('JSON inválido retorna 400',async()=>{const r=await worker.fetch(req('POST','{quebrado'),{GROQ_API_KEY:'x',TAVILY_API_KEY:'y'});assert.equal(r.status,400)});
await test('POST sem jogo/pergunta retorna 400',async()=>{const r=await worker.fetch(req('POST',JSON.stringify({game:'',query:'pergunta'})),{GROQ_API_KEY:'x',TAVILY_API_KEY:'y'});assert.equal(r.status,400)});
await test('Worker aplica CORS e no-store às respostas JSON',async()=>{const r=await worker.fetch(req('GET'),{});assert.equal(r.headers.get('access-control-allow-origin'),'*');assert.equal(r.headers.get('cache-control'),'no-store')});
await test('evidência local é limitada a oito trechos e validada por jogo',async()=>{assert.match(source,/body\.localEvidence\.slice\(0,\s*8\)/);assert.match(source,/normalizeText\(itemGame\) !== normalizeText\(game\)/);assert.match(source,/content\.length < 40/)});
await test('URL de evidência local externa é bloqueada',async()=>{assert.match(source,/function safeManualUrl/);assert.match(source,/u\.origin !== "https:\/\/meeple-library\.local"/)});
await test('Worker mantém separação entre pergunta e evidência local',async()=>{assert.match(source,/localEvidence = Array\.isArray\(body\.localEvidence\)/);assert.match(source,/searchTavily\(game, query/)});
console.log(`\n${passed} passaram, ${failed} falharam.`);
if(failed)process.exit(1);
