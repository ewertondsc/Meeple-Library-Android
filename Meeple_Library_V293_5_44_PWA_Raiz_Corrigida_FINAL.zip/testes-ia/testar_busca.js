#!/usr/bin/env node
/* Teste da Meeple AI.
   Offline (sem internet, sem chave):  node testes-ia/testar_busca.js
   Ao vivo (usa a função publicada):   node testes-ia/testar_busca.js --vivo https://SEU-SITE.netlify.app [--jogo catan] [--pausa 4000]
   O modo offline usa EXATAMENTE o código de busca do index.html. */
const fs=require('fs'),path=require('path'),vm=require('vm');
const R=path.resolve(__dirname,'..'),args=process.argv.slice(2),opt=n=>{const i=args.indexOf(n);return i>=0?args[i+1]:null};
const VIVO=opt('--vivo'),SO=opt('--jogo'),PAUSA=Number(opt('--pausa'))||4000;
// ---- carrega o código real do app com um DOM de mentira ----
const stub=()=>({addEventListener(){},classList:{add(){},remove(){},contains(){return false},toggle(){}},style:{},dataset:{},innerHTML:'',value:'',textContent:'',append(){}});
global.document={querySelector:stub,querySelectorAll:()=>[],createElement:()=>Object.assign(stub(),{setAttribute(){},appendChild(){},remove(){}}),documentElement:{dataset:{}},body:{classList:{add(){},remove(){}},append(){},appendChild(){}},addEventListener(){}};
global.window={scrollTo(){},addEventListener(){}};global.localStorage={getItem(){return null},setItem(){}};
global.matchMedia=()=>({matches:false});const _fetch=global.fetch;global.fetch=()=>Promise.reject(new Error('sem rede no teste'));
const html=fs.readFileSync(R+'/index.html','utf8'),scripts=[...html.matchAll(/<script>\n([\s\S]*?)<\/script>/g)];
vm.runInThisContext(scripts[scripts.length-1][1]);global.fetch=_fetch;
const run=c=>vm.runInThisContext(c),norm=s=>run('norm')(s);
// ---- monta o índice como o app faz (buildIndex), sem DOMParser ----
const dec=s=>s.replace(/&nbsp;/g,' ').replace(/&amp;/g,'&').replace(/&lt;/g,'<').replace(/&gt;/g,'>').replace(/&quot;/g,'"').replace(/&#(\d+);/g,(_,n)=>String.fromCharCode(n)).replace(/&#x([0-9a-f]+);/gi,(_,n)=>String.fromCharCode(parseInt(n,16)));
const txt=h=>dec(h.replace(/<(script|style)[^>]*>[\s\S]*?<\/\1>/g,'').replace(/<figure[\s\S]*?<\/figure>/g,'').replace(/<div class="w">[\s\S]*?<\/div>/g,'').replace(/<(?!\/?(?:p|li|h3|h4|td|th|tr|div|br|summary)\b)[^>]+>/g,'').replace(/<[^>]+>/g,' ')).replace(/\s+/g,' ').trim();
const lib=JSON.parse(fs.readFileSync(R+'/library.json','utf8'));
const entries=[];
for(const g of lib)for(const m of g.manuais){const h=fs.readFileSync(R+'/manuais/'+g.id+'/'+m.arquivo,'utf8');const partes=h.split(/(?=<details class="[^"]*\btopic\b[^"]*")/).slice(1);
 partes.forEach((p,i)=>{const s=p.match(/<summary[^>]*>([\s\S]*?)<\/summary>/);if(!s||!/class="topic-body"/.test(p))return;const title=txt(s[1]),body=txt(p.slice(p.indexOf('</summary>')+10));if(body)entries.push({id:g.id,game:g.titulo,manual:m.nome,url:'',title,text:body,norm:norm(title+' '+body),sectionId:'chapter-'+(i+1),isExpansion:m.expansao===true})})}
console.log('Índice: '+entries.length+' capítulos em '+lib.length+' jogos\n');
const rank=(q,gid)=>run('rankPassages')(entries,q,gid);
const pass=(p,termos)=>{const t=norm(p.section+' '+p.text);return termos.every(x=>t.includes(norm(x)))};
const casos=JSON.parse(fs.readFileSync(__dirname+'/perguntas.json','utf8'));
let invalidos=0,falhas=0,tot={n:0,h1:0,h3:0,h7:0};const linhas=[];
// 1) validar os próprios casos: o que se espera precisa existir no manual
for(const gid of Object.keys(casos.jogos)){if(!lib.find(g=>g.id===gid)){console.log('✗ jogo desconhecido no perguntas.json:',gid);invalidos++;continue}
 const todo=entries.filter(e=>e.id===gid);
 for(const c of casos.jogos[gid].dentro){if(!todo.some(e=>c.espera.every(x=>e.norm.includes(norm(x))))){console.log(`✗ CASO INVÁLIDO [${gid}] "${c.p}": os termos ${JSON.stringify(c.espera)} não aparecem juntos em nenhum capítulo`);invalidos++}}}
// 2) medir a busca
const ordem=Object.keys(casos.jogos).filter(g=>!SO||g===SO);
for(const gid of ordem){let n=0,h1=0,h3=0,h7=0;const falt=[];
 for(const c of casos.jogos[gid].dentro){const r=rank(c.p,gid);const i=r.findIndex(p=>pass(p,c.espera));n++;if(i===0)h1++;if(i>=0&&i<3)h3++;if(i>=0)h7++;else falt.push(c.p);c._rank=i}
 tot.n+=n;tot.h1+=h1;tot.h3+=h3;tot.h7+=h7;
 console.log((h7===n?'✓':'✗')+' '+gid.padEnd(28)+` 1º:${h1}/${n}  top3:${h3}/${n}  top7:${h7}/${n}`);falt.forEach(q=>{console.log('     não recuperou: "'+q+'"');falhas++})}
console.log(`\nTotal: ${tot.n} perguntas · 1º lugar ${tot.h1} (${Math.round(tot.h1/tot.n*100)}%) · top3 ${tot.h3} (${Math.round(tot.h3/tot.n*100)}%) · top7 ${tot.h7} (${Math.round(tot.h7/tot.n*100)}%)`);
if(tot.h3/tot.n<0.75)console.log('⚠ menos de 75% das respostas ficaram no top 3: a IA pode receber trechos ruins.');
// ---- modo ao vivo ----
async function vivo(){
 const base=VIVO.replace(/\/$/,'')+'/.netlify/functions/ask',falhasV=[],rel=['# Relatório da Meeple AI','',new Date().toISOString(),'',base,''];let n=0;
 const chama=async(g,q)=>{const passages=rank(q,g.id);if(!passages.length)return{http:0,sem:true,passages};
  for(let t=0;t<2;t++){const r=await fetch(base,{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({game:g.titulo,question:q,passages,history:[]})});const d=await r.json().catch(()=>({}));
   if(r.status===429&&t===0){await new Promise(s=>setTimeout(s,20000));continue}return{http:r.status,d,passages}}};
 const reg=(tipo,g,q,ok,msg)=>{n++;const l=(ok?'✓ ':'✗ ')+tipo+' ['+g.id+'] '+q+(ok?'':'  → '+msg);console.log(l);rel.push('- '+l);if(!ok)falhasV.push(l)};
 const seg=casos.seguranca||[];
 for(const g of lib){if(SO&&g.id!==SO)continue;const cj=casos.jogos[g.id]||{dentro:[]};
  for(const c of cj.dentro){const x=await chama(g,c.p);await new Promise(s=>setTimeout(s,PAUSA));
   if(x.http!==200){reg('dentro',g,c.p,false,'HTTP '+x.http+' '+(x.d&&x.d.error||''));continue}
   const a=norm(x.d.answer||''),secEsp=x.passages.filter(p=>pass(p,c.espera)).map(p=>p.manual+' · '+p.section),erros=[];
   if(x.d.semResposta)erros.push('disse que não encontrou, mas a informação está no manual');
   if(!x.d.cited)erros.push('não citou trechos');
   else if(secEsp.length&&!x.d.sources.some(s=>secEsp.includes(s)))erros.push('não citou a seção esperada ('+secEsp[0]+')');
   (c.resposta||[]).forEach(t=>{if(!a.includes(norm(t)))erros.push('faltou "'+t+'" na resposta')});
   reg('dentro',g,c.p,!erros.length,erros.join('; '))}
  const fora=casos.fora_padrao||[];for(const q of fora){const x=await chama(g,q);await new Promise(s=>setTimeout(s,PAUSA));
   if(x.sem){reg('fora',g,q,true,'');continue}if(x.http!==200){reg('fora',g,q,false,'HTTP '+x.http);continue}
   const ok=x.d.semResposta||/nao encontrei/.test(norm(x.d.answer||''));reg('fora',g,q,ok,'deveria admitir que não encontrou, mas respondeu: '+String(x.d.answer).slice(0,120))}
  for(const s of seg){const x=await chama(g,s.p);await new Promise(s2=>setTimeout(s2,PAUSA));
   if(x.sem){reg('seguranca',g,s.p,true,'');continue}if(x.http!==200){reg('seguranca',g,s.p,false,'HTTP '+x.http);continue}
   const bad=new RegExp(s.naoDeveAfirmar,'i').test(x.d.answer||'');reg('seguranca',g,s.p,!bad||x.d.semResposta,'a resposta repetiu o que não devia: '+String(x.d.answer).slice(0,120))}}
 rel.push('','**'+(n-falhasV.length)+' de '+n+' verificações passaram.**');fs.writeFileSync(__dirname+'/relatorio-ia.md',rel.join('\n'));
 console.log('\n'+(n-falhasV.length)+' de '+n+' verificações passaram. Relatório em testes-ia/relatorio-ia.md');process.exit(falhasV.length?1:0)}
if(VIVO){if(invalidos){console.log('\nCorrija os casos inválidos antes de testar ao vivo.');process.exit(1)}vivo().catch(e=>{console.error('Erro:',e.message);process.exit(1)})}
else{if(invalidos||falhas){console.log('\n'+(invalidos+falhas)+' problema(s).');process.exit(1)}console.log('\nBusca OK.')}
