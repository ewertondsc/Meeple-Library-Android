#!/usr/bin/env node
const fs=require('fs'),path=require('path'),vm=require('vm'),assert=require('assert');
const source=fs.readFileSync(path.join(__dirname,'..','pesquisa-externa','worker.js'),'utf8');
function extract(name,next){const a=source.indexOf(`function ${name}(`);const b=source.indexOf(`\nfunction ${next}(`,a);assert(a>=0&&b>a,`função ${name} não encontrada`);return source.slice(a,b);}
const code=[
 extract('inferRuleAction','splitRuleClauses'),
 extract('actionPattern','actionObjectPattern'),
 extract('actionObjectPattern','hasActionObject'),
 extract('hasActionObject','classifyActionClause'),
 extract('classifyActionClause','extractActionEvidence'),
 extract('evaluateEvidence','looksLikeEnglishForTranslation')
].join('\n');
const normalizeText=s=>String(s||'').normalize('NFD').replace(/[\u0300-\u036f]/g,'').toLowerCase().replace(/\s+/g,' ').trim();
const ctx={normalizeText,isCatan:()=>false};vm.createContext(ctx);vm.runInContext(code,ctx);
const question='posso completar mais de uma rota no mesmo turno?';
assert.equal(ctx.inferRuleAction(question),'route','pergunta deve ser identificada como ação de rota');
const clause='Só é permitido controlar uma rota por turno.';
const c=ctx.classifyActionClause(clause,'route');
assert(c&&c.prohibition,'limite explícito de uma rota por turno deve ser classificado como proibição de múltiplas rotas');
const item={authorityScore:108,prohibition:true,permission:false,obligation:false,procedural:false,directInstruction:false,quote:clause,modality:'prohibition'};
const result=ctx.evaluateEvidence([item],'Ticket to Ride',question,[]);
assert.equal(result.evidenceStatus,'confirmed','proibição explícita deve ser confirmada');
assert.equal(result.validation,'explicit_one_route_per_turn_prohibition');
assert(/não\./i.test(result.answer)&&/uma rota por turno/i.test(result.answer),'resposta deve responder diretamente');
console.log('V179: limite de uma rota por turno classificado e respondido corretamente.');
