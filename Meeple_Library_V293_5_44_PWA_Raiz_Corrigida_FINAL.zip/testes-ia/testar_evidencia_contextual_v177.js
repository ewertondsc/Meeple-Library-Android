#!/usr/bin/env node
const fs=require('fs'),vm=require('vm'),path=require('path');
const html=fs.readFileSync(path.resolve(__dirname,'../index.html'),'utf8');
const start=html.indexOf('function selectContextualEvidence('),end=html.indexOf('\nfunction findLocalManualEvidence',start);
if(start<0||end<0)throw new Error('Seletor contextual não encontrado');
const ctx={};vm.createContext(ctx);vm.runInContext(html.slice(start,end)+';this.select=selectContextualEvidence;',ctx);
let failures=0;
function test(name,fn){try{if(!fn())throw new Error('condição não atendida');console.log('✓ '+name)}catch(e){failures++;console.log('✗ '+name+' — '+e.message)}}
const base=[
 {game:'Azul',manual:'Manual base',section:'Preparação',sectionId:'setup',url:'azul.html',score:4,isExpansion:false},
 {game:'Azul',manual:'Manual base',section:'Preparação duplicada',sectionId:'setup',url:'azul.html',score:3,isExpansion:false},
 {game:'Azul',manual:'Manual base',section:'Turno',sectionId:'turn',url:'azul.html',score:2,isExpansion:false},
 {game:'Azul',manual:'Azul Pavilhão de Verão',section:'Módulo',sectionId:'module',url:'summer.html',score:5,isExpansion:true}
];
test('remove duplicatas da mesma seção',()=>ctx.select(base,'azul','Como funciona a preparação?').filter(x=>x.sectionId==='setup').length===1);
test('não inclui expansão sem solicitação explícita',()=>ctx.select(base,'azul','Como funciona a preparação?').every(x=>!x.isExpansion));
test('permite expansão quando a pergunta a solicita',()=>ctx.select(base,'azul','Na expansão Pavilhão de Verão, como funciona?').some(x=>x.isExpansion));
test('limita o contexto ao máximo solicitado',()=>ctx.select(base,'azul','regras',2).length<=2);
test('mantém os trechos em ordem de relevância',()=>{const x=ctx.select(base,'azul','regras',4);return x.every((p,i)=>i===0||x[i-1].score>=p.score)});
test('não mistura identificadores de outro jogo',()=>ctx.select([{id:'catan',manual:'Catan',section:'x',score:9}], 'azul','regras').length===0);
console.log(`\n${6-failures}/6 verificações passaram.`);process.exit(failures?1:0);
