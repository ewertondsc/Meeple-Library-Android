#!/usr/bin/env node
// Testes offline da Meeple Knowledge Base: indexação local e critério de fallback.
const fs=require('fs'),path=require('path'),vm=require('vm'),assert=require('assert');
const R=path.resolve(__dirname,'..');
const stub=()=>({addEventListener(){},classList:{add(){},remove(){},contains(){return false},toggle(){}},style:{},dataset:{},innerHTML:'',value:'',textContent:'',append(){}});
global.document={querySelector:stub,querySelectorAll:()=>[],createElement:()=>Object.assign(stub(),{setAttribute(){}}),documentElement:{dataset:{}},body:{classList:{add(){},remove(){},append(){},appendChild(){}},append(){},appendChild(){}},addEventListener(){}};
global.window={scrollTo(){},addEventListener(){},history:{state:null,replaceState(state){this.state=state},pushState(state){this.state=state},back(){}},location:{href:'http://localhost/'}};global.history={replaceState(){},pushState(){},back(){}};global.localStorage={getItem(){return null},setItem(){}};global.matchMedia=()=>({matches:false});
const html=fs.readFileSync(path.join(R,'index.html'),'utf8'),scripts=[...html.matchAll(/<script>\n([\s\S]*?)<\/script>/g)];
vm.runInThisContext(scripts[scripts.length-1][1]);
const normFn=vm.runInThisContext('norm');
const dec=s=>s.replace(/&nbsp;/g,' ').replace(/&amp;/g,'&').replace(/&lt;/g,'<').replace(/&gt;/g,'>').replace(/&quot;/g,'"').replace(/&#(\d+);/g,(_,n)=>String.fromCharCode(n)).replace(/&#x([0-9a-f]+);/gi,(_,n)=>String.fromCharCode(parseInt(n,16)));
const txt=h=>dec(h.replace(/<(script|style)[^>]*>[\s\S]*?<\/\1>/g,'').replace(/<figure[\s\S]*?<\/figure>/g,'').replace(/<div class="w">[\s\S]*?<\/div>/g,'').replace(/<(?!\/?(?:p|li|h3|h4|td|th|tr|div|br|summary)\b)[^>]+>/g,'').replace(/<[^>]+>/g,' ')).replace(/\s+/g,' ').trim();
const lib=JSON.parse(fs.readFileSync(path.join(R,'library.json'),'utf8')),entries=[];vm.runInThisContext('library = '+JSON.stringify(lib));
for(const g of lib)for(const m of g.manuais){const file=path.join(R,'manuais',g.id,m.arquivo);if(!fs.existsSync(file))continue;const h=fs.readFileSync(file,'utf8'),parts=h.split(/(?=<details class="[^"]*\btopic\b[^\"]*")/).slice(1);parts.forEach((part,i)=>{const sm=part.match(/<summary[^>]*>([\s\S]*?)<\/summary>/);if(!sm||!/class="topic-body"/.test(part))return;const title=txt((sm[1].match(/<span[^>]*>([\s\S]*?)<\/span>/)||[])[1]||sm[1]),body=txt(part.slice(part.indexOf('</summary>')+10));if(body)entries.push({id:g.id,game:g.titulo,manual:m.nome,url:'manuais/'+g.id+'/'+m.arquivo,title,text:body,norm:normFn(title+' '+body),sectionId:'chapter-'+(i+1),isExpansion:/expans|1912|5-6|rio|abade/i.test(m.nome+' '+m.arquivo)});});}
const find=vm.runInThisContext('findLocalManualEvidence');
const cases=[
 ['Catan','catan','Como ganhar no Catan?'],
 ['Catan 7','catan','Quando sai 7 nos dados no Catan?'],
 ['Azul','azul','Como funciona a pontuação no Azul?'],
 ['Ticket Europa','ticket-to-ride-europa','Como pontuar no Ticket to Ride Europa?']
];
for(const [label,gid,q] of cases){const hits=find(q,gid,entries);assert(hits.length>0,`${label}: deveria recuperar trechos locais para ${q}`);console.log(`OK ${label}: ${hits.length} trecho(s), melhor seção: ${hits[0].section}`);}
const unknown=find('Qual a previsão do tempo para amanhã em Recife?', 'catan', entries);assert.strictEqual(unknown.length,0,'Pergunta fora do manual deve seguir para pesquisa externa');
assert(html.includes("requestMeepleExplorer(fullQuestion,{id:scope,title:chosenGame.titulo},expertResult||{status:'not_found',hits:[]},expertHistory)"),'fallback externo deve usar o Worker dedicado do Meeple Explorer');
const sw=fs.readFileSync(path.join(R,'sw.js'),'utf8');assert(/var BUILD='(v\d+-[^']+|[0-9a-f]{10})'/.test(sw),'cache do service worker deve usar o identificador versionado ou hash de build');
const scoreHits=find('Como pontuar no Azul?','azul',entries);
assert(scoreHits.some(p=>/pontua|ponto|fim do jogo/i.test(p.section+' '+p.text)),'Azul: a busca de pontuação deve recuperar a seção de pontuação');
const scoreAnswer=vm.runInThisContext('makeLocalAnswer')('Como pontuar no Azul?','azul',entries,'');
assert(/pontua|ponto|azulejo|fileira/i.test(scoreAnswer),'Azul: resposta local deve trazer conteúdo de pontuação');
const worker=fs.readFileSync(path.join(R,'pesquisa-externa','worker.js'),'utf8');
assert(worker.includes('extractGeneralManualEvidence'),'Worker deve validar perguntas gerais com evidência literal do manual');
assert(worker.includes('direct_local_manual_excerpts'),'Worker deve aceitar trechos literais para perguntas sem modalidade normativa');
assert(html.includes("data.evidenceStatus==='not_found' && localHits.length"),'app deve recuperar a resposta local quando o Worker não validar evidência do modelo');
assert(html.includes('renderManualKnowledgeAnswer(localAnswer,localHits,chosenGame.titulo)'),'fallback deve exibir as referências locais');
console.log(`\nMeeple Knowledge Base OK: ${entries.length} capítulos indexáveis em ${lib.length} jogos; fallback externo preservado.`);
