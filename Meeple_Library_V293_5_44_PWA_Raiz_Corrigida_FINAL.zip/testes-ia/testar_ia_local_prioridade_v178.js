#!/usr/bin/env node
const fs=require('fs'),path=require('path'),assert=require('assert');
const root=path.resolve(__dirname,'..');
const html=fs.readFileSync(path.join(root,'index.html'),'utf8');
const worker=fs.readFileSync(path.join(root,'pesquisa-externa','worker.js'),'utf8');
const sw=fs.readFileSync(path.join(root,'sw.js'),'utf8');
const checks=[];const t=(n,f)=>{f();checks.push(n);console.log('✓ '+n)};
t('front-end seleciona até oito trechos locais',()=>assert.match(html,/function selectContextualEvidence\(hits,gameId,question,max=8\)/));
t('consulta envia até oito evidências locais',()=>assert.ok(html.includes('const localEvidence=(localHits||[]).slice(0,8)')));
t('trechos locais enviados comportam 1800 caracteres',()=>assert.match(html,/slice\(0,1800\)/));
t('Worker aceita até oito trechos locais',()=>assert.match(worker,/body\.localEvidence\.slice\(0, 8\)/));
t('manual local tem prioridade e Tavily só entra como fallback',()=>assert.match(worker,/if \(!localActionEvidence\)\s*\{\s*try \{\s*const search = await searchTavily/));
t('fallback de tradução preserva resposta em português',()=>assert.match(worker,/const safeAnswer = answerIsEnglish[\s\S]*payload\.answer/));
t('fallback não apresenta citação inglesa como traduzida',()=>assert.match(worker,/quoteIsEnglish \? "A fonte foi localizada, mas a tradução deste trecho não foi validada\."/));
t('cache V182 preserva cache de imagens V172',()=>{assert.match(sw,/var BUILD='v182-game-profile'/);assert.match(sw,/var IMG='v172-persistencia'/)});
console.log(`\nV181: ${checks.length}/${checks.length} verificações aprovadas.`);
