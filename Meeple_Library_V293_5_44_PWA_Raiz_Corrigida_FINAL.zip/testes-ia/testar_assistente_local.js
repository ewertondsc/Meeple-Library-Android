#!/usr/bin/env node
const fs=require('fs'),vm=require('vm'),path=require('path');
const html=fs.readFileSync(path.resolve(__dirname,'../index.html'),'utf8');
const norm=s=>(s||'').normalize('NFD').replace(/[\u0300-\u036f]/g,'').toLowerCase();
const start=html.indexOf('function normalizeAssistantInput(value){');
const smallStart=html.indexOf('function smallTalkAnswer(question){');
const smallEnd=html.indexOf('\nfunction makeLocalAnswer',smallStart);
if(start<0||smallStart<0||smallEnd<0)throw Error('Funções do assistente não encontradas');
const helpers=html.slice(start,smallStart),fn=html.slice(smallStart,smallEnd);
const ctx={norm};vm.createContext(ctx);vm.runInContext(helpers+';'+fn+';this.normalize=normalizeAssistantInput;this.reply=smallTalkAnswer;',ctx);
const cases={
 'Bom dia, Meeple!':['Bom dia','☀️'],'Boa tarde':['Boa tarde','😄'],'Boa noite':['Boa noite','🌙'],
 'Oi':['Opa!','Meeple'],'Tudo bem?':['Tudo ótimo','jogos'],'Quem é você?':['Meeple','manuais'],
 'O que você faz?':['encontrar jogos','comparar títulos'],'Qual é seu nome?':['Meu nome é Meeple'],
 'Vc joga?':['não consigo sentar à mesa','acompanhar'],'Que jogos vc gosta?':['não tenho um jogo favorito','estratégia'],
 'Obrigado!':['Tamo junto','Boa partida'],'Tchau':['Até mais','👋'],'Me conta uma piada':['guarda-chuva','dado']
};
let fail=0;
for(const [q,needles] of Object.entries(cases)){const a=ctx.reply(q)||'';const ok=needles.every(x=>a.toLowerCase().includes(x.toLowerCase()));console.log((ok?'✓ ':'✗ ')+q+(ok?'':' → '+a));if(!ok)fail++}
const slang=ctx.normalize('vc tbm sabe oq é pontuacoa?'),slangOK=slang.includes('voce')&&slang.includes('tambem')&&slang.includes('pontuacao');
console.log((slangOK?'✓ ':'✗ ')+'abreviações e erros comuns são normalizados');if(!slangOK)fail++;
const a=html.indexOf('function makeAIQuickPrompts()'),b=html.indexOf('\nfunction renderAI',a),block=html.slice(a,b);
const promptOK=['Controle de área','Cooperativos','Mais rejogáveis','Interação direta','Mecânicas'].every(x=>block.includes(x));
console.log((promptOK?'✓ ':'✗ ')+'repertório de perguntas rápidas ampliado');if(!promptOK)fail++;
const formOK=html.includes("$('#aiForm').addEventListener('click',e=>{")&&html.includes("if(field.value.trim())$('#aiForm').requestSubmit();");
console.log((formOK?'✓ ':'✗ ')+'atalhos enviam o formulário');if(!formOK)fail++;
console.log(`\n${Object.keys(cases).length+3-fail}/${Object.keys(cases).length+3} verificações passaram.`);process.exit(fail?1:0);
