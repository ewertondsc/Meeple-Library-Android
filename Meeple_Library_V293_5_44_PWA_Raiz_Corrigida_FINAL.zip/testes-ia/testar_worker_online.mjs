// Smoke test online sem consumir cota Groq/Tavily: GET público do Worker.
import assert from 'node:assert/strict';
const endpoint=(process.argv[2]||'https://meeple-expert-public-search.ewertonscosta.workers.dev').replace(/\/$/,'');
const r=await fetch(endpoint,{headers:{'Accept':'application/json'}});
assert.equal(r.status,200,`HTTP ${r.status}`);
const d=await r.json();
assert.equal(d.service,'Meeple AI');
assert.ok(d.version,'versão do Worker ausente');
assert.equal(d.provider,'Groq');
assert.equal(d.searchProvider,'Tavily');
console.log(`Worker online: Meeple AI ${d.version}; Groq ${d.groqKeyConfigured?'configurado':'sem secret'}; Tavily ${d.tavilyKeyConfigured?'configurado':'sem secret'}.`);
