// Versão anterior do shell: v293-5-15-meeple-ai-scroll-refine-20261117.
// V293.5.17: histórico no canto superior direito e Novo chat refinado; fluxo contínuo preservado.
var BUILD='v293-5-44-pwa-root-20261117';var IMG='v288-core-images-20261114';var C='manuais-'+BUILD,I='imagens-'+IMG;
function ehImagem(u){try{return /\/manuais\/.+\.(jpe?g|png|webp|gif|svg|avif)$/i.test(new URL(u).pathname)}catch(e){return false}}
self.addEventListener('install',function(e){e.waitUntil(fetch('files.json').then(function(r){return r.json()}).then(function(l){return caches.open(I).then(function(){return caches.open(C)}).then(function(c){return c.addAll(Array.isArray(l)?l:l.core)})}).then(function(){return self.skipWaiting()}))});
self.addEventListener('activate',function(e){e.waitUntil(caches.keys().then(function(k){return Promise.all(k.filter(function(n){return n!==C&&n!==I&&!/^meeple-modules(?:-|$)/.test(n)&&!/^meeple-module(?:-|$)/.test(n)}).map(function(n){return caches.delete(n)}))}).then(function(){return self.clients.claim()}))});
self.addEventListener('message',function(e){if(e.data&&e.data.type==='MEEPLE_CLAIM_CLIENTS')self.clients.claim()});
self.addEventListener('fetch',function(e){
 if(e.request.method!=='GET')return;
 e.respondWith((async function(){
  // Dados estruturais da biblioteca usam rede primeiro para evitar conteúdo antigo após atualização.
  var requestUrl=new URL(e.request.url);
  var pathname=requestUrl.pathname;
  // A raiz do PWA deve permanecer em /; entrega o shell index.html do cache
  // sem redirecionar o navegador para /index.html.
  if(e.request.mode==='navigate' && (pathname==='/' || pathname==='')){
   var rootShell=await caches.open(C).then(function(c){return c.match(new URL('index.html',self.location.origin).href)});
   if(rootShell)return rootShell;
   try{
    var rootNetwork=await fetch(e.request);
    if(rootNetwork&&rootNetwork.ok)return rootNetwork;
   }catch(rootErr){}
   var rootFallback=await caches.open(C).then(function(c){return c.match(new URL('index.html',self.location.origin).href)});
   if(rootFallback)return rootFallback;
  }
  if(pathname.endsWith('/library.json')||pathname.endsWith('/files.json')){
   try{var fresh=await fetch(e.request,{cache:'no-store'});if(fresh&&fresh.ok){var dataCopy=fresh.clone();caches.open(C).then(function(c){return c.put(e.request,dataCopy)}).catch(function(){});return fresh}}catch(err){}
   var dataCached=await caches.open(C).then(function(c){return c.match(e.request,{ignoreSearch:true})});if(dataCached)return dataCached;
  }
  // Módulos instalados têm prioridade sobre a rede e o cache principal.
  var moduleCache=await caches.open('meeple-modules-v1');
  var moduleResponse=await moduleCache.match(e.request,{ignoreSearch:true});
  if(moduleResponse)return moduleResponse;
  var cached=await caches.match(e.request,{ignoreSearch:true});
  if(cached)return cached;
  try{
   var response=await fetch(e.request);
   if(response&&response.status===200&&response.type==='basic'){
    var copy=response.clone();caches.open(ehImagem(e.request.url)?I:C).then(function(c){return c.put(e.request,copy)}).catch(function(){});
   }
   return response;
  }catch(err){
   if(e.request.mode==='navigate'){var offline=await caches.match('offline.html');if(offline)return offline}
   throw err;
  }
 })());
});
