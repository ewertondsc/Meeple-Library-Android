MODELO DE MÓDULO — V288

O módulo não deve trazer uma página HTML pronta nem CSS/JavaScript de apresentação.

Arquivos esperados:
- game.json: identidade do jogo, ficha, metadados e lista de manuais.
- manual.json: texto e estrutura semântica do manual (schema meeple-manual-v1).
- cover.jpg: capa do jogo.
- assets/: imagens/diagramas usados no conteúdo.

O layout, navegação, busca, capítulos, tipografia, cores e responsividade são gerados pelo Meeple Library.
Consulte MODELO_MODULO/manual.json para os tipos de bloco suportados: paragraph, heading, image, list, callout, faq, card e group.

A ficha de dados pode incluir ludopediaNota, ludopediaAvaliacoes, ludopediaUrl, bggId, bggNota, bggAvaliacoes, bggUrl, anoLancamento, jogadoresMin/Max, duracaoMin/Max, idade, editoraBrasil, designers, artistas, categorias, mecanicas, temas, metadataSources e metadataUpdatedAt.


PADRÃO DE CONTEÚDO V288
- O campo game.json > descricao é obrigatório: ele alimenta o texto editorial logo abaixo dos dados do jogo.
- O campo game.json > mesa.resumo e mesa.secoes deve ser preenchido. As mesmas seções alimentam o Meeple Guia (passo a passo) e o Modo Mesa (consulta durante a partida).
- Inclua fichaRapida.objetivo, fichaRapida.dicas e fichaRapida.erros quando houver conteúdo verificável.
- Não inclua HTML/CSS/JS de apresentação: o aplicativo monta o layout. O módulo entrega somente conteúdo, metadados e mídia.
