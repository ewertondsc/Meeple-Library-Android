#!/bin/sh
# Validação completa da base V293; testes que exigem jogos pré-instalados são omitidos na base limpa.
cd "$(dirname "$0")" || exit 1
set -eu
python3 build.py --verificar
node testes/testar_cache.js
node testes/testar_assistente_local.js
node testes/testar_prompt_sintese.js
node testes/testar_pwa_indice.js
node testes/testar_regras_salvas_manual.js
node testes/testar_importacao_modular_v266.js
node testes/testar_leitor_universal_v267.js
node testes/testar_referencia_modulos_v285.js
node testes/testar_modulo_estruturado_v286.js
node testes/testar_conteudo_modulo_v287.js
node testes/testar_v288_premium_mobile.js
node testes/testar_v288_1_consolidacao.js
node testes/testar_v289_inteligencia.js
node testes/testar_v291_gerenciador_modulos.js
node testes/testar_v292_ia_contextual.js
node testes/testar_leitor_manual_v292_2.js
node testes/testar_v293_premium.js
node testes/testar_v293_2_premium_home.js
node testes/testar_v293_2_3_estante_refinada.js
node testes/testar_v293_3_ficha_jogo.js
node testes/testar_v293_5_ficha_horizontal.js
node testes/testar_v293_5_13_meeple_ai_gemini_style.js
node testes/testar_v293_5_14_meeple_ai_novo_chat.js
node testes/testar_v293_5_15_chat_refinado.js
node testes/testar_v293_5_16_chat_flow.js
node testes/testar_v293_5_17_header_controls.js
node testes/testar_v293_5_18_meeple_explorer.js
node testes/testar_v293_5_38_prioridade_jogo_selecionado.js
node testes/testar_v293_5_14_meeple_expert_catalogo.js
python3 testes/testar_leitor_manual_v292_2.py
node testes/testar_importador_reference_matched_v286_1.js
node testes/testar_leitor_universal_v285.js
node testes/testar_metadata_v285.js
node testes-ia/testar_funcao.mjs
node testes-ia/testar_metadata_worker_v283.mjs
node testes-ia/testar_worker_evidencia_geral.js
if [ "$(node -e "process.stdout.write(String(require('./library.json').length))")" -gt 0 ]; then
  node testes/testar_diagramas.js
  node testes/testar_busca_sinonimos_v97_2.js
  node testes/testar_links_externos_v282.js
  node testes/testar_link_ludopedia_v279.js
  node testes/testar_ludopedia_handler_v281.js
  node testes/testar_ludopedia_visao_geral.js
  node testes-ia/testar_busca.js
  node testes-ia/testar_knowledge_base.js
else
  echo "
Testes de conteúdo específico de jogos ignorados: a base está intencionalmente sem módulos."
fi
echo "
Validação V293 concluída."
