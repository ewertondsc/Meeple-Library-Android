const fs=require('fs');const s=fs.readFileSync('index.html','utf8');const sw=fs.readFileSync('sw.js','utf8');
const vm=require('vm');
const checks=[
 ['module manager retained in V293',s.includes("V293.5.18 · Meeple Explorer integrado ao chat.")],
 ['update ZIP action',s.includes('data-update-module=')],
 ['version comparison and downgrade confirmation',s.includes('moduleUpdateVersionCompare(incomingVersion,installedVersion)')&&s.includes('inferior à versão instalada')],
 ['same-version repair confirmation',s.includes('reinstalar para reparar')],
 ['transactional install option',s.includes('async function installGameModule(file,options={})')&&s.includes('options.replaceExisting')],
 ['same module ID enforced',s.includes('options.expectedId!==game.id')],
 ['rollback previous record',s.includes('await moduleDBPut(previousModule).catch(()=>{})')],
 ['preserve previous files',s.includes('previousAssets=new Map()')],
 ['missing-file filter',s.includes('value="atencao"')],
 ['duplicate filter',s.includes('value="duplicados"')],
 ['duplicate detection by title and IDs',s.includes('function findPotentialModuleDuplicates(mods)')&&s.includes("keys.push('bgg:'+bgg)")&&s.includes("keys.push('ludo:'+ludo)")],
 ['no automatic duplicate removal',s.includes('nada será excluído automaticamente')],
 ['storage audit visible',s.includes('em arquivos de módulos')],
 ['search across metadata',s.includes('g.editora,g.editoraBrasil,...(g.categorias||[])')],
 ['browser storage estimate clearly scoped',s.includes('Uso geral do site:')&&s.includes('inclui módulos, cache e outros dados locais')],
 ['ZIP entries are read only once during update',s.includes('entries:packageEntries')&&s.includes('options.entries||normalizeModuleFiles')],
 ['service worker cache version',sw.includes("v293-5-18-meeple-explorer-integration-20261117")],
 ['existing module export retained',s.includes('data-export-module=')],
 ['existing remove action retained',s.includes('data-remove-module=')],
 ['remote server tab retained as optional',s.includes('pane-server')&&s.includes('Catálogo remoto (opcional)')],
 ['local installed tab is the default',s.includes("let moduleManagerActiveTab='installed'")],
 ['manual ZIP import retained',s.includes('moduleZipInput')]
];let fail=0;for(const [name,ok] of checks){console.log((ok?'PASS ':'FAIL ')+name);if(!ok)fail++}if(fail)process.exit(1);
const start=s.indexOf('function findPotentialModuleDuplicates(mods){');
const end=s.indexOf('\nfunction renderModuleManager()',start);
if(start<0||end<0)throw new Error('duplicate helpers not found');
const context={moduleNorm:v=>String(v||'').normalize('NFD').replace(/[\u0300-\u036f]/g,'').toLowerCase().replace(/[^a-z0-9]+/g,' ').trim(),metadataBggId:g=>g.bggId||null,metadataLudoId:g=>g.ludoId||null};
vm.createContext(context);vm.runInContext(s.slice(start,end),context);
const groups=context.findPotentialModuleDuplicates([
 {id:'one',game:{titulo:'Azul',bggId:230802}},
 {id:'two',game:{titulo:'AZUL',bggId:230802}},
 {id:'three',game:{titulo:'Dewan',bggId:390221}},
 {id:'four',game:{titulo:'Outro nome',bggId:390221}},
 {id:'five',game:{titulo:'Survive the Island',bggId:999999}}
]);
if(groups.length!==2||groups.some(g=>g.length!==2))throw new Error('duplicate grouping does not respect title/IDs');
const cmp=context.moduleUpdateVersionCompare;
if(cmp('1.2.0','1.1.9')!==1||cmp('1.0.0','1.0.0')!==0||cmp('0.9','1.0')!==-1||cmp('beta','1.0')!==null)throw new Error('version comparator failed');
console.log('PASS runtime duplicate grouping and version comparisons');

console.log(`\nV291: ${checks.length} verificações específicas aprovadas.`);
