// V293.5.22 — regressão de conversa informal
const fs = require('fs');
const html=fs.readFileSync('index.html','utf8');
const expert=fs.readFileSync('meeple-expert/js/meeple-engine.js','utf8');
for(const token of ['tudo joia','como vai voce','smallTalkAnswer(question)','V293.5.22 · Conversa informal ampliada.'])
  if(!html.includes(token)) throw new Error('Chat sem regra esperada: '+token);
for(const token of ['tudo joia','td joia','como vai voce'])
  if(!expert.includes(token)) throw new Error('Expert sem regra esperada: '+token);
console.log('OK: saudações informais reconhecidas no Chat e no Expert');
