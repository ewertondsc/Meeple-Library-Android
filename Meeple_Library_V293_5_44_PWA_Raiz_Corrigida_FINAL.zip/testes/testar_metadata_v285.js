const fs=require('fs'),assert=require('assert');
const app=fs.readFileSync('index.html','utf8'),sw=fs.readFileSync('sw.js','utf8');
const checks=[
 ['cadastro central persistente por dispositivo',app.includes("MODULE_REFERENCE_STORAGE_KEY='meepleModuleReferenceDataV285'")&&app.includes('localStorage.setItem(MODULE_REFERENCE_STORAGE_KEY,JSON.stringify(stored))')],
 ['cadastro inclui notas e URLs da Ludopedia e BGG',app.includes('ludopediaNota')&&app.includes('bggNota')&&app.includes('bggUrl')],
 ['base da biblioteca alimenta o cadastro central',app.includes('for(const game of data||[])upsertModuleReferenceFromGame(game)')],
 ['dados novos dos módulos alimentam futuras instalações',app.includes('upsertModuleReferenceFromGame(game)')&&app.includes('moduleReferenceCandidates(game)')],
 ['módulos são enriquecidos antes da gravação',app.includes('let referenceMatched=false;')&&app.includes('referenceMatched=Object.keys(moduleReferenceFallback(game)).length>0;game=normalizeModuleGame(game);upsertModuleReferenceFromGame(game);const record=')],
 ['campos vazios do ZIP são completados pela referência',app.includes('function normalizeModuleGame(game)')&&app.includes('moduleReferenceFallback(source)')],
 ['dados existentes da referência não são sobrescritos por valores vazios',app.includes('moduleReferenceMergeEntry(existing,incoming)')&&app.includes('if(moduleReferenceHasValue(value))refreshed[field]=value')],
 ['cadastro central pode ser reaplicado manualmente e localmente',app.includes('async function syncInstalledReferenceData')&&app.includes('syncInstalledReferenceData()')],
 ['instalação não depende de chamadas externas, Worker ou Cloudflare',app.includes('não aguarda APIs, Worker ou Cloudflare')&&app.includes('MEEPLE_METADATA_ENDPOINT=null')],
 ['BGG público continua opcional e sem token',app.includes('boardgamegeek.com/xmlapi2/search')&&!app.includes('BGG_API_TOKEN')],
 ['Ludopedia pública é identificada como busca, sem fingir API',app.includes('public_search_only')&&app.includes('ludopedia.com.br/busca?search=')],
 ['atualização semanal continua disponível',app.includes('MEEPLE_METADATA_INTERVAL=7*24*60*60*1000')&&app.includes("document.addEventListener('visibilitychange'")],
 ['cache do Service Worker avança para V289',sw.includes('v293-5-18-meeple-explorer-integration-20261117')],
 ['versão exibida no app é V293',app.includes('V293.5.18 · Meeple Explorer integrado ao chat.')]
];
let failed=0;for(const [name,ok] of checks){console.log((ok?'✓ ':'✗ ')+name);if(!ok)failed++}if(failed)process.exit(1);console.log(`\nMetadados V286: ${checks.length} verificações aprovadas.`);
