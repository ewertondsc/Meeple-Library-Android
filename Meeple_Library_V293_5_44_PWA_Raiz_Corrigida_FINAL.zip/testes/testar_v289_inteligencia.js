const fs=require('fs'),vm=require('vm');
const path=require('path');
const root=path.resolve(__dirname,'..');
const html=fs.readFileSync(path.join(root,'index.html'),'utf8');
const sw=fs.readFileSync(path.join(root,'sw.js'),'utf8');
const assert=(ok,msg)=>{if(!ok)throw new Error(msg)};
const checks=[];
function check(name,fn){try{fn();checks.push('✓ '+name)}catch(e){checks.push('✗ '+name+': '+e.message)}}
check('campo dedicado de busca da biblioteca',()=>assert(html.includes('id="collectionSearch"'),'Busca ausente'));
check('ordenação da biblioteca',()=>assert(html.includes('id="collectionSort"')&&['title','year','favorites','players','duration','complexity'].every(k=>html.includes(`value="${k}"`)),'Opções incompletas'));
check('pipeline combinado de filtros',()=>assert(html.includes('function applyCollectionTools(list)')&&html.includes('applyFilters(list).filter(collectionMatchesSearch)'),'Busca não combina com filtros existentes'));
check('busca cobre título e metadados',()=>assert(/g\.titulo,g\.editora[\s\S]*g\.designer/.test(html)&&html.includes('q.mecanicas'),'Escopo de metadados incompleto'));
check('busca e ordenação não usam API externa',()=>assert(!/fetch\([^)]*(collectionSearch|collectionSort)/.test(html),'Busca local não deve chamar rede'));
check('preferência de ordenação fica salva',()=>assert(html.includes("save('meepleCollectionSort',collectionSort)"),'Persistência local ausente'));
check('limpeza combinada de busca e filtros',()=>assert(html.includes('data-clear-all-collection')&&html.includes('data-clearcollection'),'Ações de limpeza ausentes'));
check('Meeple Insights expandido',()=>assert(['Jogos por categoria','Complexidade','Quantidade de jogadores','Duração cadastrada','Cobertura das informações'].every(t=>html.includes(t)),'Indicadores ausentes'));
check('dados não informados não são estimados',()=>assert(html.includes('Campos ausentes não são estimados.'),'Aviso de transparência ausente'));
check('cache versionado do Service Worker V293.5.13' ,()=>assert(sw.includes('v293-5-18-meeple-explorer-integration-20261117'),'Cache não versionado'));
check('versão de produto V293.5.13',()=>assert(html.includes('V293.5.18 · Meeple Explorer integrado ao chat.'),'Rodapé não atualizado'));
check('comparador avançado com atalhos',()=>assert(html.includes('data-compare-swap')&&html.includes('data-compare-random'),'Atalhos ausentes'));
check('comparação de mecânicas comuns e exclusivas',()=>assert(html.includes('Mecânicas compartilhadas')&&html.includes('compareTokens')&&html.includes('compare-differences'),'Análise de mecânicas ausente'));
check('comparação de editora, designers e ano',()=>assert(['publisher','designers','year','weight'].every(k=>html.includes(`case '${k}'`)),'Campos editoriais ausentes'));
check('comparador não estima dados faltantes',()=>assert(html.includes('não é uma avaliação negativa')&&html.includes('Não informado'),'Aviso de transparência ausente'));
check('interface responsiva do comparador',()=>assert(html.includes('v290-compare-mobile')&&html.includes('.compare-insight-grid{grid-template-columns:1fr}'),'Regras mobile ausentes'));

// Execute the real search and sorting functions from the app in an isolated context.
const start=html.indexOf('function collectionSearchText(g){');
const end=html.indexOf('\nfunction renderCollectionResults(){',start);
assert(start>=0&&end>start,'Não foi possível localizar as funções reais da busca');
const block=html.slice(start,end);
const normalize=s=>String(s||'').normalize('NFD').replace(/[\u0300-\u036f]/g,'').toLowerCase();
const games=[
 {id:'survive',titulo:'Survive the Island',editora:'Galápagos Jogos',designer:'Julien Prothière',ano:2023,categorias:['Aventura'],jogadoresMin:2,jogadoresMax:5,duracaoMin:45,duracaoMax:60,complexidadeNivel:2,fichaRapida:{mecanicas:['Movimento em grade']}},
 {id:'azul',titulo:'Azul',editora:'Next Move',designer:'Michael Kiesling',ano:2017,categorias:['Abstrato'],jogadoresMin:2,jogadoresMax:4,duracaoMin:30,duracaoMax:45,complexidadeNivel:2,fichaRapida:{mecanicas:['Construção de padrões']}},
 {id:'ticket',titulo:'Ticket to Ride Europe',editora:'Galápagos Jogos',designer:'Alan R. Moon',ano:2005,categorias:['Rotas'],jogadoresMin:2,jogadoresMax:5,duracaoMin:60,duracaoMax:90,complexidadeNivel:2,fichaRapida:{mecanicas:['Construção de rotas']}}
];
const ctx={norm:normalize,collectionQuery:'galapagos island',collectionSort:'title',applyFilters:x=>x,parseJog:g=>({min:g.jogadoresMin||0,max:g.jogadoresMax||0}),parseDur:g=>Number.isFinite(g.duracaoMax)?{min:g.duracaoMin,max:g.duracaoMax}:null,favorites:new Set(['azul'])};
vm.createContext(ctx);vm.runInContext(block,ctx);
check('busca por termos combinados e acentos',()=>assert(ctx.collectionMatchesSearch(games[0])&&!ctx.collectionMatchesSearch(games[2]),'Consulta AND ou normalização falhou'));
check('busca por metadados da mecânica',()=>{ctx.collectionQuery='padroes azul';assert(ctx.collectionMatchesSearch(games[1]),'Mecânica não foi indexada')});
check('ordenação por duração',()=>{ctx.collectionQuery='';ctx.collectionSort='duration';const rows=ctx.applyCollectionTools(games.slice());assert(rows.map(x=>x.id).join(',')==='azul,survive,ticket','Ordem de duração incorreta')});
check('favoritos primeiro sem perder critério secundário',()=>{ctx.collectionSort='favorites';const rows=ctx.applyCollectionTools(games.slice());assert(rows[0].id==='azul','Favorito não foi priorizado')});

const scripts=[...html.matchAll(/<script\b[^>]*>([\s\S]*?)<\/script>/gi)].map(m=>m[1]).filter(x=>x.trim());
for(let i=0;i<scripts.length;i++)new vm.Script(scripts[i],{filename:'inline-'+i+'.js'});
check('sintaxe de todos os scripts inline',()=>assert(scripts.length>0,'Nenhum script encontrado'));
for(const line of checks)console.log(line);
const failures=checks.filter(x=>x.startsWith('✗'));
if(failures.length)process.exit(1);
console.log(`\nRegressão V289/V290 na base V291: ${checks.length} verificações aprovadas; ${scripts.length} bloco(s) JavaScript inline válido(s).`);
