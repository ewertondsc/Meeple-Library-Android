const fs=require('fs'),vm=require('vm');
const app=fs.readFileSync('index.html','utf8'),sw=fs.readFileSync('sw.js','utf8');
const start=app.indexOf('function renderHome(){'),end=app.indexOf('function collectionSearchText(g){',start);
const home=app.slice(start,end),css=app.slice(app.indexOf('<style id="v293-2-premium-home">'),app.indexOf('</style>',app.indexOf('<style id="v293-2-premium-home">')));
const checks=[];const check=(n,v)=>checks.push([n,!!v]);
check('retomada de leitura preserva o título CONTINUAR DE ONDE PAROU',home.includes('CONTINUAR DE ONDE PAROU'));
check('retomada mantém jogo, manual e link de continuar',home.includes('home-premium-resume')&&home.includes('manualUrl(g,m)')&&home.includes('esc(m.nome)'));
check('percentual de leitura foi removido da Início',!home.includes('% concluído')&&!home.includes('pct}%'));
check('barra de progresso da retomada foi removida',!home.includes('home-premium-progress'));
check('estante inclui todos os jogos exceto o que está em retomada',home.includes('library.filter(g=>g.id!==resumeId)')&&!home.includes('.slice(0,3)'));
check('estante usa rolagem horizontal',css.includes('overflow-x:auto')&&css.includes('display:flex'));
check('estante usa toque e encaixe suave entre capas',css.includes('-webkit-overflow-scrolling:touch')&&css.includes('scroll-snap-type:x mandatory'));
check('barra horizontal fica visualmente discreta',css.includes('scrollbar-width:none')&&css.includes('::-webkit-scrollbar'));
check('a lista informa acessibilidade sobre deslizar para ver mais jogos',home.includes('Deslize para o lado para ver os demais'));
check('capas abrem as fichas e têm recuperação visual após load',home.includes('data-detail="${esc(g.id)}"')&&home.includes("onload=")&&home.includes("cover-missing"));
check('atalhos Meeple IA e Comparador permanecem',home.includes('data-open-ai=""')&&home.includes('data-hub="compare"'));
check('resumo da coleção continua compacto',home.includes('home-premium-summary')&&home.includes('favoritos'));
check('cache offline recebe identificação nova',sw.includes('v293-5-18-meeple-explorer-integration-20261117'));
check('marca da versão identifica V293.2.3',app.includes('V293.5.18 · Meeple Explorer integrado ao chat.'));

const view={innerHTML:''},classes=[];
const games=[
{id:'things',titulo:'Things in Rings',capa:'cover.jpg',manuais:[{nome:'Manual completo ilustrado',arquivo:'manual.html'}]},
{id:'azul',titulo:'Azul',capa:'cover.jpg',manuais:[{nome:'Manual',arquivo:'manual.html'}]},
{id:'carcassonne',titulo:'Carcassonne',capa:'cover.jpg',manuais:[]},
{id:'catan',titulo:'Catan',capa:'cover.jpg',manuais:[]},
{id:'root',titulo:'Root',capa:'cover.jpg',manuais:[]},
{id:'everdell',titulo:'Everdell',capa:'cover.jpg',manuais:[]},
{id:'dewan',titulo:'Dewan',capa:'cover.jpg',manuais:[]}
];
const ctx={library:games,favorites:new Set(['root']),history:[{id:'things',nome:'Manual completo ilustrado'}],reading:{'things|manual':100},document:{body:{classList:{add:x=>classes.push(x)}}},$:sel=>sel==='#view'?view:null,esc:x=>String(x??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c])),cover:g=>'manuais/'+g.id+'/'+g.capa,manualUrl:(g,m)=>'manuais/'+g.id+'/'+m.arquivo};
vm.createContext(ctx);vm.runInContext(home,ctx);vm.runInContext('renderHome()',ctx);let html=view.innerHTML;
check('render real mantém o card de retomada sem 100% concluído',html.includes('Things in Rings')&&html.includes('Manual completo ilustrado')&&!html.includes('100% concluído')&&!html.includes('home-premium-progress'));
check('render real mostra os seis outros jogos, não só três', (html.match(/class="home-premium-shelf-game"/g)||[]).length===6);
check('render real exclui da estante o jogo que está em retomada',!html.includes('data-detail="things"'));
check('render real mantém as outras capas da coleção',html.includes('data-detail="azul"')&&html.includes('data-detail="dewan"')&&html.includes('data-detail="everdell"'));
check('render real cria dois atalhos', (html.match(/class="home-premium-action(?: home-premium-ai)?"/g)||[]).length===2);
vm.runInContext('history=[];renderHome()',ctx);html=view.innerHTML;
check('sem histórico, a estante mostra todos os jogos',!html.includes('home-premium-resume')&&(html.match(/class="home-premium-shelf-game"/g)||[]).length===7);
vm.runInContext('library=[];favorites=new Set();renderHome()',ctx);html=view.innerHTML;
check('coleção vazia preserva a ação principal de instalação',html.includes('Adicionar meus jogos')&&!html.includes('home-premium-shelf'));
let fail=0;for(const [n,v] of checks){console.log((v?'✓ ':'✗ ')+n);if(!v)fail++}
if(fail)process.exit(1);console.log(`\nV293.2.3: ${checks.length} verificações aprovadas.`);
