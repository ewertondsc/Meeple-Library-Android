// V293.5.28 — manter BGG e Ludopedia lado a lado em telas estreitas
const fs=require('fs');
const html=fs.readFileSync('index.html','utf8');
const match=html.match(/<style id="v293-5-27-detail-layout-structural">([\s\S]*?)<\/style>/);
if(!match)throw new Error('Estilo estrutural da ficha não encontrado');
const css=match[1];
if(!css.includes('grid-template-columns:repeat(2,minmax(0,1fr))!important;gap:8px!important')) throw new Error('BGG/Ludopedia não estão definidos em duas colunas');
if(css.includes('.detail-v293-content>.detail-v259-community{grid-template-columns:1fr!important')) throw new Error('Regra mobile ainda empilha os cartões');
if(!html.includes('class="detail-v293-content"')||!html.includes('class="detail-v259-description"')) throw new Error('Estrutura com descrição em largura total foi alterada');
if(!html.includes('V293.5.28 · Cartões BGG e Ludopedia lado a lado')) throw new Error('Buildstamp não atualizado');
console.log('OK: descrição preservada em largura total e BGG/Ludopedia lado a lado em telas estreitas');
