// V293.5.39 — valida a padronização da identidade visual da Meeple IA.
const fs = require('fs');
const path = require('path');
const root = path.resolve(__dirname, '..');
const html = fs.readFileSync(path.join(root, 'index.html'), 'utf8');
const files = JSON.parse(fs.readFileSync(path.join(root, 'files.json'), 'utf8'));
const sw = fs.readFileSync(path.join(root, 'sw.js'), 'utf8');
const assert = require('assert');
const checks = [];
function check(name, condition) { assert.ok(condition, name); checks.push(name); }
check('imagem oficial Meeple IA existe', fs.existsSync(path.join(root, 'meeple-ai-emblem.png')));
check('imagem oficial está no precache PWA', files.core.includes('meeple-ai-emblem.png'));
check('cabeçalho do Meeple AI usa a imagem oficial', /ai-gemini-chat-mark[^>]*>[\s\S]*?src="meeple-ai-emblem\.png"/.test(html));
check('símbolo central da tela inicial usa a imagem oficial', /ai-home-emblem[^>]*>[\s\S]*?src="meeple-ai-emblem\.png"/.test(html));
check('navegação inferior Meeple IA usa a imagem oficial', /navicon-chat[^>]*>[\s\S]*?src="meeple-ai-emblem\.png"/.test(html));
check('atalho rápido da página inicial usa a imagem oficial', /home-premium-action-icon meeple-ai-entry-icon-wrap[^>]*>[\s\S]*?src="meeple-ai-emblem\.png"/.test(html));
check('atalho da ficha do jogo usa a imagem oficial', /detail-use-card ai[^>]*>[\s\S]*?src="meeple-ai-emblem\.png"/.test(html));
check('atalho do leitor de manual usa a imagem oficial', /meepleToolbarAI[\s\S]{0,600}meeple-ai-emblem\.png/.test(html));
check('atalho de trecho selecionado usa a imagem oficial', /meepleSelectionAsk[\s\S]{0,350}meeple-ai-emblem\.png/.test(html));
check('atalhos do leitor recebem estilo no documento do manual', html.includes('#meepleSelectionAsk.visible{display:flex!important}') && html.includes('.reader-actions #meepleToolbarAI .meeple-ai-entry-icon'));
check('ícone Ferramentas permanece no SVG próprio', /data-tab="hub"[\s\S]{0,700}navicon-tools[\s\S]{0,250}<svg/.test(html));
check('ícones das categorias de ajuda permanecem específicos', html.includes('ai-home-tile-strategy') && html.includes('ai-home-tile-recommend'));
check('ícone de histórico continua sendo relógio', html.includes('ai-gemini-history-quick') && html.includes('M3.5 11a8.5 8.5'));
check('cache do service worker atualizado', sw.includes("v293-5-39-meeple-ai-emblem-20261117"));
check('versão exibida é 293.5.39', html.includes('V293.5.39 · Identidade visual Meeple AI'));
check('marca da IA não abre o visualizador de imagens do manual', html.includes('!img.classList.contains(\'meeple-ai-emblem-img\')') && html.includes('img:not(.meeple-ai-emblem-img):not(.meeple-ai-entry-icon)'));
check('estrutura e classe do layout de ficha não foram removidas', html.includes('v293-game-launch') && html.includes('detail-use-grid v293-game-actions'));
console.log(`V293.5.39: ${checks.length}/${checks.length} testes aprovados`);
checks.forEach((name, i) => console.log(`${i + 1}. ${name}`));
