const fs=require('fs');
const html=fs.readFileSync('index.html','utf8');
const sw=fs.readFileSync('sw.js','utf8');
const checks=[
 ['ícone de histórico único está no cabeçalho',html.includes('id="aiHistoryQuick"')&&html.includes('Abrir histórico de conversas')],
 ['controle de histórico permanece dentro do cabeçalho',html.includes('<div class="ai-gemini-header-actions">')&&html.includes('id="aiHistoryQuick"')],
 ['menu de histórico contém seletor de conversas',html.includes('id="aiConversationSelect"')],
 ['painel contém histórico e exclusão sem controles obsoletos',html.includes('id="aiDeleteConversation"')&&html.includes('Apagar histórico')&&!html.includes('Estilo da resposta')],
 ['Novo chat mantém o ID usado pela lógica existente',html.includes('id="aiNewConversationTop"')],
 ['Novo chat tem ícone próprio e rótulo explícito',html.includes('ai-gemini-new-chat-icon')&&html.includes('<b>Novo chat</b>')],
 ['seletor e botão usam linha de largura total',html.includes('.ai-gemini-screen .ai-gemini-game-row{')&&html.includes('width:100%!important;align-items:center!important;justify-content:space-between!important')],
 ['CSS ancora ações do cabeçalho à direita',html.includes('.ai-gemini-screen .ai-gemini-header-actions{')&&html.includes('flex:0 0 auto!important;width:auto!important;margin-left:auto!important')],
 ['menu abre alinhado à direita',html.includes('ai-history-popover')&&/#aiHistoryPanel\{[\s\S]*?right:0!important/.test(html)],
 ['compositor V293.5.16 permanece no fluxo flex',html.includes('.ai-gemini-screen .ai-gemini-composer{')&&html.includes('position:relative!important;inset:auto!important')],
 ['cache de shell V293.5.39 atualizado',sw.includes('v293-5-39-meeple-ai-emblem-20261117')],
 ['cache de imagens preservado',sw.includes('v288-core-images-20261114')]
];
let failed=0;for(const [name,ok] of checks){console.log(`${ok?'PASS':'FAIL'} ${name}`);if(!ok)failed++;}
if(failed)process.exit(1);console.log(`V293.5.39: ${checks.length} verificações aprovadas.`);
