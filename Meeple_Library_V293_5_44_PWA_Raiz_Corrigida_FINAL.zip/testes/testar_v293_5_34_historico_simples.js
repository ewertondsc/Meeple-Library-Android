// V293.5.34 — menu de histórico exclusivo e ação de apagar tudo
const fs=require('fs');const html=fs.readFileSync('index.html','utf8');
const start=html.indexOf('<div class="ai-v3-options-body ai-gemini-options-body ai-history-only-body">');
const end=html.indexOf('</div></details></div>',start);
const menu=html.slice(start,end);
const handler=html.slice(html.indexOf("$('#aiDeleteConversation').addEventListener"),html.indexOf("const historyQuick=$('#aiHistoryQuick')"));
const checks=[
 ['menu contém apenas histórico',menu.includes('<b>Histórico</b>')&&menu.includes('aiConversationSelect')&&!menu.includes('Estilo da resposta')&&!menu.includes('data-ai-mode')],
 ['botão apagar histórico',menu.includes('Apagar histórico')&&menu.includes('id="aiDeleteConversation"')],
 ['botão nova conversa removido do histórico',!menu.includes('aiNewConversation')],
 ['ação apaga todas as conversas',handler.includes('save(AI_CONVERSATIONS_KEY,[])')],
 ['confirma antes de apagar',handler.includes('confirm(')],
 ['inicia chat limpo após apagar',handler.includes('startNewAIConversation(gameId,true)')],
 ['histórico rápido e menu continuam',html.includes('id="aiHistoryQuick"')&&html.includes('ai-gemini-menu-icon')],
 ['atalhos da tela inicial preservados',html.includes('data-ai-home-mode="rules"')&&html.includes('data-ai-home-mode="strategy"')],
 ['versão atualizada',html.includes('V293.5.34 · Histórico simplificado')]
];
for(const [name,ok] of checks){if(!ok)throw new Error('Falhou: '+name);console.log('OK:',name)}
