#!/usr/bin/env node
// V176 — regressão: Abrir no manual em Regras salvas deve abrir o manual e o capítulo, sem popup.
const fs=require('fs'),path=require('path'),assert=require('assert').strict;
const R=path.resolve(__dirname,'..'),html=fs.readFileSync(path.join(R,'index.html'),'utf8');
let ok=0;function T(name,fn){fn();ok++;console.log('✓',name)}
const a=html.indexOf('async function openStoredModuleManual('),b=html.indexOf('// Fallback para capas',a);
assert.ok(a>=0&&b>a,'função de abertura de módulo encontrada');
const fn=html.slice(a,b);
T('manual de módulo não depende de janela popup about:blank',()=>assert.doesNotMatch(fn,/window\.open\(['"]about:blank/));
T('manual mantém URL real no histórico do navegador',()=>assert.match(fn,/window\.history\.pushState\(\{meepleStoredManual:true/));
T('conteúdo do manual é aberto na janela atual',()=>{assert.match(fn,/document\.open\(\);document\.write/);assert.doesNotMatch(fn,/win\.document/)});
T('capítulo salvo é procurado pelo ID e aberto antes de rolar',()=>{assert.match(fn,/getElementById\(targetId\)/);assert.match(fn,/target\.open=true/);assert.match(fn,/scrollIntoView/)});
T('botão Abrir no manual encaminha o capítulo salvo',()=>{assert.match(html,/openStoredModuleManual\(g,m,r\.chapterId\|\|''\)/);assert.match(html,/location\.href=url/)});
console.log(`\nRegras salvas → manual: ${ok} aprovadas.`);
