const fs=require('fs'),vm=require('vm'),assert=require('assert');
const app=fs.readFileSync('index.html','utf8');
const start=app.indexOf('const MODULE_REFERENCE_DATA={');
const end=app.indexOf('\nasync function migrateBaseGamesToModules',start);
assert(start>=0&&end>start,'bloco do cadastro central encontrado');
const memory=new Map();
const context={
 localStorage:{getItem:k=>memory.has(k)?memory.get(k):null,setItem:(k,v)=>memory.set(k,String(v))},
 console, Date, Number, String, Object, Array, Set, Math, JSON
};
vm.createContext(context);vm.runInContext(app.slice(start,end),context);
const run=(code)=>vm.runInContext(code,context);
// 1) O cadastro estático herdado da V282 continua a completar lacunas.
const azul=run("normalizeModuleGame({id:'azul-addon',titulo:'Azul',ludopediaNota:'',ludopediaUrl:''})");
assert.equal(azul.ludopediaNota,8.6);
assert.equal(azul.ludopediaUrl,'https://ludopedia.com.br/jogo/azul');
// 2) Dados completos da biblioteca base alimentam o cadastro persistente e outro módulo os reaproveita.
run("upsertModuleReferenceFromGame({id:'base-game',titulo:'Jogo Base',bggUrl:'https://boardgamegeek.com/boardgame/987654/jogo-base',bggNota:7.9,bggAvaliacoes:1234,editoraBrasil:'Editora Local',jogadoresMin:2,jogadoresMax:4,categorias:['Estratégia'],fichaRapida:{mecanicas:['Controle de área']}})");
const imported=run("normalizeModuleGame({id:'jogo-base-expansao',titulo:'Jogo Base',bggUrl:'',editoraBrasil:''})");
assert.equal(imported.bggUrl,'https://boardgamegeek.com/boardgame/987654/jogo-base');
assert.equal(imported.bggNota,7.9);
assert.equal(imported.bggAvaliacoes,1234);
assert.equal(imported.editoraBrasil,'Editora Local');
assert.equal(imported.jogadoresMin,2);
assert.deepEqual(Array.from(imported.fichaRapida.mecanicas),['Controle de área']);
// 3) Informações trazidas por um módulo novo viram referência para instalações futuras.
run("upsertModuleReferenceFromGame({id:'novo-jogo-ilha',titulo:'Novo Jogo Ilha',ludopediaNota:8.4,ludopediaAvaliacoes:321,ludopediaUrl:'https://ludopedia.com.br/jogo/survive-the-island',bggId:123456,bggUrl:'https://boardgamegeek.com/boardgame/123456/survive-the-island'})");
const future=run("normalizeModuleGame({id:'novo-jogo-ilha',titulo:'Novo Jogo Ilha',ludopediaNota:null,bggUrl:''})");
assert.equal(future.ludopediaNota,8.4);
assert.equal(future.ludopediaAvaliacoes,321);
assert.equal(future.bggId,123456);
// 4) Valor já cadastrado na referência não é apagado por dados vazios ou inferiores do módulo.
run("upsertModuleReferenceFromGame({id:'azul',titulo:'Azul',ludopediaNota:7.1,ludopediaUrl:''})");
const preserved=run("normalizeModuleGame({id:'azul',titulo:'Azul',ludopediaNota:'',ludopediaUrl:''})");
assert.equal(preserved.ludopediaNota,8.6);
assert.equal(JSON.parse(memory.get('meepleModuleReferenceDataV285')).azul.ludopediaNota,8.6);
// 5) A rotina de armazenamento é local e usa o mesmo registry após reload.
assert.ok(memory.has('meepleModuleReferenceDataV285'));
console.log('Cadastro central: 5 testes de compatibilidade aprovados.');
