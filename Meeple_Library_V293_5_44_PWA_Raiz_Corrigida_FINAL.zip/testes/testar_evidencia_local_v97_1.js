#!/usr/bin/env node
const fs=require('fs'),assert=require('assert').strict,path=require('path');
const html=fs.readFileSync(path.resolve(__dirname,'..','index.html'),'utf8');
const worker=fs.readFileSync(path.resolve(__dirname,'..','pesquisa-externa','worker.js'),'utf8');
const req=html.slice(html.indexOf('async function requestMeepleIA'),html.indexOf('\nfunction evidenceStatusInfo'));
assert.match(req,/localEvidence/,'front-end precisa enviar evidências locais em campo separado');
assert.match(req,/query:String\(question\|\|''\)/,'a pergunta deve seguir limpa e separada');
assert.doesNotMatch(req,/buildLocalEvidencePrompt\(question/,'não embutir os manuais no texto da pergunta');
assert.match(html,/strong\.length\?strong:hits\.slice\(0,8\)/,'recuperar candidatos locais mesmo quando a confiança inicial é baixa');
assert.match(worker,/Array\.isArray\(body\.localEvidence\)/,'Worker deve aceitar evidências locais estruturadas');
assert.match(worker,/sources = \[\.\.\.sources, \.\.\.search\.results\]/,'Worker deve combinar manual local e pesquisa externa');
assert.match(worker,/searchError && !sources\.length/,'falha externa não pode descartar manual local');
assert.match(worker,/MANUAL LOCAL DA BIBLIOTECA/,'modelo deve identificar a origem local');
assert.match(worker,/localEvidenceUsed:/,'Worker deve informar quantos trechos locais analisou');
console.log('Meeple IA V97.1 — 9 verificações aprovadas.');
