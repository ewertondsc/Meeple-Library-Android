const fs=require('fs'),assert=require('assert');
const app=fs.readFileSync('index.html','utf8');
const sw=fs.readFileSync('sw.js','utf8');
const checks=[
 ['o app remove CSS e scripts particulares do módulo','doc.querySelectorAll(\'style,link[rel~=\\"stylesheet\\"],script\').forEach(node=>node.remove())'],
 ['o app elimina estilos inline que quebram responsividade',app.includes("doc.querySelectorAll('[style]').forEach(node=>{if(!node.closest('svg'))node.removeAttribute('style')})")],
 ['viewport mobile padronizado','viewport-fit=cover'],
 ['raiz universal gerenciada pelo app',app.includes("standardizedRoot.classList.add('meeple-reader-content')")],
 ['imagens com tamanho responsivo e carregamento otimizado',app.includes("img.loading='lazy';img.decoding='async'")],
 ['tabelas com rolagem horizontal controlada',app.includes("wrap.className='meeple-table-scroll'")],
 ['stylesheet final do app centraliza apresentação',app.includes('meeple-reader-standard-v286')],
 ['layout mobile reduzido para ecrãs estreitos',app.includes('@media(max-width:420px)')],
 ['cache do Service Worker avança para V293.5.39',sw.includes('v293-5-39-meeple-ai-emblem-20261117')],
 ['leitor nativo continua com capítulos e navegação',app.includes('details.topic')&&app.includes("className='chapter-nav'")]
];
let fail=0;for(const [name,pass] of checks){console.log((pass?'✓ ':'✗ ')+name);if(!pass)fail++}
if(fail)process.exit(1);console.log(`\nV293.5.39: ${checks.length} verificações do leitor aprovadas.`);
