const fs=require('fs');
const html=fs.readFileSync('index.html','utf8');
const i=html.indexOf('data-community="ludopedia"');
const snippet=html.slice(i,i+350);
const handler=html.slice(html.indexOf('function openLudopediaCommunity'),html.indexOf('function renderCommunityPage'));
const checks=[
 ['botão Ludopedia chama função dedicada',snippet.includes("openLudopediaCommunity('")],
 ['função dedicada abre página interna Ludopedia',handler.includes("renderCommunityPage(id,'ludopedia')")],
 ['fallback de URL do Azul existe',handler.includes("game.id==='azul'")],
 ['evento não dispara duas vezes',snippet.includes('event.stopPropagation()')],
 ['cache atualizado',fs.readFileSync('sw.js','utf8').includes('v282-community-direct-external-links')]
];
let fail=0;for(const [n,ok] of checks){console.log((ok?'✓ ':'✗ ')+n);if(!ok)fail++}
if(fail)process.exit(1);console.log(`\nCommunity buttons V281 OK: ${checks.length} verificações.`);
