const fs=require('fs');
const html=fs.readFileSync('index.html','utf8');
const lib=JSON.parse(fs.readFileSync('library.json','utf8'));
const azul=lib.find(g=>g.id==='azul');
const d=azul&&azul.ludopediaDados;
const checks=[
 ['dados complementares da Ludopedia cadastrados para Azul',!!d],
 ['Visão geral com série, ano e lançamento no Brasil',!!(d&&d.serie&&d.ano&&d.lancamentoBrasil)],
 ['designer e artistas disponíveis',!!(d&&d.designer?.length&&d.artistas?.length)],
 ['categorias, mecânicas e temas disponíveis',!!(d&&d.categorias?.length&&d.mecanicas?.length&&d.temas?.length)],
 ['idioma e editoras disponíveis',!!(d&&d.idioma&&d.editoras?.length)],
 ['avaliação de comunidade e métricas Como é jogar',!!(d&&d.comoEJogar?.interacao&&d.comoEJogar?.sorte&&d.comoEJogar?.downtime&&d.comoEJogar?.rejogabilidade)],
 ['prêmios, componentes e versão digital disponíveis',!!(d&&d.premios?.length&&d.componentes?.length&&d.versoesDigitais?.length)],
 ['página apresenta seção Visão geral da Ludopedia',html.includes('Visão geral da Ludopedia')],
 ['página apresenta seção Como é jogar',html.includes('Como é jogar')],
 ['página só mostra campos com dados',html.includes(".filter(x=>x[2]!==undefined&&x[2]!==null&&String(x[2]).trim()!=='')")],
 ['layout responsivo da ficha complementar',html.includes('v276-ludopedia-overview')],
 ['cache do app atualizado',fs.readFileSync('sw.js','utf8').includes('v282-community-direct-external-links')]
];
let fail=0;for(const [name,ok] of checks){console.log((ok?'✓ ':'✗ ')+name);if(!ok)fail++}
if(fail)process.exit(1);console.log(`\nLudopedia Visão Geral OK: ${checks.length} verificações.`);
