const fs = require('fs');
const assert = require('assert');
const html = fs.readFileSync('index.html', 'utf8');
const sw = fs.readFileSync('sw.js', 'utf8');
const renderStart = html.indexOf('function renderAI(');
const renderEnd = html.indexOf("$('#aiForm').addEventListener('submit',askAI);", renderStart);
assert(renderStart >= 0 && renderEnd > renderStart, 'AI render function is present');
const render = html.slice(renderStart, renderEnd);
for (const token of ['ai-future-screen','ai-future-header','ai-future-controls','ai-future-chat','ai-future-compose','id="aiGame"','id="aiQuestion"','id="aiConversationSelect"','id="aiNewConversation"','data-ai-mode="rules"','data-ai-mode="strategy"','data-ai-mode="situation"']) {
  assert(render.includes(token) || html.includes(token), `required UI token: ${token}`);
}
assert(render.includes("$('#aiForm').addEventListener") === false, 'event listeners remain outside template markup');
assert(html.includes('id="meeple-ai-v293-5-11-futurista"'), 'futuristic visual system is installed');
assert(html.includes('grid-template-columns:minmax(0,1fr) 48px'), 'composer keeps a fluid input and fixed send button');
assert(html.includes('writing-mode:horizontal-tb'), 'mobile input remains horizontal');
assert(html.includes('MeepleExpertCore'), 'Expert engine integration is retained');
assert(html.includes("$('#aiForm').addEventListener('submit',askAI)"), 'submit listener remains connected');
assert(html.includes("$('#aiConversationSelect').addEventListener"), 'conversation history listener remains connected');
assert(html.includes("document.querySelectorAll('[data-ai-mode]')"), 'response style controls remain connected');
assert(sw.includes("var BUILD='v293-5-11-meeple-ai-futurista-20261117'"), 'service worker cache was versioned');
console.log('V293.5.11 Meeple AI Futurista: all checks passed.');
