#!/usr/bin/env node
// Confere os exemplos redesenhados em HTML do The Resistance.  Uso: node testes/testar_diagramas.js
const fs=require('fs'),path=require('path'),assert=require('assert').strict;
const R=path.resolve(__dirname,'..'),h=fs.readFileSync(R+'/manuais/the-resistance/completo.html','utf8');
let ok=0,fail=0;const t=(n,f)=>{try{f();ok++;console.log('✓',n)}catch(e){fail++;console.log('✗',n,'\n    ',e.message.split('\n')[0])}};
const mx=[...h.matchAll(/<div aria-label="([^"]+)" class="mx" role="group">([\s\S]*?)<details class="orig">/g)];
const txt=s=>s.replace(/<[^>]+>/g,' ').replace(/\s+/g,' ');
t('3 diagramas (equipe, votação, missão), cada um com rótulo de acessibilidade',()=>{assert.equal(mx.length,3);assert.deepEqual(mx.map(m=>/equipe|vota|miss/i.test(m[1])),[true,true,true])});
t('equipe: Paulo é Líder e tem ficha; Carlos tem ficha; 5 jogadores',()=>{const d=txt(mx[0][2]);assert.equal((mx[0][2].match(/class="pl"/g)||[]).length,5);assert.match(d,/Paulo Líder Ficha de Equipe/);assert.match(d,/Carlos Ficha de Equipe/)});
t('votação: 4 aprovam, 1 rejeita, equipe aprovada',()=>{assert.equal((mx[1][2].match(/✓ Aprova/g)||[]).length,4);assert.equal((mx[1][2].match(/✗ Rejeita/g)||[]).length,1);assert.match(txt(mx[1][2]),/4 aprovam · 1 rejeita[\s\S]*aprovada/)});
t('missão: Paulo joga Sucesso, Carlos joga Fracasso, resultado = fracasso',()=>{const d=txt(mx[2][2]);assert.match(d,/Paulo[\s\S]*joga Sucesso/);assert.match(d,/Carlos[\s\S]*joga Fracasso/);assert.match(txt(mx[2][2]),/1 Sucesso \+ 1 Fracasso[\s\S]*fracassa/)});
t('as ilustrações originais continuam disponíveis (recolhidas) e existem no disco',()=>{const o=[...h.matchAll(/<details class="orig">[\s\S]*?src="(img\/[^"]+)"/g)].map(m=>m[1]);assert.equal(o.length,3);for(const f of o)assert.ok(fs.existsSync(R+'/manuais/the-resistance/'+f),f)});
t('o CSS dos diagramas usa as cores do tema (claro/escuro) e quebra linha no celular',()=>{const c=h.match(/<style id="diagramas-resistance">([\s\S]*?)<\/style>/)[1];for(const v of['--ln','--sf','--bg','--mu'])assert.ok(c.includes('var('+v+')'),v);assert.match(c,/flex-wrap:wrap/);assert.ok(!/#fff\b|#000\b|background:white/i.test(c),'cor fixa que quebra o modo escuro')});
t('as imagens dos exemplos não aparecem soltas fora das ilustrações originais',()=>{const solto=h.replace(/<details class="orig">[\s\S]*?<\/details>/g,'');for(const f of['exemplo_equipe','exemplo_votacao','exemplo_missao'])assert.ok(!solto.includes(f),f)});
console.log(fail?'\n'+fail+' falha(s)':'\nDiagramas OK: '+ok+' verificações');process.exit(fail?1:0);
