const fs=require('fs'),assert=require('assert'),vm=require('vm');
const s=fs.readFileSync('index.html','utf8'),sw=fs.readFileSync('sw.js','utf8');
const checks=[
 ['V293.5.18 build marker',s.includes("V293.5.18 · Meeple Explorer integrado ao chat.")],
 ['versioned service worker cache',sw.includes("v293-5-18-meeple-explorer-integration-20261117")],
 ['device-local conversation store',s.includes("AI_CONVERSATIONS_KEY='meepleAIConversationsV292'")],
 ['conversation history persistence',s.includes('function persistAIConversation()')&&s.includes('save(AI_CONVERSATIONS_KEY')],
 ['conversation restore by selected game',s.includes('function prepareAIConversation(gameId,preserve)')&&s.includes("filter(x=>String(x.gameId||'')===gameId)")],
 ['recent conversation selector',s.includes('id="aiConversationSelect"')&&s.includes('refreshAIConversationOptions()')],
 ['new conversation action',s.includes('id="aiNewConversation"')],
 ['delete current conversation action',s.includes('id="aiDeleteConversation"')],
 ['history capped to 20 sessions',s.includes('sessions.slice(0,20)')],
 ['stored messages capped to recent 12',s.includes('aiMessages.slice(-12)')],
 ['three response modes',s.includes("rules:'MODO DE RESPOSTA")&&s.includes("strategy:'MODO DE RESPOSTA")&&s.includes("situation:'MODO DE RESPOSTA")],
 ['mode controls are accessible inside the options menu',s.includes('role="group" aria-label="Estilo da resposta"')&&s.includes('data-ai-mode="rules"')&&s.includes('data-ai-mode="strategy"')&&s.includes('data-ai-mode="situation"')],
 ['local context index helper retained without adding status clutter',s.includes('function updateAIContextStatus(gameId)')&&!s.includes('id="aiContextStatus"')],
 ['context counts index sections and expansions',s.includes('seção(ões) indexada(s)')&&s.includes('expansions=rows.filter')],
 ['Explorer bridge forwards only context-dependent recent history',/function passHistory\(question, history\)/.test(fs.readFileSync('meeple-explorer/js/bridge.js','utf8'))&&/slice\(-4\)/.test(fs.readFileSync('meeple-explorer/js/bridge.js','utf8'))],
 ["local-first evidence flow retained with Explorer routing",s.includes("findLocalManualEvidence(contextualQuestion,scope,entries)")&&s.includes("requestMeepleExplorer(contextualQuestion,{id:scope,title:chosenGame.titulo},expertResult||{status:'partial',hits:localHits},expertHistory)")],
 ['source citations retained in Explorer synthesis',s.includes('renderMeepleExplorerSynthesis(data,localHits,chosenGame.titulo)')&&s.includes('renderMeepleIAAnswer(data)')],
 ['existing saved-rule feature retained',s.includes('data-save-rule=')&&s.includes('function saveAIRule(index)')],
 ['quick-prompt cards removed from the simplified main screen',!s.slice(s.indexOf('function renderAI('),s.indexOf('function safeTextHTML')).includes('ai-shortcuts-v2')],
 ['V291 module manager retained',s.includes('Gerenciar módulos')&&s.includes('renderModuleManager')],
 ['V290 comparator retained',s.includes('Comparar jogos')&&s.includes('function renderCompare()')&&s.includes('function compareField(g,key)')],
 ['safe HTML escaping retained',s.includes('function safeTextHTML(s)')&&s.includes('function esc(s)')]
];let bad=0;for(const [name,ok] of checks){console.log((ok?'PASS ':'FAIL ')+name);if(!ok)bad++;}
// Exercise the actual persistence/restore helpers in an isolated browser-like context.
const start=s.indexOf("const AI_CONVERSATIONS_KEY='meepleAIConversationsV292';"),end=s.indexOf('function updateAIContextStatus(gameId)',start);
assert(start>=0&&end>start,'Conversation helpers not found');
const store={};const ctx={aiMessages:[],library:[{id:'azul',titulo:'Azul'},{id:'dewan',titulo:'Dewan'}],read:(k,d)=>{try{return store[k]===undefined?d:JSON.parse(store[k])}catch(_){return d}},save:(k,v)=>{store[k]=JSON.stringify(v)},safeTextHTML:x=>String(x).replace(/</g,'&lt;')};
vm.createContext(ctx);vm.runInContext(s.slice(start,end),ctx);
vm.runInContext("prepareAIConversation('azul',false);aiMessages.push({role:'user',text:'Como pontuar?',html:'Como pontuar?'});persistAIConversation();",ctx);
const azulId=vm.runInContext('aiActiveConversationId',ctx);
vm.runInContext("prepareAIConversation('dewan',false);aiMessages.push({role:'user',text:'Como funciona a trilha?',html:'Como funciona a trilha?'});persistAIConversation();prepareAIConversation('azul',false);",ctx);
const restored=vm.runInContext("({id:aiActiveConversationId,game:aiActiveGameId,count:aiMessages.length,text:aiMessages[0]?.text})",ctx);
const stored=JSON.parse(store.meepleAIConversationsV292||'[]');
const runtimeOK=restored.id===azulId&&restored.game==='azul'&&restored.count===1&&restored.text==='Como pontuar?'&&stored.length===2;
console.log((runtimeOK?'PASS ':'FAIL ')+'runtime conversation persistence, restore by game and session isolation');if(!runtimeOK)bad++;
if(bad)process.exit(1);console.log(`\nV293.5.18: ${checks.length+1} verificações específicas aprovadas.`);
