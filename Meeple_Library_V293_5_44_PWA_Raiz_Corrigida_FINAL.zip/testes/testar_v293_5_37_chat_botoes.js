'use strict';
const fs = require('fs');
const vm = require('vm');
const assert = require('assert');
const html = fs.readFileSync(require('path').join(__dirname, '..', 'index.html'), 'utf8');
const start = html.indexOf("function renderAI(prefill='',preserveQuick=false){");
const end = html.indexOf('\nfunction safeTextHTML', start);
assert(start >= 0 && end > start, 'Não foi possível localizar renderAI');
const renderSource = html.slice(start, end);
const newChatStart = html.indexOf('function startNewAIConversation(gameId,focus=true){');
const newChatEnd = html.indexOf('\nfunction persistAIConversation', newChatStart);
assert(newChatStart >= 0 && newChatEnd > newChatStart, 'Não foi possível localizar startNewAIConversation');
const newChatSource = html.slice(newChatStart, newChatEnd);

class FakeElement {
  constructor(id='') {
    this.id=id; this.handlers={}; this.attributes={}; this.dataset={}; this.style={};
    this.classList={add(){},remove(){},toggle(){},contains(){return false}};
    this.hidden=true; this.disabled=false; this.value=''; this.innerHTML='';
    this.scrollHeight=44; this.clientHeight=100; this.scrollTop=0; this.isConnected=true;
    this.options=[]; this.children=[]; this.requestSubmitCount=0; this.focusCount=0;
  }
  addEventListener(type,fn){(this.handlers[type]??=[]).push(fn)}
  setAttribute(k,v){this.attributes[k]=String(v)}
  getAttribute(k){return this.attributes[k]??null}
  dispatch(type,event={}){const e={type,target:this,preventDefault(){this.defaultPrevented=true},stopPropagation(){},...event};(this.handlers[type]||[]).forEach(fn=>fn(e));return e}
  dispatchEvent(event){return this.dispatch(event.type,{target:this})}
  focus(){this.focusCount++}
  scrollIntoView(){}
  contains(target){return target===this||target?.parent===this}
  requestSubmit(){this.requestSubmitCount++;this.dispatch('submit')}
}
const ids=['hero','view','aiForm','aiGame','aiNewConversationTop','aiConversationSelect','aiDeleteConversation','aiHistoryQuick','aiHistoryPanel','aiChat','aiQuestion','aiSend','meepleExpertStatus','meepleIAStatus'];
const nodes=Object.fromEntries(ids.map(id=>[id,new FakeElement(id)]));
nodes.aiGame.options=[{value:''},{value:'todos'},{value:'azul'}];
nodes.aiGame.value='';
nodes.aiConversationSelect.value='session-1';
nodes.aiConversationSelect.options=[{value:'session-1'}];
Object.defineProperty(nodes.view,'innerHTML',{get(){return this._html||''},set(v){this._html=v;this.renderCount=(this.renderCount||0)+1;for(const [id,node] of Object.entries(nodes)){if(id==='view'||id==='hero')continue;node.handlers={};if(id==='aiHistoryPanel')node.hidden=true;if(id==='aiHistoryQuick')node.attributes['aria-expanded']='false';if(id==='aiQuestion')node.value='';if(id==='aiSend')node.disabled=false;}}});
nodes.aiForm.requestSubmit=function(){this.requestSubmitCount++;this.dispatch('submit')};
const nav=new FakeElement('nav');nav.dataset.tab='ia';
const screen=new FakeElement('screen');
const documentHandlers={};
const document={
  body:new FakeElement('body'),
  querySelector(selector){
    if(selector.startsWith('#'))return nodes[selector.slice(1)]||null;
    if(selector==='.ai-gemini-screen')return screen;
    return null;
  },
  querySelectorAll(selector){if(selector==='.navbtn')return [nav];return []},
  addEventListener(type,fn){(documentHandlers[type]??=[]).push(fn)}
};
const store={};
let sessions=[{id:'session-1',gameId:'azul',gameTitle:'Azul',updatedAt:Date.now(),messages:[{role:'user',text:'teste'},{role:'assistant',text:'resposta'}]}];
let starts=0,asks=0,refreshes=0,idNo=0,confirmAnswer=true,alerts=[],savedRuleMode='rules';
const context={
  document,window:{innerHeight:800,visualViewport:null,addEventListener(){},scrollTo(){}},
  library:[{id:'azul',titulo:'Azul'}],aiMessages:[],aiQuickPrompts:[],aiQuickSignature:'',
  aiActiveConversationId:'session-1',aiActiveGameId:'',aiBusy:false,aiSelectedTool:'',aiResponseMode:'rules',
  AI_CONVERSATIONS_KEY:'meepleIAConversationsV292',AI_MODE_PROMPTS:{rules:'r',strategy:'s',situation:'x'},
  $:s=>s.startsWith('#')?(nodes[s.slice(1)]||null):null,
  read:(k,d)=>k==='meepleIASelectedGame'?'':(store[k]===undefined?d:store[k]),
  save:(k,v)=>{store[k]=v;if(k==='meepleIAConversationsV292')sessions=v},
  esc:s=>String(s??''),makeAIQuickPrompts:()=>[],prepareAIConversation(){},
  refreshAIConversationOptions(){refreshes++;},
  aiConversationStore:()=>sessions,aiConversationId:()=>`new-${++idNo}`,
  startNewAIConversation(){starts++;context.aiMessages=[]},
  persistAIConversation(){},updateAIContextStatus(){},askAI(){asks++},
  checkMeepleIAStatus(){},bindMeepleAIGeminiViewport(){},syncMeepleAIGeminiViewport(){},scrollMeepleAIGeminiToLatest(){},
  renderAIHomeEmpty:()=>'<div class="ai-home-empty"></div>',compactAIEvidenceHTML:s=>s,safeTextHTML:s=>String(s),
  requestAnimationFrame:fn=>fn(),Event:class {constructor(type,opts){this.type=type;this.bubbles=!!opts?.bubbles}},
  alert:m=>alerts.push(m),confirm:()=>confirmAnswer,console,
  setTimeout:fn=>fn(),
};
context.globalThis=context;
vm.createContext(context);
vm.runInContext(renderSource+'\nrenderAI();',context,{timeout:5000});
vm.runInContext(newChatSource,context,{timeout:5000});
let passed=0,total=0;const check=(label,fn)=>{total++;try{assert.strictEqual(fn(),true,label);passed++;console.log('✓ '+label)}catch(e){console.error('✗ '+label+' — '+e.message);process.exitCode=1}};

check('Inicialização do chat não tenta registrar listener em botão removido',()=>!renderSource.includes("$('#aiNewConversation').addEventListener"));
check('Formulário recebe evento submit',()=>!!nodes.aiForm.handlers.submit?.length);
check('Botão enviar recebe evento click',()=>!!nodes.aiSend.handlers.click?.length);
check('Botão novo chat recebe evento click',()=>!!nodes.aiNewConversationTop.handlers.click?.length);
check('Botão de histórico recebe evento click',()=>!!nodes.aiHistoryQuick.handlers.click?.length);
check('Botão apagar histórico recebe evento click',()=>!!nodes.aiDeleteConversation.handlers.click?.length);
check('Seletor de jogo recebe evento change',()=>!!nodes.aiGame.handlers.change?.length);
check('Seletor de conversa recebe evento change',()=>!!nodes.aiConversationSelect.handlers.change?.length);
check('Selecionar conversa restaura mensagens e jogo',()=>{let rerender=0;const original=context.renderAI;context.renderAI=()=>{rerender++};nodes.aiConversationSelect.value='session-1';nodes.aiConversationSelect.dispatch('change',{target:nodes.aiConversationSelect});context.renderAI=original;return context.aiActiveConversationId==='session-1'&&context.aiActiveGameId==='azul'&&context.aiMessages.length===2&&rerender===1});
check('Chat recebe delegado de atalhos e exemplos',()=>!!nodes.aiChat.handlers.click?.length);
check('Textarea recebe eventos de digitação e teclado',()=>['input','paste','change','keyup','compositionend','keydown'].every(x=>!!nodes.aiQuestion.handlers[x]?.length));
check('Painel de histórico inicia fechado e aria-expanded false',()=>nodes.aiHistoryPanel.hidden&&nodes.aiHistoryQuick.getAttribute('aria-expanded')==='false');
check('Textarea vazia mantém enviar desabilitado',()=>nodes.aiSend.disabled===true);
check('Histórico abre pelo botão',()=>{nodes.aiHistoryQuick.dispatch('click');return !nodes.aiHistoryPanel.hidden&&nodes.aiHistoryQuick.getAttribute('aria-expanded')==='true'});
check('Abertura do histórico move foco ao seletor',()=>nodes.aiConversationSelect.focusCount>0);
check('Histórico fecha pelo mesmo botão',()=>{nodes.aiHistoryQuick.dispatch('click');return nodes.aiHistoryPanel.hidden&&nodes.aiHistoryQuick.getAttribute('aria-expanded')==='false'});
check('Escape fecha histórico',()=>{nodes.aiHistoryQuick.dispatch('click');(documentHandlers.keydown||[]).forEach(fn=>fn({key:'Escape'}));return nodes.aiHistoryPanel.hidden&&nodes.aiHistoryQuick.focusCount>0});
check('Clique fora fecha histórico',()=>{nodes.aiHistoryQuick.dispatch('click');(documentHandlers.click||[]).forEach(fn=>fn({target:new FakeElement('outside')}));return nodes.aiHistoryPanel.hidden});
check('Apagar histórico limpa sessões e inicia conversa vazia após confirmação',()=>{sessions=[{id:'s',messages:[{role:'user',text:'x'}]}];context.aiMessages=[{role:'user',text:'x'}];const priorRender=nodes.view.renderCount;nodes.aiHistoryQuick.dispatch('click');nodes.aiDeleteConversation.dispatch('click');return sessions.length===0&&context.aiMessages.length===0&&nodes.view.renderCount===priorRender+1&&nodes.aiHistoryPanel.hidden&&nodes.aiHistoryQuick.getAttribute('aria-expanded')==='false'});
check('Cancelar exclusão preserva histórico',()=>{sessions=[{id:'keep',messages:[{role:'user',text:'manter'}]}];confirmAnswer=false;nodes.aiDeleteConversation.dispatch('click');confirmAnswer=true;return sessions.length===1&&sessions[0].id==='keep'});
check('Apagar com histórico vazio mostra aviso',()=>{sessions=[];const before=alerts.length;nodes.aiDeleteConversation.dispatch('click');return alerts.length===before+1});
check('Novo chat limpa mensagens, cria ID, mantém jogo e foca o campo',()=>{context.aiMessages=[{role:'user',text:'rascunho'}];nodes.aiGame.value='azul';const priorId=context.aiActiveConversationId,priorRender=nodes.view.renderCount,priorFocus=nodes.aiQuestion.focusCount;nodes.aiNewConversationTop.dispatch('click');return context.aiMessages.length===0&&context.aiActiveConversationId!==priorId&&context.aiActiveGameId==='azul'&&nodes.view.renderCount===priorRender+1&&nodes.aiQuestion.focusCount===priorFocus+1});
check('Seletor de jogo salva seleção e atualiza contexto',()=>{nodes.aiGame.value='azul';nodes.aiGame.dispatch('change');return store.meepleIASelectedGame==='azul'});
check('Atalho regras preenche pergunta e seleciona modo',()=>{const ev={target:{closest:s=>s==='[data-ai-home-mode]'?{dataset:{aiHomeMode:'rules'}}:null}};nodes.aiChat.dispatch('click',ev);return nodes.aiQuestion.value.includes('regras')&&context.aiResponseMode==='rules'});
check('Atalho estratégia preenche pergunta e seleciona modo',()=>{const ev={target:{closest:s=>s==='[data-ai-home-mode]'?{dataset:{aiHomeMode:'strategy'}}:null}};nodes.aiChat.dispatch('click',ev);return nodes.aiQuestion.value.includes('estratégia')&&context.aiResponseMode==='strategy'});
check('Atalho recomendações preenche pergunta',()=>{const ev={target:{closest:s=>s==='[data-ai-home-mode]'?{dataset:{aiHomeMode:'recommend'}}:null}};nodes.aiChat.dispatch('click',ev);return nodes.aiQuestion.value.includes('recomenda')} );
check('Exemplo 1 preenche prompt',()=>{const ev={target:{closest:s=>s==='[data-ai-home-mode]'?null:s==='[data-ai-example]'?{dataset:{aiExample:'Como vencer no Carcassonne?'}}:null}};nodes.aiChat.dispatch('click',ev);return nodes.aiQuestion.value==='Como vencer no Carcassonne?'});
check('Exemplo 2 preenche prompt',()=>{const ev={target:{closest:s=>s==='[data-ai-home-mode]'?null:s==='[data-ai-example]'?{dataset:{aiExample:'Qual a regra de pontuação do Azul?'}}:null}};nodes.aiChat.dispatch('click',ev);return nodes.aiQuestion.value==='Qual a regra de pontuação do Azul?'});
check('Exemplo 3 preenche prompt',()=>{const ev={target:{closest:s=>s==='[data-ai-home-mode]'?null:s==='[data-ai-example]'?{dataset:{aiExample:'Quais jogos são parecidos com Catan?'}}:null}};nodes.aiChat.dispatch('click',ev);return nodes.aiQuestion.value==='Quais jogos são parecidos com Catan?'});
check('Botão enviar fica habilitado após pergunta válida',()=>{nodes.aiQuestion.value='Como vencer no Azul?';nodes.aiQuestion.dispatch('input');return nodes.aiSend.disabled===false});
check('Botão enviar bloqueia conteúdo vazio',()=>{nodes.aiQuestion.value=' ';nodes.aiQuestion.dispatch('input');const before=nodes.aiForm.requestSubmitCount;nodes.aiSend.dispatch('click');return nodes.aiSend.disabled&&nodes.aiForm.requestSubmitCount===before});
check('Botão enviar aciona requestSubmit e evento submit',()=>{const before=nodes.aiForm.requestSubmitCount,prior=asks;nodes.aiQuestion.value='pergunta válida';nodes.aiQuestion.dispatch('input');nodes.aiSend.dispatch('click');return nodes.aiForm.requestSubmitCount===before+1&&asks===prior+1});
check('Enter aciona requestSubmit e evento submit',()=>{nodes.aiQuestion.value='teste por enter';const before=nodes.aiForm.requestSubmitCount,prior=asks;nodes.aiQuestion.dispatch('keydown',{key:'Enter',shiftKey:false});return nodes.aiForm.requestSubmitCount===before+1&&asks===prior+1});
check('Shift+Enter não envia formulário',()=>{const before=nodes.aiForm.requestSubmitCount;nodes.aiQuestion.dispatch('keydown',{key:'Enter',shiftKey:true});return nodes.aiForm.requestSubmitCount===before});
console.log(`RESULTADO: ${passed}/${total} testes de controles passaram.`);
