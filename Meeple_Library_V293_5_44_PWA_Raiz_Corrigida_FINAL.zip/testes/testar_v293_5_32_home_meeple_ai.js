// V293.5.32 — tela inicial proposta e atalhos funcionais
const fs=require('fs');
const html=fs.readFileSync('index.html','utf8');
const homeStart=html.indexOf("const homePanel=$('#aiChat')");
const homeEnd=html.indexOf("const questionBox=$('#aiQuestion'),sendButton=$('#aiSend')",homeStart);
const homeHandler=html.slice(homeStart,homeEnd);
const nav=html.slice(html.indexOf('<nav class="bottomnav"'),html.indexOf('</nav>',html.indexOf('<nav class="bottomnav"'))+6);
const detailStart=html.indexOf('<section class="detailhero detailhero-premium');
const detailEnd=html.indexOf('</section>`;',detailStart);
const detail=html.slice(detailStart,detailEnd);
const checks=[
 ['emblema Meeple central usa o ativo oficial',html.includes('ai-home-emblem')&&html.includes('ai-home-emblem-img')&&html.includes('meeple-ai-emblem.png')],
 ['título da tela inicial',html.includes('A mesa está pronta.')],
 ['atalho regras',html.includes('data-ai-home-mode="rules"')],
 ['atalho estratégias',html.includes('data-ai-home-mode="strategy"')],
 ['atalho recomendações',html.includes('data-ai-home-mode="recommend"')],
 ['três exemplos de pergunta',html.includes('Como vencer no Carcassonne?')&&html.includes('Qual a regra de pontuação do Azul?')&&html.includes('Quais jogos são parecidos com Catan?')],
 ['botão rápido de histórico',html.includes('id="aiHistoryQuick"')],
 ['histórico abre o painel de conversas',html.includes("const historyQuick=$('#aiHistoryQuick')")&&html.includes('setHistoryOpen(historyPanel.hidden)')],
 ['atalhos preenchem o campo',homeHandler.includes('questionBox.value=example.dataset.aiExample')],
 ['atalhos não enviam automaticamente',!homeHandler.includes('requestSubmit')],
 ['tela inicial aplicada quando troca de jogo',html.includes('chat.innerHTML=renderAIHomeEmpty()')],
 ['ícones atuais da navegação preservados',nav.includes('navicon-tools')&&nav.includes('navicon-chat')&&nav.includes('meeple-ai-emblem.png')],
 ['estrutura aprovada da ficha preservada',detail.includes('detail-cover-column')&&detail.includes('detail-identity')&&detail.includes('detail-v259-description')&&detail.includes('detail-v259-community')&&!detail.includes('detail-v293-content')],
 ['versão atualizada',html.includes('V293.5.39 · Identidade visual Meeple AI')]
];
for(const [name,ok] of checks){if(!ok)throw new Error('Falhou: '+name);console.log('OK:',name)}
