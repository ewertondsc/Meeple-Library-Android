const fs = require('fs');
const vm = require('vm');
const assert = require('assert');
const bridgeSource = fs.readFileSync(__dirname + '/../meeple-explorer/js/bridge.js', 'utf8');
const html = fs.readFileSync(__dirname + '/../index.html', 'utf8');
let postPayload = null;
let postUrl = '';
const games = new Map();
const core = {
  gameCatalog: games,
  documents: [],
  addGame(game) { games.set(String(game.id), { ...game, title: game.title }); },
  registerModule() {},
  detectGame() { return { id: null }; },
  isContextDependentQuery() { return false; }
};
const fakeFetch = async (url, options = {}) => {
  const u = String(url);
  if ((options.method || 'GET') === 'POST') {
    postUrl = u;
    postPayload = JSON.parse(options.body);
    return { ok: true, status: 200, json: async () => ({
      answer: 'Resposta simulada pelo Meeple Explorer.', aiGenerated: true,
      aiModel: 'workers-ai', sources: [{ title: 'Fonte simulada', url: 'https://example.org/rules', snippet: 'Trecho demonstrativo.' }]
    }) };
  }
  if (u.includes('catalogo.json')) return { ok: true, json: async () => ({ modulos: [{ id: 'survive-the-island', titulo: 'Survive the Island', zip: 'https://cdn.example.org/survive.zip', aliases: ['Survive'] }] }) };
  if (u === 'https://meeple-expert-public-search.ewertonscosta.workers.dev/') return { ok: true, json: async () => ({ status: 'online', version: '5.5', searchEnabled: true, moduleIndexEnabled: true, aiEnabled: true, model: 'workers-ai' }) };
  if (u.includes('/module-index?gameId=survive-the-island')) return { ok: true, json: async () => ({ exists: true, gameId: 'survive-the-island' }) };
  throw new Error('Fetch inesperado no teste: ' + u);
};
const context = {
  console, URL, URLSearchParams, AbortController, setTimeout, clearTimeout,
  fetch: fakeFetch,
  localStorage: { getItem: () => null, setItem: () => {} },
  window: null
};
context.window = context;
context.MeepleExpertCore = core;
vm.createContext(context);
vm.runInContext(bridgeSource, context);
(async () => {
  const initial = await context.MeepleExplorerBridge.ready();
  assert.strictEqual(initial.catalogCount, 1, 'catalogo do Explorer deve carregar');
  assert.strictEqual(initial.workerCompatible, true, 'Worker dedicado deve ser reconhecido');
  const prepared = await context.MeepleExplorerBridge.ensureGame('survive-the-island');
  assert.strictEqual(prepared.remoteIndex, true, 'deve encontrar o índice R2 remoto');
  assert.strictEqual(games.has('survive-the-island'), true, 'jogo deve ser registrado no motor');
  const response = await context.MeepleExplorerBridge.search('Como funciona o barco?', { id: 'survive-the-island', title: 'Survive the Island' }, {
    status: 'partial', confidence: 'média', answer: '', hits: [{ manual: 'Manual', section: 'Barcos', text: 'Trecho local de teste.' }]
  }, []);
  assert.ok(postUrl.includes('meeple-expert-public-search.ewertonscosta.workers.dev'), 'consulta deve usar Worker do Explorer');
  assert.ok(postUrl.includes('meeple-expert-public-search.ewertonscosta.workers.dev'), 'consulta deve usar exclusivamente o Worker dedicado');
  assert.strictEqual(postPayload.gameId, 'survive-the-island', 'gameId deve seguir ao Worker');
  assert.strictEqual(postPayload.localEvidence.hits[0].section, 'Barcos', 'evidência local deve seguir ao Worker');
  assert.strictEqual(response.answer, 'Resposta simulada pelo Meeple Explorer.');
  assert.strictEqual(response.sources.length, 1);
  await context.MeepleExplorerBridge.search('Compare Catan vs Azul', { id: '', title: 'Catan × Azul', games: [{ id: 'catan', title: 'Catan' }, { id: 'azul', title: 'Azul' }] }, { status: 'partial', hits: [] }, []);
  assert.strictEqual(postPayload.comparisonGames.length, 2, 'comparação deve enviar os dois jogos identificados');
  assert.strictEqual(postPayload.comparisonGames[1].id, 'azul', 'segundo jogo deve seguir ao Worker');
  assert.ok(html.includes('meeple-explorer/js/bridge.js'), 'Library deve carregar o bridge');
  assert.ok(html.includes('requestMeepleExplorer('), 'chat deve chamar o Explorer');
  assert.ok(html.includes('mentionedExplorerGames(question)'), 'chat deve detectar comparação entre dois jogos citados');
  console.log('V293.5.18 Meeple Explorer: 12/12 verificações aprovadas.');
})().catch(error => { console.error(error); process.exit(1); });
