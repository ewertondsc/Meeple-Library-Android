// V293.5.24 — refinamento visual do Meeple AI
const fs=require('fs');
const html=fs.readFileSync('index.html','utf8');
const checks=[
 ['marca duplicada removida',!html.includes('class="ai-gemini-library-brand" aria-label="Meeple Library"')],
 ['ícone de chat presente',html.includes('ai-gemini-chat-mark')],
 ['menu hambúrguer presente',html.includes('M4 6h16M4 12h16M4 18h16')],
 ['acessibilidade do menu',html.includes('aria-label="Abrir menu do chat"')],
 ['estado vazio com frase Meeple',html.includes('A mesa está pronta.')],
 ['ícone de brilho do estado vazio removido',!html.includes('<span class="ai-gemini-empty-mark">✦</span>')],
 ['seletor de conversas preservado',html.includes('id="aiConversationSelect"')],
 ['nova conversa preservada',html.includes('id="aiNewConversation"')],
 ['excluir conversa preservado',html.includes('id="aiDeleteConversation"')],
 ['estilo de resposta preservado',html.includes('data-ai-mode="rules"')],
 ['versão atualizada',html.includes('V293.5.24 · Identidade Meeple refinada.')]
];
for(const [name,ok] of checks){if(!ok)throw new Error('Falhou: '+name);console.log('OK:',name)}
