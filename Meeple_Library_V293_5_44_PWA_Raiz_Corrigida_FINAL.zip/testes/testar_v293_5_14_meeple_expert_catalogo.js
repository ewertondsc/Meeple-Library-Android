const assert=require('assert');
global.window=global;
for(const p of [
 'meeple-expert/data/base-knowledge.js',
 'meeple-expert/data/synonyms-data.js',
 'meeple-expert/data/hobby-glossary.js',
 'meeple-expert/data/game-dossiers.js',
 'meeple-expert/data/game-guides.js',
 'meeple-expert/data/faq-bank.js',
 'meeple-expert/data/setup-facts.js',
 'meeple-expert/data/player-setup-matrix.js',
 'meeple-expert/data/rule-interactions.js',
 'meeple-expert/js/rule-interaction-engine.js',
 'meeple-expert/js/meeple-engine.js'
])require('../'+p);
const core=global.MeepleExpertCore;
assert(core&&core.gameCatalog instanceof Map,'Expert catalog not loaded');
const question='No Ticket to Ride: Europa, já completei meus bilhetes de destino. Posso comprar novos bilhetes durante a partida?';
const detected=core.detectGame(question,'todos',[]);
assert.equal(detected.id,'ticket-to-ride-europa','Ticket to Ride: Europa not identified from natural language');
const result=core.ask(question,detected.id,[]);
assert(result&&result.hits&&result.hits.length>=1,'Expert did not retrieve local passages');
assert(/bilhete|destino|compr/i.test(result.answer),'Expert answer does not address destination tickets');
console.log('PASS Expert recognizes Ticket to Ride: Europa while selector is Toda a coleção');
console.log(`PASS Expert retrieves ${result.hits.length} local evidence passages`);
console.log('PASS local answer addresses destination ticket purchase');
