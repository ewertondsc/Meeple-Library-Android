#!/usr/bin/env node
const fs=require('fs'),assert=require('assert').strict;
const app=fs.readFileSync('index.html','utf8'),sw=fs.readFileSync('sw.js','utf8');
const libFn=app.slice(app.indexOf('function renderLibrary(){'),app.indexOf('\nfunction renderFavorites()'));
const checks=[
 ['estados vazios distintos para biblioteca sem jogos e filtros sem resultados',libFn.includes('Sua coleção ainda está vazia.')&&libFn.includes('collectionResults')],
 ['filtros continuam visíveis quando existem jogos cadastrados',libFn.includes("${isEmpty?empty:controls+filters()+\`<div id=\"collectionResults\"></div>\`}")&&app.includes('applyCollectionTools')],
 ['CTA da biblioteca vazia abre gerenciador de módulos',app.includes('Adicionar meus jogos')&&app.includes('data-manage-modules')],
 ['favoritos vazios distinguem coleção vazia de lista sem favoritos',app.includes('Seus favoritos começam com sua coleção.')&&app.includes('Você ainda não tem favoritos.')],
 ['importação muda para a aba Biblioteca após instalar',/setTab\('biblioteca'\);const note=document\.createElement/.test(app)],
 ['navegação comunica a aba ativa por aria-current',app.includes("setAttribute('aria-current','page')")],
 ['estados vazios possuem layout responsivo dedicado',app.includes('meeple-v288-1-consolidation')&&app.includes('.collection-empty-panel')],
 ['cache do Service Worker versionado na V291',sw.includes('v293-5-18-meeple-explorer-integration-20261117')],
 ['versão V293 exibida no rodapé',app.includes('V293.5.18 · Meeple Explorer integrado ao chat.')],
 ['movimento reduzido continua respeitado',app.includes('prefers-reduced-motion:reduce')]
];
let fail=0;for(const [name,ok] of checks){console.log((ok?'✓ ':'✗ ')+name);if(!ok)fail++}
if(fail)process.exit(1);console.log(`\nRegressão V288.1 na base V291: ${checks.length} verificações aprovadas.`);
