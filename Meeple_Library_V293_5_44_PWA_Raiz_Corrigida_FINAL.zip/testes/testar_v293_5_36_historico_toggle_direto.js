// V293.5.36 — histórico abre pelo botão real sem depender de <details>
const fs=require('fs');const html=fs.readFileSync('index.html','utf8');
const header=html.slice(html.indexOf('<div class="ai-gemini-header-actions">'),html.indexOf('</header>',html.indexOf('<div class="ai-gemini-header-actions">')));
const handler=html.slice(html.indexOf("const historyQuick=$('#aiHistoryQuick')"),html.indexOf("const homePanel=$('#aiChat')"));
const deleteHandler=html.slice(html.indexOf("$('#aiDeleteConversation').addEventListener"),html.indexOf("const historyQuick=$('#aiHistoryQuick')"));
const checks=[
 ['um único botão de histórico', (header.match(/id="aiHistoryQuick"/g)||[]).length===1],
 ['painel de histórico identificado',header.includes('id="aiHistoryPanel"')],
 ['não depende de details',!header.includes('<details')&&!header.includes('</details>')],
 ['painel inicia oculto',/id="aiHistoryPanel"[^>]*hidden/.test(header)],
 ['botão controla a propriedade hidden',handler.includes('historyPanel.hidden=!open')&&handler.includes('setHistoryOpen(historyPanel.hidden)')],
 ['clique fora fecha',handler.includes('!historyPanel.contains(event.target)')&&handler.includes('setHistoryOpen(false)')],
 ['Escape fecha',handler.includes("event.key==='Escape'")],
 ['apagar histórico fecha painel',deleteHandler.includes("const panel=$('#aiHistoryPanel')")&&deleteHandler.includes('panel.hidden=true')],
 ['conteúdo só histórico e apagar',header.includes('<b>Histórico</b>')&&header.includes('Apagar histórico')&&!header.includes('Estilo da resposta')],
 ['não usa seletor ai-gemini-options',!handler.includes("$('.ai-gemini-options')")],
 ['CSS não deixa o painel preso a display:none',html.includes('#aiHistoryPanel[hidden]{display:none!important}')&&html.includes('#aiHistoryPanel{')],
 ['histórico preservado na versão atual',html.includes('V293.5.39 · Identidade visual Meeple AI')]
];
for(const [name,ok] of checks){if(!ok)throw new Error('Falhou: '+name);console.log('OK:',name)}
