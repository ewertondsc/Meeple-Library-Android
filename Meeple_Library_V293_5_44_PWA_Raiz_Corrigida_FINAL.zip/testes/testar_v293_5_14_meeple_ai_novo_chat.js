const fs=require('fs');
const html=fs.readFileSync('index.html','utf8');
const sw=fs.readFileSync('sw.js','utf8');
const checks=[
 ['botão Novo chat visível',/id="aiNewConversationTop"/.test(html)],
 ['interface mantém apenas o botão atual de novo chat',/id="aiNewConversationTop"/.test(html)&&!/id="aiNewConversation"/.test(html)],
 ['troca de aba IA inicia sessão limpa',/startNewAIConversation\(read\('meepleIASelectedGame',''\),false\)/.test(html)],
 ['histórico permanece selecionável',/id="aiConversationSelect"/.test(html)],
 ['seleção explícita do histórico preserva conversa',/aiMessages=item\.messages\.map/.test(html)],
 ['colagem atualiza estado do compositor',/addEventListener\('paste',\(\)=>setTimeout\(fitQuestion,0\)\)/.test(html)],
 ['envio pelo botão continua funcional',/sendButton\.addEventListener\('click'/.test(html)],
 ['Expert identifica jogos sem módulo da Biblioteca',/MeepleExpertCore\?\.detectGame/.test(html)&&/String\(scope\)\.startsWith\('expert:'\)/.test(html)],
 ['compositor está no fluxo normal',/\.ai-gemini-screen \.ai-gemini-composer\{[\s\S]*?position:relative!important/.test(html)],
 ['chat remove limite de altura legado',/\.ai-gemini-screen \.ai-gemini-chat\{[\s\S]*?max-height:none!important/.test(html)],
 ['cache do shell atualizado para V293.5.38',/v293-5-38-selected-game-priority-20261117/.test(sw)],
 ['motor Expert incluído',fs.existsSync('meeple-expert/js/meeple-engine.js')]
];let failed=0;for(const [name,ok] of checks){console.log(`${ok?'PASS':'FAIL'} ${name}`);if(!ok)failed++;}if(failed)process.exit(1);
