// V293.5.27 — layout estrutural da ficha em duas áreas
const fs=require('fs');
const html=fs.readFileSync('index.html','utf8');
const checks=[
 ['cabeçalho isolado',html.includes('class="detail-v293-topline"')],
 ['conteúdo editorial isolado',html.includes('class="detail-v293-content"')],
 ['descrição dentro do conteúdo',/detail-v293-content[\s\S]{0,250}detail-v259-description/.test(html)],
 ['links sociais dentro do conteúdo',/detail-v293-content[\s\S]{0,1200}detail-v259-community/.test(html)],
 ['editora dentro do conteúdo',/detail-v293-content[\s\S]{0,2000}detail-v259-publisher/.test(html)],
 ['conteúdo em flex vertical',html.includes('detailhero-v293-5-horizontal>.detail-v293-content{')],
 ['links em uma coluna em telas estreitas',html.includes('grid-template-columns:1fr!important;gap:8px!important')],
 ['ícones anteriores preservados',html.includes('navicon-chat')&&html.includes('navicon-tools')],
 ['versão atualizada',html.includes('V293.5.27 · Layout estrutural da ficha corrigido')]
];
for(const [name,ok] of checks){if(!ok)throw new Error('Falhou: '+name);console.log('OK:',name)}
