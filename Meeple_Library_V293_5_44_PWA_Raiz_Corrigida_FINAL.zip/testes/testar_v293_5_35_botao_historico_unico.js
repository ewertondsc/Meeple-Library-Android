// V293.5.35 — um único botão funcional para abrir/fechar o histórico
const fs=require('fs');const html=fs.readFileSync('index.html','utf8');
const header=html.slice(html.indexOf('<div class="ai-gemini-header-actions">'),html.indexOf('</header>',html.indexOf('<div class="ai-gemini-header-actions">')));
const handler=html.slice(html.indexOf("const historyQuick=$('#aiHistoryQuick')"),html.indexOf("const homePanel=$('#aiChat')"));
const checks=[
 ['um único botão de histórico', (header.match(/id="aiHistoryQuick"/g)||[]).length===1],
 ['ícone de três linhas removido',!header.includes('ai-gemini-menu-icon')&&!header.includes('<summary')],
 ['histórico abre e fecha pelo mesmo botão',handler.includes('historyMenu.open=!historyMenu.open')],
 ['estado acessível do botão',handler.includes("setAttribute('aria-expanded'")],
 ['fecha ao clicar fora',handler.includes('!historyMenu.contains(event.target)')],
 ['fecha com Escape',handler.includes("event.key==='Escape'")],
 ['painel contém apenas histórico e apagar histórico',header.includes('<b>Histórico</b>')&&header.includes('id="aiConversationSelect"')&&header.includes('Apagar histórico')&&!header.includes('Estilo da resposta')],
 ['novo chat continua no cabeçalho separado',html.includes('id="aiNewConversationTop"')],
 ['versão atualizada',html.includes('V293.5.35 · Histórico com botão único')]
];
for(const [name,ok] of checks){if(!ok)throw new Error('Falhou: '+name);console.log('OK:',name)}
