// V293.5.20 — compositor compacto
const fs = require('fs');
const html = fs.readFileSync('index.html','utf8');
const css = html.match(/<style id="meeple-ai-compact-composer-v520">([\s\S]*?)<\/style>/);
if (!css) throw new Error('CSS do compositor compacto ausente');
for (const token of ['height:38px!important','min-height:38px!important','width:36px!important','height:36px!important','@media(max-width:600px)','height:34px!important']) {
  if (!css[1].includes(token)) throw new Error('Regra esperada ausente: '+token);
}
if (!html.includes('V293.5.20 · Compositor compacto do Meeple AI.')) throw new Error('Buildstamp não atualizado');
console.log('OK: compositor compacto desktop/mobile e buildstamp');
