// V293.5.31 — grid plano: descrição e botões voltam a ocupar a largura completa
const fs=require('fs');
const html=fs.readFileSync('index.html','utf8');
const css=html.match(/<style id="v293-5-31-flat-detail-grid-repair">([\s\S]*?)<\/style>/);
if(!css)throw new Error('CSS de correção não encontrado');
const s=css[1];
const rules=[
 ['capa na primeira coluna',s.includes('>.detail-cover-column{')&&s.includes('grid-column:1!important;grid-row:1!important')],
 ['identidade na segunda coluna',s.includes('>.detail-identity{')&&s.includes('grid-column:2!important;grid-row:1!important')],
 ['descrição atravessa as duas colunas',s.includes('>.detail-v259-description{')&&s.includes('grid-column:1/-1!important;grid-row:2!important')],
 ['botões atravessam as duas colunas',s.includes('>.detail-v259-community{')&&s.includes('grid-column:1/-1!important;grid-row:3!important')],
 ['BGG e Ludopedia em duas colunas',s.includes('grid-template-columns:repeat(2,minmax(0,1fr))!important')],
 ['editora atravessa as duas colunas',s.includes('>.detail-v259-publisher{')&&s.includes('grid-column:1/-1!important;grid-row:4!important')],
 ['descrição sem borda e fundo',s.includes('border:0!important;border-radius:0!important;background:transparent!important;box-shadow:none!important')],
 ['ícones de navegação mantidos',html.includes('navicon-chat')&&html.includes('navicon-tools')],
 ['versão atualizada',html.includes('V293.5.31 · Descrição e cartões em largura total')]
];
for(const [name,ok] of rules){if(!ok)throw new Error('Falhou: '+name);console.log('OK:',name)}
