const fs=require('fs'),vm=require('vm');
const app=fs.readFileSync('index.html','utf8'),sw=fs.readFileSync('sw.js','utf8');
const start=app.indexOf('function renderHome(){'),end=app.indexOf('function collectionSearchText(g){',start);
const home=app.slice(start,end),styleStart=app.indexOf('<style id="v293-2-premium-home">'),styleEnd=app.indexOf('</style>',styleStart),css=app.slice(styleStart,styleEnd);
const checks=[];const check=(n,v)=>checks.push([n,!!v]);
check('retomada continua sem percentual nem barra de progresso',home.includes('CONTINUAR DE ONDE PAROU')&&!home.includes('% concluído')&&!home.includes('home-premium-progress'));
check('estante conserva todos os jogos exceto o jogo em retomada',home.includes('library.filter(g=>g.id!==resumeId)')&&!home.includes('.slice(0,3)'));
check('indicador discreto está logo abaixo da faixa de capas',home.includes('home-premium-shelf-indicator')&&home.indexOf('home-premium-shelf-indicator')>home.indexOf('home-premium-shelf-row'));
check('indicador tem trilho e marcador móvel',css.includes('.home-premium-shelf-indicator{')&&css.includes('.home-premium-shelf-thumb{'));
check('indicador é ocultado quando não há rolagem',home.includes('indicator.hidden=max<3')&&css.includes('.home-premium-shelf-indicator[hidden]'));
check('marcador acompanha scrollLeft e calcula proporção',home.includes('row.addEventListener(\'scroll\',update')&&home.includes('row.scrollLeft/max')&&home.includes('thumb.style.transform'));
check('rolagem horizontal usa momentum e encaixe suave',css.includes('-webkit-overflow-scrolling:touch')&&css.includes('scroll-snap-type:x mandatory')&&css.includes('scroll-behavior:smooth'));
check('capas recebem realce ao pressionar',home.includes("button.classList.add('is-pressed')")&&css.includes('.home-premium-shelf-game:active img'));
check('o destaque do toque é removido ao soltar/cancelar/sair',home.includes("button.addEventListener('pointerup',release)")&&home.includes("button.addEventListener('pointercancel',release)")&&home.includes("button.addEventListener('pointerleave',release)"));
check('foco por teclado tem indicação visual',css.includes('.home-premium-shelf-game:focus-visible img'));
check('capa continua abrindo ficha do jogo',home.includes('data-detail="${esc(g.id)}"'));
check('cache do service worker foi atualizado',sw.includes('v293-5-18-meeple-explorer-integration-20261117'));
check('versão aparece no buildstamp',app.includes('V293.5.18 · Meeple Explorer integrado ao chat.'));

// Run renderHome against seven test games and a mocked browser shelf to exercise the live indicator updater.
const view={innerHTML:''};
const games=[
{id:'things',titulo:'Things in Rings',capa:'cover.jpg',manuais:[{nome:'Manual completo ilustrado',arquivo:'manual.html'}]},
{id:'azul',titulo:'Azul',capa:'cover.jpg',manuais:[]},
{id:'carcassonne',titulo:'Carcassonne',capa:'cover.jpg',manuais:[]},
{id:'catan',titulo:'Catan',capa:'cover.jpg',manuais:[]},
{id:'root',titulo:'Root',capa:'cover.jpg',manuais:[]},
{id:'everdell',titulo:'Everdell',capa:'cover.jpg',manuais:[]},
{id:'dewan',titulo:'Dewan',capa:'cover.jpg',manuais:[]}
];
const thumb={style:{}};
const indicator={hidden:false,clientWidth:48};
let scrollHandler=null, pointerHandlers={};
const row={scrollWidth:600,clientWidth:300,scrollLeft:150,querySelectorAll:()=>[{classList:{add(){},remove(){}},addEventListener:(n,f)=>{pointerHandlers[n]=f}}],addEventListener:(n,f)=>{if(n==='scroll')scrollHandler=f}};
const ctx={library:games,favorites:new Set(['root']),history:[{id:'things',nome:'Manual completo ilustrado'}],document:{body:{classList:{add(){}}}},window:{},ResizeObserver:class{constructor(fn){this.fn=fn}observe(){this.fn()}disconnect(){}},$:sel=>sel==='#view'?view:sel==='#view .home-premium-shelf-row'?row:sel==='#view .home-premium-shelf-indicator'?indicator:sel==='#view .home-premium-shelf-thumb'?thumb:null,esc:x=>String(x??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c])),cover:g=>'manuais/'+g.id+'/'+g.capa,manualUrl:(g,m)=>'manuais/'+g.id+'/'+m.arquivo};
vm.createContext(ctx);vm.runInContext(home,ctx);vm.runInContext('renderHome()',ctx);
let html=view.innerHTML;
check('render real mantém retomada sem indicador de leitura',html.includes('Things in Rings')&&!html.includes('100% concluído')&&!html.includes('home-premium-progress'));
check('render real cria indicador abaixo das capas',html.indexOf('home-premium-shelf-indicator')>html.indexOf('home-premium-shelf-row'));
check('render real mostra todos os seis jogos adicionais', (html.match(/class="home-premium-shelf-game"/g)||[]).length===6);
check('indicador se mostra quando existe conteúdo fora da tela',indicator.hidden===false);
check('indicador calcula largura proporcional à área visível',parseFloat(thumb.style.width)>0&&parseFloat(thumb.style.width)<48);
check('indicador atualiza sua posição ao rolar',typeof scrollHandler==='function');
if(scrollHandler){row.scrollLeft=300;scrollHandler();check('posição do indicador avança com a rolagem',parseFloat(thumb.style.transform.match(/translateX\(([-\d.]+)px\)/)?.[1]||0)>0)}
check('feedback de toque possui eventos de pressionar e soltar',!!pointerHandlers.pointerdown&&!!pointerHandlers.pointerup&&!!pointerHandlers.pointercancel&&!!pointerHandlers.pointerleave);
vm.runInContext('history=[];renderHome()',ctx);html=view.innerHTML;
check('sem histórico, todos os jogos continuam na estante',!html.includes('home-premium-resume')&&(html.match(/class="home-premium-shelf-game"/g)||[]).length===7);
vm.runInContext('library=[];favorites=new Set();renderHome()',ctx);html=view.innerHTML;
check('coleção vazia mantém ação de instalar jogos',html.includes('Adicionar meus jogos')&&!html.includes('home-premium-shelf'));
let fail=0;for(const [n,v] of checks){console.log((v?'✓ ':'✗ ')+n);if(!v)fail++}
if(fail)process.exit(1);console.log(`\nV293.2.3: ${checks.length} verificações aprovadas.`);
