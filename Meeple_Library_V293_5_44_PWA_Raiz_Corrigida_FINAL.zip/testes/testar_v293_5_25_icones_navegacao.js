// V293.5.25 — ícones da navegação principal
const fs=require('fs');
const html=fs.readFileSync('index.html','utf8');
const checks=[
 ['Ferramentas sem brilho Gemini',!html.includes('data-tab="hub"><span class="navicon">✦</span>')],
 ['Ferramentas com engrenagem',html.includes('navicon-tools') && html.includes('data-tab="hub"')],
 ['Meeple IA com o emblema oficial',html.includes('navicon-chat') && html.includes('data-tab="ia"') && /navicon-chat[^>]*>[\s\S]*?meeple-ai-emblem\.png/.test(html)],
 ['mesmo emblema oficial no cabeçalho e na navegação',html.includes('ai-gemini-chat-mark') && html.includes('navicon-chat') && /ai-gemini-chat-mark[^>]*>[\s\S]*?meeple-ai-emblem\.png/.test(html)],
 ['rótulos de navegação preservados',html.includes('>Ferramentas</button>') && html.includes('>Meeple IA</button>')],
 ['versão atualizada',html.includes('V293.5.39 · Identidade visual Meeple AI')]
];
for(const [name,ok] of checks){if(!ok)throw new Error('Falhou: '+name);console.log('OK:',name)}
