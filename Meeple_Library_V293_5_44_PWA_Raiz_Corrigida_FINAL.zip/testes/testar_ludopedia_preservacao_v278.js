const fs=require('fs');
const html=fs.readFileSync('index.html','utf8');
const fn=html.slice(html.indexOf('function renderCommunityPage(id,source){'),html.indexOf('\nfunction manualsForDisplay(g){'));
const checks=[
 ['Resumo da ficha removido',!fn.includes('Resumo da ficha')],
 ['bloco Sobre o jogo removido',!fn.includes('if(d.sobre)')],
 ['lista Componentes removida',!fn.includes('d.componentes')],
 ['Avaliações da Ludopedia preservadas',fn.includes('Avaliações da Ludopedia')],
 ['Visão geral da Ludopedia preservada',fn.includes('Visão geral da Ludopedia')],
 ['Como é jogar preservado',fn.includes('Como é jogar')],
 ['Prêmios e reconhecimentos preservados',fn.includes('Prêmios e reconhecimentos')],
 ['Versões digitais preservadas',fn.includes('Versões digitais')],
 ['pontos de atenção preservados',fn.includes('d.pontosAtencao')],
 ['layout refinado sem remover conteúdo',html.includes('v278-ludopedia-layout-tune')],
 ['cache atualizado',fs.readFileSync('sw.js','utf8').includes('v282-community-direct-external-links')]
];
let fail=0;for(const [n,ok] of checks){console.log((ok?'✓ ':'✗ ')+n);if(!ok)fail++}
if(fail)process.exit(1);console.log(`\nLudopedia V278 OK: ${checks.length} verificações.`);
