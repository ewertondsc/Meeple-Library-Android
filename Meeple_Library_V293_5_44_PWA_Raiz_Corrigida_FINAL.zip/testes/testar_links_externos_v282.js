const fs=require('fs');
const html=fs.readFileSync('index.html','utf8');
const lib=JSON.parse(fs.readFileSync('library.json','utf8'));
const azul=lib.find(g=>g.id==='azul');
const detail=html;
const checks=[
 ['cartão BGG é link direto externo',detail.includes('href="${esc(g.bggUrl)}"')&&detail.includes('Abrir no BoardGameGeek')],
 ['cartão Ludopedia é link direto externo',detail.includes('href="${esc(g.ludopediaUrl)}"')&&detail.includes('Abrir na Ludopedia')],
 ['ambos navegam na mesma aba',detail.includes('target="_self"')],
 ['endereço BGG do Azul está cadastrado',azul?.bggUrl==='https://boardgamegeek.com/boardgame/230802/azul'],
 ['endereço Ludopedia do Azul está cadastrado',azul?.ludopediaUrl==='https://ludopedia.com.br/jogo/azul'],
 ['cartões não chamam páginas internas',!html.includes('renderCommunityPage(')&&!html.includes('openLudopediaCommunity(')],
 ['tratamento antigo de clique interno removido',!html.includes('[data-community]')],
 ['cartões mantêm apresentação visual',html.includes('v282-direct-community-links')],
 ['cache atualizado',fs.readFileSync('sw.js','utf8').includes('v293-5-18-meeple-explorer-integration-20261117')]
];
let fail=0;for(const [n,ok] of checks){console.log((ok?'✓ ':'✗ ')+n);if(!ok)fail++}
if(fail)process.exit(1);console.log(`\nLinks externos V282 OK: ${checks.length} verificações.`);
