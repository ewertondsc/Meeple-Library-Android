#!/usr/bin/env python3
"""Testa o build.py de verdade: copia o projeto para uma pasta temporária, provoca defeitos
(um por vez) e confere se o build avisa/aborta e se NADA é alterado quando aborta.
Uso: python3 testes/testar_build.py"""
import os,sys,json,shutil,hashlib,tempfile,subprocess,contextlib,re
from pathlib import Path
R=Path(__file__).resolve().parent.parent
tmp=Path(tempfile.mkdtemp(prefix='build-teste-'));T=tmp/'app'
shutil.copytree(R,T,ignore=shutil.ignore_patterns('testes','testes-ia','.git','node_modules','relatorio-ia.md'))
ok=fail=0
def rodar(*a):
    p=subprocess.run([sys.executable,'build.py',*a],cwd=T,capture_output=True,text=True);return p.returncode,p.stdout+p.stderr
def arvore():
    h=hashlib.md5()
    for f in sorted(T.rglob('*')):
        if f.is_file(): h.update(str(f.relative_to(T)).encode());h.update(f.read_bytes())
    return h.hexdigest()
@contextlib.contextmanager
def mexer(rel,fn=None,remover=False):
    p=T/rel;orig=p.read_bytes() if p.exists() and p.is_file() else None
    try:
        if remover: p.unlink()
        elif fn: fn(p)
        yield
    finally:
        if orig is not None: p.write_bytes(orig)
        elif p.exists() and p.is_file(): p.unlink()
def meta(rel,mod):
    def f(p):
        m=json.loads(p.read_text(encoding='utf8'));mod(m);p.write_text(json.dumps(m,ensure_ascii=False,indent=1),encoding='utf8')
    return f
def texto(fn):
    return lambda p:p.write_text(fn(p.read_text(encoding='utf8')),encoding='utf8')
def T_(nome,cond,detalhe=''):
    global ok,fail
    if cond: ok+=1;print('✓',nome)
    else: fail+=1;print('✗',nome,'\n     ',detalhe[-400:].replace('\n','\n      '))
def aborta(nome,esperado,ctx,args=()):
    """o build deve abortar (saída 1), citar o problema e deixar TODOS os arquivos intactos"""
    with ctx:
        antes=arvore();c,o=rodar(*args);intacto=arvore()
    T_(nome,c==1 and all(re.search(e,o) for e in esperado) and 'NADA foi alterado' in o,'saída %s\n%s'%(c,o))
    T_(nome+' — nada foi alterado',intacto==antes,'a árvore mudou')
def avisa(nome,esperado,ctx):
    with ctx: c,o=rodar()
    T_(nome,c==0 and all(re.search(e,o) for e in esperado),'saída %s\n%s'%(c,o))
M=lambda g:'manuais/%s/meta.json'%g
# ---- caminho feliz ----
c,o=rodar();T_('projeto atual passa no build',c==0 and 'Pronto' in o,o)
h1=arvore();c,o=rodar();T_('rodar de novo não muda nada (idempotente)',c==0 and arvore()==h1)
a=arvore();c,o=rodar('--verificar');T_('--verificar não altera nada e responde OK',c==0 and 'Verificação OK' in o and arvore()==a,o)
fj=json.loads((T/'files.json').read_text());todos=fj['core']+[x for v in fj['games'].values() for x in v]
T_('todo arquivo de files.json existe',all(x=='./' or (T/x).exists() for x in todos))
T_('library.json tem todos os jogos das pastas',len(json.loads((T/'library.json').read_text(encoding='utf8')))==len(list((T/'manuais').glob('*/meta.json'))))
# ---- jogo sumiu / sem meta ----
aborta('pasta de jogo sem meta.json',[r'não tem meta\.json',r'sumiu'],mexer(M('azul'),remover=True))
def apagar_pasta():
    @contextlib.contextmanager
    def f():
        bk=tmp/'bk';shutil.copytree(T/'manuais/finca',bk);shutil.rmtree(T/'manuais/finca')
        try: yield
        finally: shutil.copytree(bk,T/'manuais/finca');shutil.rmtree(bk)
    return f()
aborta('jogo que sumiu da biblioteca é barrado',[r'"finca" estava na biblioteca e sumiu'],apagar_pasta())
with apagar_pasta(): c,o=rodar('--permitir-remover');n=len(json.loads((T/'library.json').read_text(encoding='utf8')));restantes=len(list((T/'manuais').glob('*/meta.json')))
T_('--permitir-remover aceita a saída proposital',c==0 and n==restantes,o)
rodar()  # restaura library.json com todos os jogos
# ---- imagens e arquivos ----
img=next((T/'manuais/azul').rglob('*.jpg')) if list((T/'manuais/azul').rglob('img/*.jpg')) else None
alvo=re.search(r'src="(img/[^"]+)"',(T/'manuais/azul/completo.html').read_text(encoding='utf8')).group(1)
aborta('imagem quebrada no manual',[r'arquivo referenciado não existe: '+re.escape(alvo)],mexer('manuais/azul/'+alvo,remover=True))
aborta('capa ausente',[r'a capa não existe'],mexer('manuais/catan/cover.jpg',remover=True))
aborta('capa corrompida',[r'não é uma imagem válida'],mexer('manuais/catan/cover.jpg',lambda p:p.write_bytes(b'lixo'*50)))
aborta('imagem do manual corrompida',[r'imagem ilegível ou corrompida: '+re.escape(alvo)],mexer('manuais/azul/'+alvo,lambda p:p.write_bytes(b'lixo'*50)))
# ---- ficha ----
aborta('ficha rápida sem dicas',[r'sem "dicas"'],mexer(M('azul'),meta(M('azul'),lambda m:m['fichaRapida'].__setitem__('dicas',[]))))
aborta('fonte de duração inválida',[r'duracaoFonte deve ser um de'],mexer(M('azul'),meta(M('azul'),lambda m:m.__setitem__('duracaoFonte','chute'))))
aborta('mínimo de jogadores maior que o máximo',[r'valores incoerentes'],mexer(M('azul'),meta(M('azul'),lambda m:m.__setitem__('jogadoresMin',9))))
aborta('complexidade fora de 1 a 5',[r'valores incoerentes'],mexer(M('azul'),meta(M('azul'),lambda m:m.__setitem__('complexidadeNivel',7))))
aborta('título repetido',[r'título repetido'],mexer(M('azul'),meta(M('azul'),lambda m:m.__setitem__('titulo',json.loads((T/M('catan')).read_text(encoding='utf8'))['titulo']))))
aborta('link de curiosidade inválido',[r'não é um link http'],mexer(M('azul'),meta(M('azul'),lambda m:m['curiosidades'][0].__setitem__('fonte','sem-link'))))
# ---- o caso "perdeu dados em silêncio" ----
aborta('campo que existia na versão anterior e sumiu do meta.json é barrado',[r'existiam no library\.json anterior e sumiram: .*curiosidades'],mexer(M('azul'),meta(M('azul'),lambda m:m.pop('curiosidades'))))
# ---- HTML do manual ----
aborta('<details> desbalanceado',[r'desbalanceadas'],mexer('manuais/azul/completo.html',texto(lambda t:t.replace('</body>','<details></body>',1))))
aborta('manual sem capítulos (busca/IA não indexariam)',[r'sem capítulos'],mexer('manuais/azul/completo.html',texto(lambda t:t.replace('class="topic','class="tpc'))))
aborta('ids repetidos no manual',[r'ids repetidos: chapter-1'],mexer('manuais/azul/completo.html',texto(lambda t:t.replace('id="chapter-2"','id="chapter-1"',1))))
aborta('manual listado que não existe',[r'o manual "completo\.html" não existe'],mexer('manuais/azul/completo.html',remover=True))
# ---- consulta rápida ----
aborta('consulta rápida: tipo de seção inválido',[r'tipo inválido'],mexer(M('azul'),meta(M('azul'),lambda m:m['mesa']['secoes'][0].__setitem__('tipo','xyz'))))
aborta('consulta rápida: tabela com colunas inconsistentes',[r'colunas inconsistentes'],mexer(M('azul'),meta(M('azul'),lambda m:[s for s in m['mesa']['secoes'] if s['tipo']=='tabela'][0]['linhas'].append(['só uma']))))
aborta('consulta rápida: seção sem itens',[r'está sem itens'],mexer(M('azul'),meta(M('azul'),lambda m:m['mesa']['secoes'][0].__setitem__('itens',[]))))
# ---- avisos (não impedem o build) ----
avisa('capa PNG com extensão .jpg gera aviso',[r'na verdade PNG'],mexer('manuais/catan/cover.jpg',lambda p:__import__('PIL.Image',fromlist=['x']).open(p).save(p,'PNG')))
avisa('imagem que nenhum manual usa gera aviso',[r'img/solta\.jpg'],mexer('manuais/azul/img/solta.jpg',lambda p:p.write_bytes((T/'manuais/azul/cover.jpg').read_bytes())))
avisa('HTML na pasta fora do meta.json gera aviso',[r'extra\.html está na pasta'],mexer('manuais/azul/extra.html',lambda p:p.write_text('<html></html>')))
avisa('link "Ver no manual" sem resultado gera aviso',[r'busca "zzzinexistente"'],mexer(M('azul'),meta(M('azul'),lambda m:m['mesa']['secoes'][0].__setitem__('busca','zzzinexistente'))))
avisa('imagem sem alt gera aviso',[r'sem texto alternativo'],mexer('manuais/azul/completo.html',texto(lambda t:t.replace('<img ','<img data-x="1" ',1).replace('alt="','data-alt="',1))))
# ---- versões do cache ----
def hashes(): s=(T/'sw.js').read_text();return re.search(r"BUILD='(\w+)'",s).group(1),re.search(r"IMG='(\w+)'",s).group(1)
rodar();b0,i0=hashes()
with mexer('manuais/azul/completo.html',texto(lambda t:t.replace('</body>','<!--x--></body>',1))): rodar();b1,i1=hashes()
T_('mudar o texto muda BUILD e não muda IMG',b1!=b0 and i1==i0,'%s %s | %s %s'%(b0,i0,b1,i1))
with mexer('manuais/azul/'+alvo,lambda p:p.write_bytes(p.read_bytes()+b'\0')): rodar();b2,i2=hashes()
T_('mudar uma imagem muda IMG',i2!=i0,'%s %s'%(i0,i2))
rodar()
shutil.rmtree(tmp,ignore_errors=True)
print('\n%s'%('%d falha(s), %d ok'%(fail,ok) if fail else 'Build OK: %d verificações'%ok));sys.exit(1 if fail else 0)
