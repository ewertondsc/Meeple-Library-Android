// V97.2 — sinônimos contam como "termo encontrado" no filtro de relevância; expansão do TTR Europa marcada.
const {spawnSync}=require('child_process'),assert=require('assert'),fs=require('fs');
let n=0;const T=(nome,f)=>{f();n++;console.log('✓ '+nome)};
const html=fs.readFileSync('index.html','utf8'),lib=JSON.parse(fs.readFileSync('library.json','utf8'));
T('rankPassages usa synOf/hitT (sinônimos no filtro enough)',()=>assert.ok(html.includes('synOf')&&html.includes('hitT')&&html.includes('hitTitle')));
T('expansão 1912 do TTR Europa marcada no library.json',()=>assert.ok(lib.find(g=>g.id==='ticket-to-ride-europa').manuais.find(m=>m.arquivo==='expansao-1912.html').expansao===true));
const r=spawnSync('node',['testes-ia/testar_busca.js'],{encoding:'utf8'});
T('busca offline: 100% no top 7 e sem falhas',()=>{assert.strictEqual(r.status,0,r.stdout.slice(-400));assert.ok(/top7 (\d+) \(100%\)/.test(r.stdout))});
console.log('\nBusca V97.2 OK: '+n+' verificações');
