import json, pathlib, subprocess
from playwright.sync_api import sync_playwright
root=pathlib.Path(__file__).resolve().parents[1]
html=(root/'index.html').read_text(encoding='utf-8')
node=r'''const fs=require('fs');const s=fs.readFileSync('index.html','utf8');
const a=s.indexOf('const nativeReaderScripts=')+'const nativeReaderScripts='.length;
const b=s.indexOf('];;\n  // Botão Voltar',a)+1;
const arr=Function('return '+s.slice(a,b))();
let pushes=[],tail=s.slice(b);
for(const m of tail.matchAll(/nativeReaderScripts\.push\(("(?:\\.|[^"\\])*")\);/g)){pushes.push(JSON.parse(m[1]));}
function tpl(key){const at=s.indexOf(key);if(at<0)throw Error('missing '+key);const st=s.indexOf('`',at)+1;let en=s.indexOf('`;',st);if(en<0)throw Error('unterminated '+key);return s.slice(st,en)}
const css=tpl('canonicalReaderStyle.textContent=');
const css2=tpl('meepleMobileStandard.textContent=');
fs.writeFileSync('/tmp/v2922_reader_test.json',JSON.stringify({arr,pushes,css,css2}));
'''
subprocess.run(['node','-e',node],cwd=root,check=True)
data=json.loads(pathlib.Path('/tmp/v2922_reader_test.json').read_text())
arr=data['arr']; pushes=data['pushes']; css=data['css']; css2=data['css2']
assert len(arr)==10,len(arr)
assert not arr[0] and not arr[9]
font_scripts=[x for x in pushes if "readerFontSize" in x]
header_scripts=[x for x in pushes if "meeple-reader-fixed-spacer" in x]
assert len(font_scripts)==1,len(font_scripts)
assert len(header_scripts)==1,len(header_scripts)
# Build the actual reader shape produced by the app before native scripts are run.
fixture=f'''<!doctype html><html lang="pt-BR"><head><meta name="viewport" content="width=device-width,initial-scale=1,viewport-fit=cover"><style>
{css}\n{css2}
</style></head><body>
<div class="meeple-reader-fixed-header" role="banner"><div class="meeple-context-heading"><a class="meeple-context-back" href="#">‹</a><div><span>BIBLIOTECA</span><b>Jogo de Teste</b></div></div>
<div class="reader-tools" role="toolbar"><div class="reader-actions"><button type="button" id="goTop">↑</button></div><div class="reader-font-controls"><button type="button" id="fontDown">A−</button><button type="button" id="fontUp">A+</button></div></div></div>
<div class="meeple-reader-fixed-spacer" aria-hidden="true"></div>
<main id="c" class="meeple-reader-content"><div class="reader-title-row"><h1>Manual de Teste</h1></div><div class="bar"><input id="q" type="search" placeholder="Buscar no manual"></div>
<details class="topic" id="cap-setup" open><summary class="topic-summary">Preparação da partida</summary><div class="topic-body"><p>Organize os componentes e prepare a mesa para todos os jogadores.</p><p>A duração estimada da partida é de trinta minutos.</p><div class="meeple-manual-callout"><span>Importante: a regra de preparação deve ser seguida.</span></div></div></details>
<details class="topic" id="cap-turn"><summary class="topic-summary">Turno dos jogadores</summary><div class="topic-body"><p>Durante seu turno, escolha uma ação e resolva seus efeitos.</p><p>Os jogadores alternam turnos até o final da rodada.</p></div></details>
<details class="topic" id="cap-end"><summary class="topic-summary">Fim da partida</summary><div class="topic-body"><p>A partida termina quando a condição final for alcançada.</p></div></details>
</main></body></html>'''
with sync_playwright() as p:
    browser=p.chromium.launch(executable_path='/usr/bin/chromium',headless=True,args=['--no-sandbox'])
    context=browser.new_context(viewport={'width':390,'height':844},device_scale_factor=2,is_mobile=True,has_touch=True)
    page=context.new_page(); errors=[]
    page.on('pageerror',lambda e:errors.append(str(e)))
    page.set_content(fixture,wait_until='domcontentloaded')
    # Old native scripts: progress, search, image lightbox, on-demand original index, rule navigation, legacy cleanup.
    for i in [2,3,4,5,6,7,8]:
        if arr[i]: page.add_script_tag(content=arr[i])
    page.add_script_tag(content=font_scripts[0])
    page.add_script_tag(content=header_scripts[0])
    page.wait_for_timeout(180)
    # Fonts must directly change real text-bearing nodes and remain visible beside the action row.
    before=page.locator('#cap-setup .topic-body p').first.evaluate('(e)=>getComputedStyle(e).fontSize')
    upbox=page.locator('#fontUp').bounding_box();page.touchscreen.tap(upbox['x']+upbox['width']/2,upbox['y']+upbox['height']/2);page.wait_for_timeout(40)
    larger=page.locator('#cap-setup .topic-body p').first.evaluate('(e)=>getComputedStyle(e).fontSize')
    downbox=page.locator('#fontDown').bounding_box();page.touchscreen.tap(downbox['x']+downbox['width']/2,downbox['y']+downbox['height']/2);page.wait_for_timeout(40)
    restored=page.locator('#cap-setup .topic-body p').first.evaluate('(e)=>getComputedStyle(e).fontSize')
    assert (before,larger,restored)==('16px','17px','16px'),(before,larger,restored)
    assert page.locator('.reader-font-controls').evaluate('(e)=>e.parentElement.classList.contains("reader-tools")')
    # Index panel must not be present as a new always-on block; old panel remains hidden until button press.
    assert page.locator('#meepleReaderIndexPanel').count()==0
    assert page.locator('#meepleChapterPanel').count()==1
    assert page.locator('#meepleChapterPanel').evaluate('(e)=>getComputedStyle(e).display')=='none'
    page.locator('[data-reader-action="index"]').first.click();page.wait_for_timeout(60)
    assert page.locator('#meepleChapterPanel.open').count()==1
    assert page.locator('#meepleChapterTabs').count()==0  # original panel tabs keep original data-chapter-tab hooks
    assert page.locator('#meepleChapterPanel [data-chapter-tab]').count()==3
    assert page.locator('#meepleChapterPanel .meeple-chapter-link').count()==3
    page.locator('#meepleChapterPanel [data-chapter-tab="last"]').click()
    # Close modal through original close control.
    page.locator('#meepleChapterPanel .meeple-chapter-close').click()
    assert page.locator('#meepleChapterPanel.open').count()==0
    # Manual search still works, accent-insensitive.
    page.locator('#q').fill('duracao');page.wait_for_timeout(230)
    assert page.locator('#cap-setup').evaluate('(e)=>!e.classList.contains("hide")')
    assert page.locator('#cap-turn').evaluate('(e)=>e.classList.contains("hide")')
    assert page.locator('mark.meeple-search-match').count()>=1
    page.locator('#q').fill('');page.wait_for_timeout(180)
    # The full app toolbar stays at viewport top after scrolling; spacer reserves its exact height.
    page.evaluate('window.scrollTo(0,document.body.scrollHeight)');page.wait_for_timeout(120)
    top=page.locator('.meeple-reader-fixed-header').evaluate('(e)=>e.getBoundingClientRect().top')
    header_height=page.locator('.meeple-reader-fixed-header').evaluate('(e)=>Math.ceil(e.getBoundingClientRect().height)')
    spacer_height=page.locator('.meeple-reader-fixed-spacer').evaluate('(e)=>Math.ceil(e.getBoundingClientRect().height)')
    assert abs(top)<=1,top
    assert abs(header_height-spacer_height)<=1,(header_height,spacer_height)
    assert page.locator('#fontUp').is_visible() and page.locator('#fontDown').is_visible()
    page.locator('[data-reader-action="index"]').first.click()
    assert page.locator('#meepleChapterPanel.open').count()==1
    page.locator('#meepleChapterPanel .meeple-chapter-close').click()
    assert page.locator('.meeple-context-back').is_visible()
    assert not errors,errors
    print('PASS V292.2 mobile 390x844: toque real em A+/A− altera fonte 16→17→16px; índice clássico só abre ao tocar e preserva abas; busca sem acento; barra fixa a 0px e Índice/Voltar acessíveis mesmo após rolagem; espaçador compensa altura; sem erros JS.')
    browser.close()
