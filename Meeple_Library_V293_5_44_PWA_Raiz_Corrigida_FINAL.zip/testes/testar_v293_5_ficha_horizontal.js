const fs=require('fs'),vm=require('vm');
const app=fs.readFileSync('index.html','utf8'),sw=fs.readFileSync('sw.js','utf8');
const checks=[];const check=(name,ok)=>checks.push([name,!!ok]);
const styleAt=app.lastIndexOf('<style id="v293-5-ficha-horizontal">');
const styleEnd=app.indexOf('</style>',styleAt);
const css=styleAt>=0&&styleEnd>styleAt?app.slice(styleAt,styleEnd):'';
check('build stamp identifies V293.5 horizontal premium detail',app.includes("V293.5.18 · Meeple Explorer integrado ao chat."));
check('service worker cache key is unique to V293.5',sw.includes("v293-5-18-meeple-explorer-integration-20261117"));
check('detail header uses the horizontal hero scope',app.includes('detailhero detailhero-premium detailhero-v260 detailhero-v293-5-horizontal'));
check('horizontal detail stylesheet remains intact alongside the dedicated Meeple AI stylesheet',styleAt>0&&css.length>0&&styleEnd>styleAt&&app.includes('<style id="meeple-ai-v293-5-13-gemini-style">'));
check('horizontal grid puts cover and identity in separate columns',css.includes('grid-template-columns:minmax(104px,34%) minmax(0,1fr)!important')&&css.includes('>.detail-cover-column{')&&css.includes('>.detail-identity{'));
check('cover and identity occupy the first row',css.includes('grid-column:1!important;grid-row:1!important')&&css.includes('grid-column:2!important;grid-row:1!important'));
check('description spans the full width below the first row',css.includes('>.detail-v259-description{')&&css.includes('grid-column:1/-1!important')&&css.includes('grid-row:2!important'));
check('BGG and Ludopedia are large balanced two-column cards',css.includes('>.detail-v259-community{')&&css.includes('grid-template-columns:repeat(2,minmax(0,1fr))!important')&&css.includes('min-height:74px!important'));
check('publisher has its own row and compact non-full-width link',css.includes('>.detail-v259-publisher{')&&css.includes('width:auto!important'));
check('very narrow screens have a readable vertical fallback',css.includes('@media(max-width:340px)')&&css.includes('grid-template-columns:minmax(0,1fr)!important'));
check('tablet and desktop get a larger cover with horizontal identity',css.includes('@media(min-width:620px)')&&css.includes('grid-template-columns:190px minmax(0,1fr)!important'));
check('image cache key is preserved',sw.includes("var IMG='v288-core-images-20261114'"));
check('Manual shortcut remains removed from exploration actions',!app.includes('const primaryManual=detailManuals[0]')&&!app.includes('class="detail-use-card manual'));
check('Guide, Table Mode and Meeple IA remain in exploration',app.includes('data-guia="${esc(g.id)}"')&&app.includes('data-open-table="${esc(g.id)}"')&&app.includes('data-open-ai="${esc(g.id)}"'));
check('Quick Consult and Complete Manual remain in the rules section',app.includes('if(g.mesa&&Array.isArray(g.mesa.secoes)&&g.mesa.secoes.length){html+=consultaEntry(g);}')&&app.includes('visibleManuals.map(m=>'));
check('reading progress and complete state remain',app.includes('Concluído · Toque para revisar')&&app.includes('role="progressbar"'));
check('game info groups and curiosity section remain',app.includes('function extendedGameProfile(g){')&&app.includes('html+=curiositySection(g);'));

// Runtime render contract: ensure the actual detail renderer emits the horizontal hero
// while retaining links, actions, manuals and progress state.
const detailStart=app.indexOf('function renderDetail(id){');
const detailEnd=app.indexOf('\nfunction setTab(next)',detailStart);
const detailSrc=app.slice(detailStart,detailEnd);
const manualFnStart=app.indexOf('function manualsForDisplay(g){');
const manualFnEnd=app.indexOf('\nfunction renderDetail(id)',manualFnStart);
const manualFn=app.slice(manualFnStart,manualFnEnd);
const view={innerHTML:''},hero={classList:{add(){}}};
const ctx={
 esc:x=>String(x??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c])),norm:x=>String(x??'').normalize('NFD').replace(/[\u0300-\u036f]/g,'').toLowerCase(),
 quickPlayers:g=>g.jogadoresTexto||'2–4',gameCompleteness:()=>({filled:9,total:10,pct:90}),cover:g=>'cover.webp',extendedGameProfile:g=>'<section>Informações do jogo</section>',curiositySection:g=>'<section>Além do tabuleiro</section>',
 manualUrl:(g,m)=>'manuais/'+g.id+'/'+m.arquivo,gameDescription:g=>g.descricao||'Texto editorial.',quickSheet:()=>'<div class="quick-sheet">Consulta Rápida</div>',consultaEntry:g=>'<a data-consulta="'+g.id+'">Consulta Rápida</a>',offlineRefresh:()=>{},
 $:sel=>sel==='#hero'?hero:sel==='#view'?view:null,window:{scrollTo(){}},favorites:new Set(),reading:{'sample|manual':55},library:[],meepleDetailOpen:false,Number,Array,String,Math,Set
};
vm.createContext(ctx);vm.runInContext(manualFn+'\n'+detailSrc,ctx);
const g={id:'sample',titulo:'Jogo de Teste',jogadoresTexto:'2–4',jogadoresMin:2,jogadoresMax:4,duracaoMin:30,duracaoMax:45,idade:8,categorias:['Família'],descricao:'Descrição do jogo.',bggUrl:'https://boardgamegeek.com',ludopediaUrl:'https://ludopedia.com.br',editora:'Editora Exemplo',manuais:[{nome:'Manual Completo',arquivo:'manual.html'}],mesa:{secoes:[{titulo:'Objetivo'}]},guia:{secoes:[{titulo:'Comece'}]}};
ctx.library=[g];ctx.renderDetail('sample');
check('runtime detail renders horizontal hero class',view.innerHTML.includes('detailhero-v293-5-horizontal'));
check('runtime exploration preserves Guide, Table Mode and AI without a Manual duplicate',view.innerHTML.includes('Meeple Guia')&&view.innerHTML.includes('Modo Mesa')&&view.innerHTML.includes('Meeple IA')&&!/detail-use-card manual/.test(view.innerHTML));
check('runtime Rules and Manuals shows Quick Consult and Complete Manual',view.innerHTML.includes('data-consulta="sample"')&&view.innerHTML.includes('Manual Completo'));
check('runtime manual retains reading progress',view.innerHTML.includes('55% lido · Continuar')&&view.innerHTML.includes('aria-valuenow="55"'));
check('runtime hero retains external BGG and Ludopedia links',view.innerHTML.includes('https://boardgamegeek.com')&&view.innerHTML.includes('https://ludopedia.com.br'));
check('runtime publisher and game description remain',view.innerHTML.includes('Editora Exemplo')&&view.innerHTML.includes('Descrição do jogo.'));
let failed=0;for(const [name,ok] of checks){console.log((ok?'✓ ':'✗ ')+name);if(!ok)failed++;}
if(failed)process.exit(1);console.log(`\nV293.5: ${checks.length} verificações aprovadas.`);
