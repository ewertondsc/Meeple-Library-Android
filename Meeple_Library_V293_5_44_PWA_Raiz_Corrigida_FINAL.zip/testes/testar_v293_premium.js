const fs=require('fs'),assert=require('assert').strict;
const app=fs.readFileSync('index.html','utf8'),sw=fs.readFileSync('sw.js','utf8'),vm=require('vm');
const helper=app.slice(app.indexOf('function gameCompleteness(g){'),app.indexOf('function readDateLabel(){'));const box={};vm.runInNewContext(helper+';this.gameCompleteness=gameCompleteness;',box);
const emptyQuality=box.gameCompleteness({}),fullQuality=box.gameCompleteness({jogadores:'2–4',duracaoMin:30,idade:8,designer:'Designer',editora:'Editora',categorias:['Estratégia'],fichaRapida:{duracao:'30 min',mecanicas:['Draft'],objetivo:'Pontuar'},manuais:[{nome:'Manual',arquivo:'manual.json'}],descricao:'Descrição'});
const checks=[
 ['marca V293.2 e identidade premium preservada',app.includes('V293.5.18 · Meeple Explorer integrado ao chat.')&&app.includes('meeple-v293-premium-experience')],
 ['Início minimalista reúne boas-vindas, resumo compacto e retomada',app.includes('home-premium-heading')&&app.includes('home-premium-summary')&&app.includes('home-premium-resume')],
 ['atalhos principais usam a IA e a Comparador existente',app.includes('data-open-ai=""')&&app.includes('data-hub="compare"')],
 ['atalhos de exploração preservam Guia, Modo Mesa e Meeple IA sem duplicar o Manual',app.includes('v293-game-actions')&&app.includes('data-open-table=')&&app.includes('data-open-ai=')&&app.includes('data-guia=')&&!app.includes('class="detail-use-card manual')],
 ['completude da ficha usa campos reais e não estimados',app.includes('function gameCompleteness(g)')&&app.includes("['Mecânicas',has(q.mecanicas)")],
 ['completude não preenche campos ausentes por inferência',emptyQuality.pct===0&&fullQuality.pct===100],
 ['backup continua acessível pela área Ferramentas',app.includes("hubCard('⤓','Backup e restauração'")&&app.includes("'backup')")],
 ['Insights inclui mecânicas e cadastros a revisar',app.includes('rankedMechanics')&&app.includes('v293-gap-list')],
 ['gerenciador mostra completude do módulo',app.includes('Cadastro ${gameCompleteness(g).pct}% completo')],
 ['tema claro/escuro persistente foi preservado',app.includes("save('theme',root.dataset.theme)")],
 ['service worker força novo cache de conteúdo sem trocar a chave das imagens',sw.includes('v293-5-18-meeple-explorer-integration-20261117')&&sw.includes('var IMG=')],
 ['acessibilidade e movimento reduzido',app.includes('prefers-reduced-motion:reduce')&&app.includes(':focus-visible')]
];
let fail=0;for(const [name,ok] of checks){console.log((ok?'✓ ':'✗ ')+name);if(!ok)fail++}
if(fail)process.exit(1);console.log(`\nV293 Premium: ${checks.length} verificações estáticas aprovadas.`);
