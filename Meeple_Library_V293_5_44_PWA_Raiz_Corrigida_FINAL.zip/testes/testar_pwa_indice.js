#!/usr/bin/env node
// V92: índice local resiliente, expansão explícita no meta.json e melhorias de PWA (offline, manifest, ícones).  Uso: node testes/testar_pwa_indice.js
const fs=require('fs'),vm=require('vm'),assert=require('assert').strict,path=require('path');
const R=path.resolve(__dirname,'..');const rd=f=>fs.readFileSync(path.join(R,f),'utf8');
const html=rd('index.html');let ok=0;
const T=async(n,f)=>{try{await f();ok++;console.log('✓',n)}catch(e){console.log('✗',n,'\n    ',e.message.split('\n')[0]);process.exitCode=1}};
const pick=n=>{const i=html.indexOf(n);return html.slice(i,html.indexOf('\n}\n',i)+3)};
(async()=>{
 const mk=fetchImpl=>new Function('fetch',pick('async function fetchManualText')+';return fetchManualText')(fetchImpl);
 await T('índice: tenta de novo quando a primeira tentativa falha',async()=>{let n=0;const f=mk(async()=>{if(++n===1)throw new Error('rede');return{ok:true,text:async()=>'<h1>ok</h1>'}});assert.equal(await f('x'),'<h1>ok</h1>');assert.equal(n,2)});
 await T('índice: resposta 404 não vira texto de manual',async()=>{const f=mk(async()=>({ok:false,text:async()=>'<h1>404</h1>'}));assert.equal(await f('x'),null)});
 await T('índice: incompleto não fica guardado na sessão',()=>assert.ok(/if\(falhou\)indexPromise=null/.test(html)));
 await T('expansão vem do meta.json, não de regex no nome',()=>{assert.ok(!/expans\|1912\|5-6\|rio\|abade/.test(html));assert.ok(html.includes('isExpansion:m.expansao===true'))});
 await T('library.json: expansões conhecidas ou catálogo intencionalmente vazio',()=>{const lib=JSON.parse(rd('library.json'));const exp=[];lib.forEach(g=>(g.manuais||[]).forEach(m=>{if(m.expansao)exp.push(g.id+'/'+m.arquivo)}));if(lib.length)assert.deepEqual(exp,['catan/expansao-5-6.html','ticket-to-ride-europa/expansao-1912.html']);else assert.deepEqual(exp,[])});
 await T('sw: navegação offline sem cache mostra offline.html',async()=>{
  const L={};const self={addEventListener(t,f){L[t]=f},skipWaiting(){},clients:{claim(){}}};
  const caches={match:async u=>(typeof u==='string'&&u==='offline.html')?'PAG_OFFLINE':undefined,open:async()=>({put:async()=>{},match:async()=>undefined}),keys:async()=>[],delete:async()=>true};
  vm.runInNewContext(rd('sw.js'),{self,caches,fetch:async()=>{throw new Error('offline')},URL,Promise});
  let r;L.fetch({request:{method:'GET',mode:'navigate',url:'https://x.test/pagina'},respondWith:p=>{r=p}});assert.equal(await r,'PAG_OFFLINE');
  let r2;L.fetch({request:{method:'GET',mode:'cors',url:'https://x.test/manuais/a/img.jpg'},respondWith:p=>{r2=p}});await assert.rejects(r2);
 });
 await T('offline.html e ícones estão no cache inicial e existem',()=>{const core=JSON.parse(rd('files.json')).core;for(const f of['offline.html','icon-180.png','icon-maskable-512.png']){assert.ok(core.includes(f),f+' fora do núcleo');assert.ok(fs.existsSync(path.join(R,f)),f+' ausente')}});
 await T('manifest: id, lang e ícone maskable',()=>{const m=JSON.parse(rd('manifest.webmanifest'));assert.ok(m.id&&m.lang==='pt-BR');assert.ok(m.icons.some(i=>/maskable/.test(i.purpose)&&i.sizes==='512x512'))});
 await T('apple-touch-icon declarado',()=>assert.ok(/rel="apple-touch-icon" href="icon-180.png"/.test(html)));
 await T('aviso de nova versão não recarrega sozinho',()=>{assert.ok(html.includes("addEventListener('controllerchange'"));assert.ok(html.includes('showUpdateBar'));assert.ok(!/controllerchange'[^;]*location\.reload/.test(html))});
 console.log('\nPWA e índice OK: '+ok+' verificações');
})();
