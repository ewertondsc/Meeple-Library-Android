// Compatibilidade: o teste histórico da V293.1 foi atualizado para validar
// o comportamento vigente da tela Início, refinado na V293.2.3.
require('./testar_v293_2_2_estante_deslizavel.js');
