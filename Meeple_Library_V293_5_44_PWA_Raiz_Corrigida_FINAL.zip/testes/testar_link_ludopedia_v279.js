const fs=require('fs');
const html=fs.readFileSync('index.html','utf8');
const lib=JSON.parse(fs.readFileSync('library.json','utf8'));
const azul=lib.find(g=>g.id==='azul');
const fn=html.slice(html.indexOf('function renderCommunityPage(id,source){'),html.indexOf('\nfunction manualsForDisplay(g){'));
const checks=[
 ['botão externo usa navegação na mesma aba',fn.includes('target="_self"')],
 ['link externo tem href baseado na URL do jogo',fn.includes('href="${esc(url)}"')],
 ['URL canônica do Azul cadastrada',azul?.ludopediaUrl==='https://ludopedia.com.br/jogo/azul'],
 ['botão não depende de popup/target blank',!fn.includes('target="_blank"')],
 ['link externo não é interceptado pelo botão interno',fn.includes('data-community-external="true"')],
 ['cache atualizado',fs.readFileSync('sw.js','utf8').includes('v282-community-direct-external-links')]
];
let fail=0;for(const [n,ok] of checks){console.log((ok?'✓ ':'✗ ')+n);if(!ok)fail++}
if(fail)process.exit(1);console.log(`\nLudopedia link V279 OK: ${checks.length} verificações.`);
