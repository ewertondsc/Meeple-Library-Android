const fs=require('fs'),vm=require('vm');
const app=fs.readFileSync('index.html','utf8'),sw=fs.readFileSync('sw.js','utf8');
const checks=[];const check=(name,ok)=>checks.push([name,!!ok]);
check('build stamp reports V293.4',app.includes("V293.5.18 · Meeple Explorer integrado ao chat."));
check('service worker cache key is unique to V293.4',sw.includes("v293-5-18-meeple-explorer-integration-20261117"));
check('detail header uses a dedicated centered scope',app.includes('detailhero-v293-4-centered'));
check('centered layout keeps cover, title and facts in one centered column',app.includes('.detailhero-v293-4-centered .detail-cover-column')&&app.includes('.detailhero-v293-4-centered .detail-identity h1')&&app.includes('justify-content:center!important'));
check('description stays left-aligned inside centered width',app.includes('.detailhero-v293-4-centered .detail-v259-description')&&app.includes('text-align:left!important')&&app.includes('max-width:640px!important'));
check('Manual shortcut is no longer rendered in exploration actions', !app.includes('const primaryManual=detailManuals[0]') && !app.includes('class=\"detail-use-card manual'));
check('exploration still exposes Meeple Guide when available',app.includes('data-guia="${esc(g.id)}"')&&app.includes('<b>Meeple Guia</b>'));
check('Modo Mesa shortcut is preserved',app.includes('data-open-table="${esc(g.id)}"')&&app.includes('<b>Modo Mesa</b>'));
check('Meeple IA shortcut is preserved',app.includes('data-open-ai="${esc(g.id)}"')&&app.includes('<b>Meeple IA</b>'));
check('exploration helper text no longer promises manual consultation',app.includes('Aprenda a jogar, acompanhe a partida ou tire dúvidas.')&&!app.includes('consulte regras ou acompanhe a partida'));
check('Consulta Rápida remains in Regras e manuais',app.includes('if(g.mesa&&Array.isArray(g.mesa.secoes)&&g.mesa.secoes.length){html+=consultaEntry(g);}'));
check('Complete manual remains in Regras e manuais',app.includes('visibleManuals.map(m=>'));
check('original PDF access remains when present',app.includes('if(g.pdfOriginal){'));
check('reading progress and complete state remain',app.includes('Concluído · Toque para revisar')&&app.includes('role="progressbar"'));
check('module information renderer remains unchanged',app.includes('function extendedGameProfile(g){'));
check('curiosity and source section remain',app.includes('html+=curiositySection(g);'));

// Runtime render contract with a test module containing all three exploration tools and both manual options.
const detailStart=app.indexOf('function renderDetail(id){');
const detailEnd=app.indexOf('\nfunction setTab(next)',detailStart);
const detailSrc=app.slice(detailStart,detailEnd);
const manualFnStart=app.indexOf('function manualsForDisplay(g){');
const manualFnEnd=app.indexOf('\nfunction renderDetail(id)',manualFnStart);
const manualFn=app.slice(manualFnStart,manualFnEnd);
const view={innerHTML:''},hero={classList:{add(){}}};
const ctx={
 esc:x=>String(x??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c])),norm:x=>String(x??'').normalize('NFD').replace(/[\u0300-\u036f]/g,'').toLowerCase(),
 quickPlayers:g=>g.jogadoresTexto||'2–4',gameCompleteness:()=>({filled:9,total:10,pct:90}),cover:g=>'cover.webp',extendedGameProfile:g=>'<section>Informações do jogo</section>',curiositySection:g=>'<section>Além do tabuleiro</section>',
 manualUrl:(g,m)=>'manuais/'+g.id+'/'+m.arquivo,gameDescription:g=>g.descricao||'Texto editorial.',quickSheet:()=>'<div class="quick-sheet">Consulta Rápida</div>',consultaEntry:g=>'<a data-consulta="'+g.id+'">Consulta Rápida</a>',offlineRefresh:()=>{},
 $:sel=>sel==='#hero'?hero:sel==='#view'?view:null,window:{scrollTo(){}},favorites:new Set(),reading:{'sample|manual':55},library:[],meepleDetailOpen:false,Number,Array,String,Math,Set
};
vm.createContext(ctx);vm.runInContext(manualFn+'\n'+detailSrc,ctx);
const g={id:'sample',titulo:'Jogo de Teste',jogadoresTexto:'2–4',jogadoresMin:2,jogadoresMax:4,duracaoMin:30,duracaoMax:45,idade:8,categorias:['Família'],descricao:'Descrição do jogo.',bggUrl:'https://boardgamegeek.com',ludopediaUrl:'https://ludopedia.com.br',editora:'Editora Exemplo',manuais:[{nome:'Manual Completo',arquivo:'manual.html'}],mesa:{secoes:[{titulo:'Objetivo'}]},guia:{secoes:[{titulo:'Comece'}]}};
ctx.library=[g];ctx.renderDetail('sample');
check('rendered runtime detail has centered header class',view.innerHTML.includes('detailhero-v293-4-centered'));
check('runtime exploration has Guide, Table and AI but no Manual card',view.innerHTML.includes('Meeple Guia')&&view.innerHTML.includes('Modo Mesa')&&view.innerHTML.includes('Meeple IA')&&!/detail-use-card manual/.test(view.innerHTML));
check('runtime Rules and Manuals has Quick Consult and Complete Manual',view.innerHTML.includes('data-consulta="sample"')&&view.innerHTML.includes('Manual Completo'));
check('runtime full manual preserves reading progress',view.innerHTML.includes('55% lido · Continuar')&&view.innerHTML.includes('aria-valuenow="55"'));
check('runtime header retains BGG and Ludopedia links',view.innerHTML.includes('https://boardgamegeek.com')&&view.innerHTML.includes('https://ludopedia.com.br'));
check('runtime description remains available',view.innerHTML.includes('Descrição do jogo.'));
let failed=0;for(const [name,ok] of checks){console.log((ok?'✓ ':'✗ ')+name);if(!ok)failed++;}
if(failed)process.exit(1);console.log(`\nV293.4: ${checks.length} verificações aprovadas.`);
