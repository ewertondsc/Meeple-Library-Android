const fs=require('fs');
const html=fs.readFileSync('index.html','utf8');
const sw=fs.readFileSync('sw.js','utf8');
const flow=html.indexOf('<style id="meeple-ai-v293-5-16-chat-flow">');
const head=html.indexOf('</head>');
const block=flow>=0&&head>flow?html.slice(flow,head):'';
const checks=[
 ['V293.5.16 CSS está no head principal',flow>=0&&head>flow],
 ['marca Meeple Library integrada ao topo',/ai-gemini-library-brand/.test(html)],
 ['botão Novo chat alinhado à seleção de jogo',/ai-gemini-game-row[^`]*id="aiNewConversationTop"/s.test(html)],
 ['motor Meeple Expert 5.9 carregado',/MeepleExpertCore/.test(html)&&fs.existsSync('meeple-expert/js/meeple-engine.js')],
 ['área de conversa acessível',/id="aiChat" role="log" aria-live="polite"/.test(html)],
 ['scroll interno por toque preservado',/\.ai-gemini-screen \.ai-gemini-chat\{[\s\S]*?-webkit-overflow-scrolling:touch!important/.test(block)],
 ['chat supera a altura limitada do CSS antigo',/\.ai-gemini-screen \.ai-gemini-chat\{[\s\S]*?max-height:none!important/.test(block)],
 ['compositor participa do fluxo flex',/\.ai-gemini-screen \.ai-gemini-composer\{[\s\S]*?position:relative!important[\s\S]*?flex:0 0 auto!important/.test(block)],
 ['compositor não é fixado sobre mensagens',!/\.ai-gemini-screen \.ai-gemini-composer\{[^}]*position:fixed!important/.test(block)],
 ['viewport adapta altura ao teclado',/--ai-gemini-visible-height/.test(block)&&/view\.style\.setProperty\('--ai-gemini-visible-height'/.test(html)],
 ['rolagem reancora em múltiplos frames',/function scrollMeepleAIGeminiToLatest[\s\S]*?frame<4/.test(html)],
 ['mensagens do usuário e assistente têm cartões distintos',/\.ai-gemini-chat \.ai-msg\.user/.test(block)&&/\.ai-gemini-chat \.ai-msg\.assistant/.test(block)],
 ['histórico e Novo chat preservados',/id="aiConversationSelect"/.test(html)&&/id="aiNewConversationTop"/.test(html)],
 ['cache de shell V293.5.18 ativo',/var BUILD='v293-5-18-meeple-explorer-integration-20261117'/.test(sw)],
 ['cache de imagens preservado',/var IMG='v288-core-images-20261114'/.test(sw)],
 ['buildstamp V293.5.18 atualizado',/V293\.5\.18 · Meeple Explorer integrado ao chat/.test(html)]
];
let failed=0;for(const [name,ok] of checks){console.log(`${ok?'PASS':'FAIL'} ${name}`);if(!ok)failed++;}
if(failed)process.exit(1);console.log(`V293.5.16: ${checks.length} verificações aprovadas.`);
