#!/usr/bin/env node
const fs=require('fs'),assert=require('assert').strict,path=require('path');
const R=path.resolve(__dirname,'..'),rd=f=>fs.readFileSync(path.join(R,f),'utf8');
const m=JSON.parse(rd('manifest.webmanifest')),html=rd('index.html'),sw=rd('sw.js'),files=JSON.parse(rd('files.json'));
assert.equal(m.start_url,'/');assert.equal(m.scope,'/');assert.equal(m.id,'/');
assert.ok(html.includes('href="/manifest.webmanifest"'));
assert.ok(html.includes("navigator.serviceWorker.register('/sw.js',{scope:'/'} )") || html.includes("navigator.serviceWorker.register('/sw.js',{scope:'/'})"));
assert.ok(sw.includes("pathname==='/'") && sw.includes("new URL('index.html',self.location.origin).href"));
assert.ok(files.core.includes('index.html') && !files.core.includes('./'));
console.log('PWA raiz: 6 verificações aprovadas');
