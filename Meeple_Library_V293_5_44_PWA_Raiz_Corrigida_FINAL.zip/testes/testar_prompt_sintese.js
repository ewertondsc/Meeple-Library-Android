#!/usr/bin/env node
// Garante que o prompt de síntese (V90) cabe no limite do Worker e mantém pergunta e trecho relevante.  Uso: node testes/testar_prompt_sintese.js
const fs=require('fs'),assert=require('assert').strict,path=require('path');
const html=fs.readFileSync(path.resolve(__dirname,'..','index.html'),'utf8');
const pick=n=>{const i=html.indexOf(n);return html.slice(i,html.indexOf('\n}\n',i)+3)};
const src=html.match(/const MEEPLE_QUERY_MAX=\d+;/)[0]+pick('function pickEvidenceWindow')+pick('function buildLocalEvidencePrompt');
const {buildLocalEvidencePrompt,MEEPLE_QUERY_MAX}=new Function(src+';return{buildLocalEvidencePrompt,MEEPLE_QUERY_MAX}')();
let ok=0;const t=(n,f)=>{f();ok++;console.log('✓',n)};
const longo='Regra irrelevante. '.repeat(120)+'Quando sai 7, quem tem mais de sete cartas descarta metade e o ladrão é movido. '+'Mais texto. '.repeat(80);
const hits=[0,1,2,3].map(i=>({game:'Catan',manual:'Básico',section:'Ladrão '+i,text:longo,isExpansion:i===3}));
const q='Quando tiro 7, sou obrigado a roubar uma carta?';
const p=buildLocalEvidencePrompt(q,'Catan',hits);
t('cabe no limite do Worker',()=>assert.ok(p.length<=MEEPLE_QUERY_MAX));
t('pergunta preservada',()=>assert.ok(p.includes(q)));
t('instrução de síntese original presente',()=>assert.ok(/ORIGINAL/.test(p)));
t('trecho relevante (não só o início da seção) entra',()=>assert.ok(p.includes('descarta metade')));
t('pergunta enorme não estoura o limite',()=>assert.ok(buildLocalEvidencePrompt(q.repeat(80),'Catan',hits).length<=MEEPLE_QUERY_MAX));
t('sem trechos não quebra',()=>assert.ok(buildLocalEvidencePrompt(q,'Catan',[]).length<=MEEPLE_QUERY_MAX));
console.log('\nPrompt de síntese OK: '+ok+' verificações');
