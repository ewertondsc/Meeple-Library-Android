const fs=require('fs');
const html=fs.readFileSync(require('path').join(__dirname,'..','index.html'),'utf8');
function ok(condition,message){if(!condition)throw new Error(message);console.log('✓ '+message)}
ok(html.includes("previousModule&&previousModule.source!=='builtin'&&!options.replaceExisting"),'módulo pode complementar jogo nativo já migrado');
ok(html.includes("merged.manuais=Array.isArray(moduleGame.manuais)&&moduleGame.manuais.length?moduleGame.manuais"),'manuais do ZIP são associados ao cadastro existente');
ok(html.includes("merged.arquivos=[...new Set([...(baseGame.arquivos||[]),...(moduleGame.arquivos||[])])]"),'arquivos do catálogo e do módulo são mesclados sem duplicação');
ok(html.includes('O catálogo nativo tem prioridade quando traz valor')&&html.includes('não apagam os dados do módulo'),'dados editoriais nativos são preservados sem perder campos do módulo');
ok(html.includes('manual.json')&&html.includes('meeple-structured-v1')&&html.includes('Manuais HTML antigos continuam aceitos'),'ajuda do importador documenta conteúdo estruturado e compatibilidade legada');
ok(html.includes('upsertModuleReferenceFromGame(game)'),'metadados aproveitáveis são compartilhados com módulos futuros');
console.log('\nImportação modular V286 OK.');
