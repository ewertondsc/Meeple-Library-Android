// V293.5.33 — exemplos horizontais em até duas linhas
const fs=require('fs');
const html=fs.readFileSync('index.html','utf8');
const checks=[
 ['exemplos com rótulos compactos',html.includes('>Vencer no Carcassonne</button>')&&html.includes('>Pontuação do Azul</button>')&&html.includes('>Jogos como Catan</button>')],
 ['prompts originais preservados',html.includes('data-ai-example="Como vencer no Carcassonne?"')&&html.includes('data-ai-example="Qual a regra de pontuação do Azul?"')&&html.includes('data-ai-example="Quais jogos são parecidos com Catan?"')],
 ['layout horizontal com quebra de linha',html.includes('flex-direction:row!important;flex-wrap:wrap!important')],
 ['botões compactos sem quebra interna',html.includes('white-space:nowrap!important')&&html.includes('font-size:.57rem!important')],
 ['limite visual de duas linhas',html.includes('max-height:68px!important;overflow:hidden!important')&&html.includes('max-height:62px!important')],
 ['histórico e atalhos permanecem',html.includes('id="aiHistoryQuick"')&&html.includes('data-ai-home-mode="strategy"')],
 ['versão atualizada',html.includes('V293.5.39 · Identidade visual Meeple AI')]
];
for(const [name,ok] of checks){if(!ok)throw new Error('Falhou: '+name);console.log('OK:',name)}
