// V293.5.29 — ficha fiel ao print 2, sem caixa editorial
const fs=require('fs');
const html=fs.readFileSync('index.html','utf8');
const css=html.match(/<style id="v293-5-29-detail-reference-layout">([\s\S]*?)<\/style>/);
if(!css)throw new Error('CSS de referência ausente');
const s=css[1];
const checks=[
 ['wrapper editorial sem caixa (display:contents)',s.includes('.detailhero-v293-5-horizontal>.detail-v293-content{')&&s.includes('display:contents!important')],
 ['ficha sem borda/fundo externo',s.includes('border:0!important;border-radius:0!important;')&&s.includes('background:transparent!important;box-shadow:none!important;')],
 ['descrição em largura total',s.includes('.detail-v293-content>.detail-v259-description')&&s.includes('grid-column:1/-1!important')],
 ['cartões BGG/Ludopedia em duas colunas',s.includes('grid-template-columns:repeat(2,minmax(0,1fr))!important')],
 ['editora sem caixa externa',s.includes('.detail-v293-content>.detail-v259-publisher')&&s.includes('background:transparent!important')],
 ['menu e ícones preservados',html.includes('navicon-tools')&&html.includes('navicon-chat')],
 ['buildstamp atualizado',html.includes('V293.5.29 · Ficha sem caixa editorial')]
];
for(const [name,ok] of checks){if(!ok)throw new Error('Falhou: '+name);console.log('OK:',name)}
