// V293.5.26 — descrição da ficha sempre em largura total
const fs=require('fs');
const html=fs.readFileSync('index.html','utf8');
const css=html.match(/<style id="v293-5-26-game-description-width-fix">([\s\S]*?)<\/style>/);
if(!css)throw new Error('CSS de correção ausente');
for(const token of ['grid-column:1/-1!important','grid-row:auto!important','width:100%!important','max-width:100%!important','@media(max-width:380px)'])
 if(!css[1].includes(token))throw new Error('Regra ausente: '+token);
if(!html.includes('navicon-chat')||!html.includes('navicon-tools'))throw new Error('Ícones da versão anterior não preservados');
if(!html.includes('V293.5.26 · Correção da largura da descrição.'))throw new Error('Versão não atualizada');
console.log('OK: descrição e seções complementares ocupam largura total também em telas estreitas; ícones preservados.');
