#!/usr/bin/env node
const fs=require('fs'),assert=require('assert').strict,path=require('path');
const html=fs.readFileSync(path.resolve(__dirname,'..','index.html'),'utf8');
const pick=n=>{const i=html.indexOf(n);return html.slice(i,html.indexOf('\n}',i)+3)};
const src=html.match(/const MEEPLE_QUERY_MAX=\d+;/)[0]+pick('function pickEvidenceWindow')+pick('function buildLocalEvidencePrompt');
const {buildLocalEvidencePrompt,MEEPLE_QUERY_MAX}=new Function(src+';return{buildLocalEvidencePrompt,MEEPLE_QUERY_MAX}')();
const q='Se eu puder mover a peça, sou obrigado a roubar?';
const hits=[{manual:'Manual oficial',section:'Sequência',text:'Depois de mover a peça, você pode roubar uma carta se cumprir a condição.',isExpansion:false}];
const prompt=buildLocalEvidencePrompt(q,'Jogo X',hits);
assert.ok(prompt.length<=MEEPLE_QUERY_MAX,'prompt excede limite');
assert.ok(prompt.includes(q),'pergunta ausente');
for(const term of ['PODE','DEVE','NÃO PODE','procedimento','exceções','não complete por suposição']) assert.ok(prompt.toLowerCase().includes(term.toLowerCase()),'faltou '+term);
assert.ok(/CONTEXTO DA PERGUNTA ANTERIOR/.test(html),'contexto de follow-up ausente');
assert.ok(/RESPOSTA ANTERIOR/.test(html),'resposta anterior não é considerada em follow-up');
console.log('Meeple IA V97: 8 verificações aprovadas.');
