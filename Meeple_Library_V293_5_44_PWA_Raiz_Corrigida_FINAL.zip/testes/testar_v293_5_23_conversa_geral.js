// V293.5.23 — cobertura de conversa geral
const fs=require('fs');
const html=fs.readFileSync('index.html','utf8');
const expert=fs.readFileSync('meeple-expert/js/meeple-engine.js','utf8');
for(const phrase of ['vamos jogar','td joia','como vai vc','Tudo joia por aqui'])
 if(!html.toLowerCase().includes(phrase.toLowerCase())) throw new Error('Chat sem resposta: '+phrase);
for(const phrase of ['vamos jogar','td joia','como vai vc'])
 if(!expert.toLowerCase().includes(phrase.toLowerCase())) throw new Error('Expert sem resposta: '+phrase);
if(!html.includes('V293.5.23 · Conversa geral sem bloqueio')) throw new Error('Buildstamp');
console.log('OK: conversas gerais não exigem contexto de jogo');
