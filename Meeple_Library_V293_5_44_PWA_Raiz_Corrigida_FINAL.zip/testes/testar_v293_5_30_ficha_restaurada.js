// V293.5.30 — restauração do padrão visual da ficha (referência do segundo print)
const fs=require('fs');
const html=fs.readFileSync('index.html','utf8');
const start=html.indexOf('<section class="detailhero detailhero-premium detailhero-v260 detailhero-v293-5-horizontal">');
const end=html.indexOf('</section>`;',start);
if(start<0||end<0)throw new Error('Template de ficha ausente');
const template=html.slice(start,end);
const positions=['detail-cover-column','detail-identity','detail-fav','detail-v259-description','detail-v259-community','detail-v259-publisher'].map(x=>template.indexOf(x));
if(positions.some(x=>x<0))throw new Error('Falta elemento da ficha');
for(let i=1;i<positions.length;i++)if(positions[i]<=positions[i-1])throw new Error('Ordem plana original da ficha foi alterada');
if(template.includes('detail-v293-topline')||template.includes('detail-v293-content'))throw new Error('Wrappers que alteram o layout ainda presentes');
if(html.includes('v293-5-29-detail-reference-layout'))throw new Error('CSS estrutural que centralizava a capa não foi removido');
if(!html.includes('navicon-chat')||!html.includes('navicon-tools'))throw new Error('Ícones novos da navegação não foram preservados');
if(!html.includes('V293.5.30 · Ficha restaurada ao padrão anterior'))throw new Error('Buildstamp não atualizado');
console.log('OK: capa e identidade em layout original; descrição, links e editora fora de caixa; navegação preservada.');
