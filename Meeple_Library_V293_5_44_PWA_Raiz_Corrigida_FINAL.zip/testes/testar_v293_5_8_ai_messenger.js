// Regression bridge: legacy messenger test now verifies the current Gemini-style composer contract.
const fs = require('fs');
const assert = require('assert');
const html = fs.readFileSync('index.html', 'utf8');
const sw = fs.readFileSync('sw.js', 'utf8');
const render = html.slice(html.indexOf('function renderAI('), html.indexOf('function safeTextHTML'));
assert(html.includes('id="meeple-ai-v293-5-13-gemini-style"'), 'Gemini style stylesheet exists');
assert(render.includes('ai-gemini-screen'), 'Gemini-style shell is rendered');
assert(render.includes('ai-gemini-empty'), 'Centered welcome state is rendered');
assert(render.includes('ai-gemini-composer'), 'Floating composer is rendered');
assert(render.includes('placeholder="Pergunte ao Meeple AI…"'), 'Composer has the concise prompt');
assert(render.includes('id="aiQuestion"') && render.includes('id="aiSend"'), 'Question and send controls remain wired');
assert(render.includes('id="aiConversationSelect"'), 'Conversation history remains accessible');
assert(render.includes('data-ai-mode="rules"') && render.includes('data-ai-mode="strategy"') && render.includes('data-ai-mode="situation"'), 'Response modes remain accessible');
assert(html.includes('MeepleExpertCore'), 'Expert engine integration is preserved');
assert(html.includes('V293.5.18 · Meeple Explorer integrado ao chat.'), 'Build stamp is updated');
assert(sw.includes("var BUILD='v293-5-18-meeple-explorer-integration-20261117'"), 'Service worker cache version is updated');
console.log('V293.5.13 Gemini-style AI: 11 checks passed.');
