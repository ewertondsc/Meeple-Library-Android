const assert = require('node:assert/strict');
const fs = require('node:fs');
const path = require('node:path');
const vm = require('node:vm');

const root = { console, setTimeout, clearTimeout };
root.window = root;
root.globalThis = root;
const context = vm.createContext(root);
const dataDir = path.join(__dirname, '..', 'meeple-expert', 'data');
for (const file of [
  'base-knowledge.js', 'synonyms-data.js', 'hobby-glossary.js',
  'game-dossiers.js', 'game-guides.js', 'faq-bank.js',
  'setup-facts.js', 'player-setup-matrix.js', 'rule-interactions.js'
]) {
  vm.runInContext(fs.readFileSync(path.join(dataDir, file), 'utf8'), context, { filename: file });
}
vm.runInContext(fs.readFileSync(path.join(__dirname, '..', 'meeple-expert', 'js', 'meeple-engine.js'), 'utf8'), context, { filename: 'meeple-engine.js' });
const core = root.MeepleExpertCore;
assert.ok(core, 'MeepleExpertCore deve inicializar');

// Simula colisão de alias entre módulos instalados: ambos reconhecem Rummikub.
core.addGame({ id: 'rummikub', title: 'Rummikub', aliases: ['Rummikub', 'Rummy tiles'] });
core.addGame({ id: 'rummy-extra', title: 'Rummy Extra', aliases: ['Rummikub'] });
core.addGame({ id: 'catan-priority-test', title: 'Catan Priority Test', aliases: ['Catan Priority Test'] });

const question = 'Quero uma orientação de estratégia para Rummikub.';
const selected = core.detectGame(question, 'rummikub', []);
assert.equal(selected.id, 'rummikub', 'o jogo selecionado deve prevalecer quando for uma das correspondências');
assert.equal(selected.fromSelection, true, 'o resultado deve registrar a prioridade do seletor');

const explicitOther = core.detectGame('Quero uma estratégia para Catan.', 'rummikub', []);
assert.equal(explicitOther.id, 'catan', 'menção única explícita a outro jogo deve prevalecer sobre o seletor');

// Dois títulos de mesmo tamanho compartilham um alias; um terceiro jogo selecionado não pode
// mascarar uma ambiguidade real quando não aparece entre os resultados.
core.addGame({ id: 'collision-a', title: 'Collision A', aliases: ['Meeple Conflict'] });
core.addGame({ id: 'collision-b', title: 'Collision B', aliases: ['Meeple Conflict'] });
const unresolved = core.detectGame('Explique Meeple Conflict.', 'catan-priority-test', []);
assert.equal(unresolved.ambiguous, true, 'sem uma seleção que corresponda aos resultados, a ambiguidade real deve ser mantida');
const unresolvedWithoutSelection = core.detectGame('Explique Meeple Conflict.', '', []);
assert.equal(unresolvedWithoutSelection.ambiguous, true, 'sem jogo selecionado, a ambiguidade real deve ser mantida');

const asked = core.ask(question, 'rummikub', []);
assert.notEqual(asked.status, 'ambiguous', 'ask() deve deixar de retornar status ambiguous com Rummikub selecionado');

console.log('V293.5.38 — prioridade do jogo selecionado: 5/5 testes aprovados');
