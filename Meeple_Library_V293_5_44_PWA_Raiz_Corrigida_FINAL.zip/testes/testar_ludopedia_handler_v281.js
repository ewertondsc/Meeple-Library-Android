const fs=require('fs');
const html=fs.readFileSync('index.html','utf8');
const lib=JSON.parse(fs.readFileSync('library.json','utf8'));
const azul=lib.find(g=>g.id==='azul');
const i=html.indexOf('data-community="ludopedia"');
const button=html.slice(i,i+400);
const handler=html.slice(html.indexOf('function openLudopediaCommunity'),html.indexOf('function renderCommunityPage'));
const checks=[
 ['cartão Ludopedia chama função exclusiva',button.includes("openLudopediaCommunity('")],
 ['função exclusiva força a origem Ludopedia',handler.includes("renderCommunityPage(id,'ludopedia')")],
 ['função exclusiva verifica o jogo antes de abrir',handler.includes('library.find(item=>item.id===id)')],
 ['URL do Azul existe na base',azul?.ludopediaUrl==='https://ludopedia.com.br/jogo/azul'],
 ['URL alternativa do Azul protege cadastro ausente',handler.includes("game.id==='azul'")],
 ['cache atualizado',fs.readFileSync('sw.js','utf8').includes('v282-community-direct-external-links')]
];
let fail=0;for(const [n,ok] of checks){console.log((ok?'✓ ':'✗ ')+n);if(!ok)fail++}
if(fail)process.exit(1);console.log(`\nLudopedia V281 OK: ${checks.length} verificações.`);
