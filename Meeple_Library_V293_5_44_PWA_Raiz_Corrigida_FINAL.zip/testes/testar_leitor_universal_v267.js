const fs=require('fs');
const s=fs.readFileSync('index.html','utf8');
const checks=[
 ['leitor universal executado pelo app',s.includes('V267: leitor universal Meeple')],
 ['barra de ferramentas criada pelo app',s.includes("shell.className='reader-tools'")&&s.includes("actions.className='reader-actions'")],
 ['padrão de botões Azul centralizado',s.includes('.reader-actions button')&&s.includes('.reader-title-row')&&s.includes('.chapter-nav button')],
 ['controles de fonte nativos',s.includes("fontDown.id='fontDown'")&&s.includes("fontUp.id='fontUp'")],
 ['barra própria dos módulos removida',s.includes("'.reader-toolbar,.title-row,.font-tools,.index-panel,#chapter-index,.chapter-index'")],
 ['capítulos normalizados para navegação comum',s.includes("el.classList.add('topic')")&&s.includes("body.classList.add('topic-body')")],
 ['service worker com cache novo',fs.readFileSync('sw.js','utf8').includes('v293-5-18-meeple-explorer-integration-20261117')],
 ['contenção de overflow horizontal',s.includes('v275-horizontal-overflow-fix')],
 ['reset do scroll horizontal ao abrir jogo',s.includes('window.scrollTo({left:0,top:0,behavior:')],
 ['nome real de cada manual exibido',s.includes('<b>${esc(m.nome||\'Manual\')}</b>')],
 ['progresso sem repetir nome do manual',s.includes('class=\"manual-reading-status\"')&&s.includes('Concluído · Toque para revisar')],
 ['lightbox oculto até abrir e com camada modal',s.includes('#meeple-lightbox.is-open')&&s.includes('visibility:hidden')],
 ['índice de capítulos oculto até abrir e estilizado',s.includes('.meeple-chapter-panel.open')&&s.includes('display:none!important')],
 ['consulta rápida duplicada ocultada quando há Modo Mesa',s.includes('function manualsForDisplay(g)')&&s.includes("return !(name==='consulta rapida'")],
 ['contagem considera apenas manuais visíveis',s.includes('visibleManuals.length')&&s.includes('visibleManuals.map(m=>')]
];
let fail=0;for(const [name,ok] of checks){console.log((ok?'✓ ':'✗ ')+name);if(!ok)fail++}
if(fail)process.exit(1);console.log('\\nLeitor universal e lista de manuais OK: '+checks.length+' verificações.');
