const fs=require('fs'),vm=require('vm');
const app=fs.readFileSync('index.html','utf8'),sw=fs.readFileSync('sw.js','utf8');
const checks=[];const check=(name,ok)=>checks.push([name,!!ok]);
check('build stamp reports V293.3',app.includes("V293.5.18 · Meeple Explorer integrado ao chat."));
check('service worker cache key is unique to V293.3',sw.includes("v293-5-18-meeple-explorer-integration-20261117"));
check('game identity has a clear kicker',app.includes('detail-v293-eyebrow')&&app.includes('FICHA DO JOGO'));
check('hero cover and title refinement targets game-detail only',app.includes('.detailhero-premium.detailhero-v260')&&app.includes('.detailhero-v260 .detail-identity h1'));
check('explore heading is a single vertical block',app.includes('.v293-game-launch .detail-use-heading{display:block!important'));
check('explore helper text is concise',app.includes('Aprenda a jogar, acompanhe a partida ou tire dúvidas.'));
check('manual has explicit completed state',app.includes('Concluído · Toque para revisar')&&app.includes('className:\'is-complete\''));
check('manual has explicit in-progress and not-started states',app.includes('% lido · Continuar')&&app.includes('Ainda não iniciado · Começar'));
check('manual progress is accessible',app.includes('role="progressbar"')&&app.includes('aria-valuenow="${pct}"'));
check('information accordion groups table data and credits',app.includes('group(\'Na mesa\'')&&app.includes('group(\'Créditos e edição\''));
check('information accordion groups game context and community',app.includes('group(\'Sobre o jogo\'')&&app.includes('group(\'Na comunidade\''));
check('information accordion groups first steps',app.includes('group(\'Primeiros passos\''));
check('only existing module data is used',app.includes('const facts=[[')&&app.includes('const objective=q.objetivo||mesa.objetivo||mesa.resumo||'));
check('curiosity card maintains the next-curiosity counter contract',app.includes('querySelector(\'.sectionhead .muted\')')&&app.includes('data-curiosity-next'));
check('curiosity source is still a direct link',app.includes('class="curiosity-source" href="${esc(c.fonte)}"'));
check('curiosity section remains omitted when there is no module content',app.includes('if(!Array.isArray(g.curiosidades)||!g.curiosidades.length)return'));

// Evaluate the isolated helpers without requiring a browser.
const sliceFunction=(name,next)=>{const a=app.indexOf('function '+name+'(');if(a<0)throw Error('missing '+name);const b=app.indexOf('\nfunction '+next+'(',a);if(b<0)throw Error('missing next '+next);return app.slice(a,b)};
const helperSrc=sliceFunction('curiosityCardMarkup','quickPlayers');
const profileStart=app.indexOf('function extendedGameProfile(g){');
const profileEnd=app.indexOf('\nconst mechanicGlossary=',profileStart);
const profileSrc=app.slice(profileStart,profileEnd);
const manualStart=app.indexOf(' function manualReadingState(pct){');
const manualEnd=app.indexOf('\n const rulesOptionCount',manualStart);
const manualSrc=app.slice(manualStart,manualEnd);
const curiosityStart=app.indexOf('function curiositySection(g){');
const curiosityEnd=app.indexOf('\nfunction quickPlayers(g)',curiosityStart);
const curiositySrc=app.slice(curiosityStart,curiosityEnd);
const detailStart=app.indexOf('function renderDetail(id){');
const detailEnd=app.indexOf('\nfunction setTab(next)',detailStart);
const detailSrc=app.slice(detailStart,detailEnd);
const view={innerHTML:''},hero={classList:{add(){}}};
const ctx={
 esc:x=>String(x??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c])),
 quickPlayers:g=>g.jogadoresTexto||'2–4',
 gameCompleteness:()=>({filled:8,total:10,pct:80}),
 cover:g=>'manuais/'+g.id+'/cover.webp',manualUrl:(g,m)=>'manuais/'+g.id+'/'+m.arquivo,
 manualsForDisplay:g=>g.manuais||[],gameDescription:g=>g.descricao||'Descrição editorial já cadastrada.',
 quickSheet:()=>'',consultaEntry:()=>'',offlineRefresh:()=>{},
 $:sel=>sel==='#hero'?hero:sel==='#view'?view:null,
 window:{scrollTo(){}},favorites:new Set(),reading:{'sample|manual':100},
 library:[],meepleDetailOpen:false,
 Number,Array,String,Math,
};
vm.createContext(ctx);
vm.runInContext(helperSrc+'\n'+profileSrc+'\n'+manualSrc+'\n'+curiositySrc+'\n'+detailSrc,ctx);
const game={id:'sample',titulo:'Jogo de teste',jogadoresMin:2,jogadoresMax:4,jogadoresTexto:'2–4',duracaoMin:30,duracaoMax:45,idade:8,complexidadeNivel:2,categorias:['Estratégia','Família'],designer:'Designer Exemplo',editora:'Editora Exemplo',ano:2024,fichaRapida:{objetivo:'Objetivo de exemplo.',mecanicas:['Draft','Construção de padrões'],dicas:['Planeje as primeiras escolhas.']},curiosidades:[{titulo:'Curiosidade de exemplo',texto:'Texto já cadastrado no módulo.',fonte:'https://example.com',fonteTexto:'Consultar fonte'}],bggUrl:'https://boardgamegeek.com',manuais:[{nome:'Manual completo',arquivo:'manual.html'}],mesa:{secoes:[]}};
ctx.library=[game];
const profile=ctx.extendedGameProfile(game);
check('runtime profile renders facts, designer, categories and mechanics',profile.includes('JOGADORES')&&profile.includes('DESIGNER')&&profile.includes('Categorias')&&profile.includes('Mecânicas'));
check('runtime profile renders only populated groups',profile.includes('Na mesa')&&profile.includes('Créditos e edição')&&profile.includes('Sobre o jogo')&&profile.includes('Primeiros passos'));
check('runtime curiosity card renders title, text and source separately',ctx.curiosityCardMarkup(game.curiosidades[0]).includes('Curiosidade de exemplo')&&ctx.curiosityCardMarkup(game.curiosidades[0]).includes('Texto já cadastrado')&&ctx.curiosityCardMarkup(game.curiosidades[0]).includes('Consultar fonte'));
check('manual completed status is clear and distinct',ctx.manualReadingState(100).className==='is-complete'&&ctx.manualReadingState(100).label.includes('revisar'));
check('manual partial status offers continuation',ctx.manualReadingState(45).className==='is-reading'&&ctx.manualReadingState(45).label.includes('Continuar'));
check('manual zero status offers first reading',ctx.manualReadingState(0).className==='is-unread'&&ctx.manualReadingState(0).label.includes('Começar'));
ctx.renderDetail('sample');
check('runtime detail view shows the improved cover identity and compact exploration heading',view.innerHTML.includes('FICHA DO JOGO')&&view.innerHTML.includes('Aprenda a jogar, acompanhe a partida ou tire dúvidas.'));
check('runtime detail view labels a completed manual for review',view.innerHTML.includes('Concluído · Toque para revisar')&&view.innerHTML.includes('aria-valuenow="100"'));
check('runtime detail view groups populated information and curiosity content',view.innerHTML.includes('Na mesa')&&view.innerHTML.includes('Créditos e edição')&&view.innerHTML.includes('Além do tabuleiro')&&view.innerHTML.includes('Consultar fonte'));
ctx.reading['sample|manual']=42;ctx.renderDetail('sample');
check('runtime detail view offers continuation for a partially read manual',view.innerHTML.includes('42% lido · Continuar')&&view.innerHTML.includes('aria-valuenow="42"'));
ctx.reading['sample|manual']=0;ctx.renderDetail('sample');
check('runtime detail view offers first reading for a new manual',view.innerHTML.includes('Ainda não iniciado · Começar')&&view.innerHTML.includes('aria-valuenow="0"'));

let failed=0;for(const [name,ok] of checks){console.log((ok?'✓ ':'✗ ')+name);if(!ok)failed++;}
if(failed)process.exit(1);console.log(`\nV293.3: ${checks.length} verificações aprovadas.`);
