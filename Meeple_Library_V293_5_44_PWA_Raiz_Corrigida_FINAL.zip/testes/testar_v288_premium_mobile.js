#!/usr/bin/env node
const fs=require('fs'),assert=require('assert').strict;
const app=fs.readFileSync('index.html','utf8'),sw=fs.readFileSync('sw.js','utf8');
const checks=[
 ['stylesheet V288 presente',app.includes('meeple-v288-premium-mobile')],
 ['paleta escura premium preservada',app.includes('--bg:#071522')&&app.includes('--ac:#4bd1e2')],
 ['tema claro continua disponível',app.includes(':root[data-theme="light"]')],
 ['navegação de cinco áreas preservada',app.includes('data-tab="inicio"')&&app.includes('data-tab="biblioteca"')&&app.includes('data-tab="favoritos"')&&app.includes('data-tab="hub"')&&app.includes('data-tab="ia"')],
 ['CTA da base vazia abre gerenciamento de módulos',app.includes('data-manage-modules')&&app.includes('Adicionar meus jogos')],
 ['resumo da coleção é calculado a partir dos dados locais',app.includes('home-collection-metrics')&&app.includes('manualCount=library.reduce')],
 ['ficha e contratos de módulos mantidos',app.includes('function gameDescription(g)')&&app.includes('function openGuia(id)')&&app.includes('function renderTable(')],
 ['cache offline avança para V289',sw.includes('v293-5-18-meeple-explorer-integration-20261117')],
 ['PWA continua no tema base azul-marinho',/theme_color": "#071522"/.test(fs.readFileSync('manifest.webmanifest','utf8'))]
];
let fail=0;for(const [name,ok] of checks){console.log((ok?'✓ ':'✗ ')+name);if(!ok)fail++}
if(fail)process.exit(1);console.log(`\nV288: ${checks.length} verificações aprovadas.`);
