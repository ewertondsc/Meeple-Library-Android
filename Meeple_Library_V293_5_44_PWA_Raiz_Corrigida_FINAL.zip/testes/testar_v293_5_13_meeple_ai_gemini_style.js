const fs = require('fs');
const html = fs.readFileSync('index.html','utf8');
const sw = fs.readFileSync('sw.js','utf8');
const checks = [
 ['novo shell Meeple AI', /class="ai-page ai-page-premium ai-v3 ai-expert-layout ai-gemini-screen"/.test(html)],
 ['saudação central estilo Gemini', /Como posso ajudar\?/.test(html)],
 ['compositor em fluxo contínuo na versão atual', /meeple-ai-v293-5-16-chat-flow/.test(html) && /ai-gemini-screen \.ai-gemini-composer/.test(html) && /position:relative!important/.test(html.slice(html.indexOf('meeple-ai-v293-5-16-chat-flow')))],
 ['seletor de jogo preservado', /id="aiGame"/.test(html)],
 ['histórico preservado', /id="aiConversationSelect"/.test(html)],
 ['estilos de resposta preservados', /data-ai-mode="rules"/.test(html) && /data-ai-mode="strategy"/.test(html) && /data-ai-mode="situation"/.test(html)],
 ['campo de pergunta preservado', /id="aiQuestion"/.test(html)],
 ['envio preservado', /id="aiSend"/.test(html)],
 ['gestão do teclado móvel', /visualViewport/.test(html) && /ai-gemini-keyboard-open/.test(html)],
 ['cache atualizado', /v293-5-18-meeple-explorer-integration/.test(sw)],
 ['motor Expert carregado', /MeepleExpertCore/.test(html) && fs.existsSync('meeple-expert/js/meeple-engine.js')]
];
let failed=0;
for(const [name,ok] of checks){console.log(`${ok?'PASS':'FAIL'} ${name}`);if(!ok)failed++;}
if(failed)process.exit(1);
