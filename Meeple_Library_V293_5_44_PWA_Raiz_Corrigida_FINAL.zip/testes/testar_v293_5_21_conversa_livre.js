// V293.5.21 — conversas gerais não exigem seleção de jogo
const fs = require('fs');
const html = fs.readFileSync('index.html','utf8');
const engine = fs.readFileSync('meeple-expert/js/meeple-engine.js','utf8');
if (!html.includes('(td bem|tudo bem|tudo bom|td bom')) throw new Error('Chat: saudação abreviada não reconhecida');
if (!engine.includes('td bem') || !engine.includes('td bom')) throw new Error('Expert: saudação abreviada não reconhecida');
if (!html.includes('const social=smallTalkAnswer(question);')) throw new Error('Chat: fluxo de conversa livre ausente');
if (!html.includes('V293.5.21 · Conversa livre sem bloqueio de jogo')) throw new Error('Buildstamp não atualizado');
console.log('OK: saudações abreviadas reconhecidas no Chat e no Meeple Expert');
