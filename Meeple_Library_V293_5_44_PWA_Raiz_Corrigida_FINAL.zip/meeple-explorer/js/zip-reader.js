/* Lightweight ZIP reader for standard STORE/DEFLATE ZIP archives in modern browsers. */
window.MeepleZip = (() => {
  const u16 = (v, o) => v.getUint16(o, true);
  const u32 = (v, o) => v.getUint32(o, true);
  async function inflateRaw(bytes) {
    if (!('DecompressionStream' in window)) throw new Error('Seu navegador não oferece descompactação ZIP nativa. Atualize o Chrome ou Edge.');
    const stream = new Blob([bytes]).stream().pipeThrough(new DecompressionStream('deflate-raw'));
    return await new Response(stream).arrayBuffer();
  }
  async function read(arrayBuffer) {
    const view = new DataView(arrayBuffer); let eocd = -1;
    const start = Math.max(0, arrayBuffer.byteLength - 65557);
    for (let p = arrayBuffer.byteLength - 22; p >= start; p--) {
      if (u32(view, p) === 0x06054b50) { eocd = p; break; }
    }
    if (eocd < 0) throw new Error('O arquivo baixado não é um ZIP válido.');
    const count = u16(view, eocd + 10), cdSize = u32(view, eocd + 12), cdOffset = u32(view, eocd + 16);
    if (count > 2500 || cdOffset + cdSize > arrayBuffer.byteLength) throw new Error('Estrutura ZIP inválida ou com quantidade excessiva de arquivos.');
    const entries = new Map(); let p = cdOffset; let total = 0;
    const decoder = new TextDecoder('utf-8');
    for (let i = 0; i < count; i++) {
      if (u32(view, p) !== 0x02014b50) throw new Error('Índice central do ZIP inválido.');
      const flags = u16(view, p + 8), method = u16(view, p + 10), csize = u32(view, p + 20), usize = u32(view, p + 24);
      const nlen = u16(view, p + 28), elen = u16(view, p + 30), clen = u16(view, p + 32), local = u32(view, p + 42);
      const name = decoder.decode(new Uint8Array(arrayBuffer, p + 46, nlen)).replace(/\\/g, '/');
      p += 46 + nlen + elen + clen;
      if (!name || name.endsWith('/')) continue;
      if (name.startsWith('/') || name.split('/').includes('..')) throw new Error('O ZIP contém um caminho de arquivo inválido.');
      if (flags & 1) throw new Error('O ZIP está protegido por senha; não consigo ler esse módulo.');
      if (usize > 35 * 1024 * 1024) throw new Error('Um arquivo interno excede 35 MB.');
      total += usize; if (total > 120 * 1024 * 1024) throw new Error('O módulo excede o limite de 120 MB.');
      if (u32(view, local) !== 0x04034b50) throw new Error('Um arquivo interno do ZIP está corrompido.');
      const dataStart = local + 30 + u16(view, local + 26) + u16(view, local + 28);
      const compressed = new Uint8Array(arrayBuffer, dataStart, csize);
      let data;
      if (method === 0) data = compressed.slice().buffer;
      else if (method === 8) data = await inflateRaw(compressed);
      else throw new Error(`Método ZIP ${method} não suportado no arquivo ${name}.`);
      if (data.byteLength !== usize) throw new Error(`Falha ao validar o arquivo ${name}.`);
      entries.set(name, data);
    }
    // Ignore common Finder metadata before locating the game manifest.
    for (const name of [...entries.keys()]) if (name.startsWith('__MACOSX/') || name.endsWith('/.DS_Store') || name === '.DS_Store') entries.delete(name);
    // Most modules have one enclosing folder; flatten it for manifest discovery.
    const names = [...entries.keys()];
    if (names.length && names.every(n => n.includes('/')) && new Set(names.map(n => n.split('/')[0])).size === 1) {
      const prefix = names[0].split('/')[0] + '/';
      if (!entries.has('game.json') && !entries.has('module.json')) {
        const flat = new Map(); for (const [k, v] of entries) if (k.startsWith(prefix)) flat.set(k.slice(prefix.length), v);
        if (flat.size) return flat;
      }
    }
    return entries;
  }
  return { read };
})();
