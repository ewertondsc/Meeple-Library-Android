/* Meeple Explorer bridge for Meeple Library V293.5.18.
   Reuses the existing MeepleExpertCore and connects it to the Explorer catalog/Worker.
   No standalone UI, chat, history, or second application storage is introduced. */
(() => {
  'use strict';
  const CATALOG_DEFAULT = 'https://pub-47e83f2fd60d453abc8fabe0d24b89ca.r2.dev/modulos/catalogo.json';
  const WORKER_DEFAULT = 'https://meeple-expert-public-search.ewertonscosta.workers.dev/';
  const DB_NAME = 'meeple-expert-standalone-v2';
  const state = {
    catalog: [], loaded: new Set(), workerOnline: false, workerCompatible: false,
    indexEnabled: false, workerAIEnabled: false, workerModel: '', workerVersion: '',
    settings: { catalogUrl: CATALOG_DEFAULT, workerUrl: WORKER_DEFAULT },
    initPromise: null, dbPromise: null
  };
  const core = () => window.MeepleExpertCore;
  const safeJson = async response => { try { return await response.json(); } catch (_) { return {}; } };
  const text = value => String(value ?? '').trim();
  const pick = (obj, keys) => { for (const key of keys) if (typeof obj?.[key] === 'string' && obj[key].trim()) return obj[key].trim(); return ''; };

  function loadSettings() {
    try {
      const saved = JSON.parse(localStorage.getItem('meepleExpertSettings') || '{}');
      state.settings.catalogUrl = saved.catalogUrl || CATALOG_DEFAULT;
      try {
        const savedWorker = new URL(String(saved.workerUrl || ''));
        state.settings.workerUrl = savedWorker.hostname === 'meeple-expert-public-search.ewertonscosta.workers.dev' ? savedWorker.href : WORKER_DEFAULT;
      } catch (_) { state.settings.workerUrl = WORKER_DEFAULT; }
    } catch (_) {}
    try {
      const saved = JSON.parse(localStorage.getItem('meepleExplorerSettings') || '{}');
      if (saved.catalogUrl) state.settings.catalogUrl = saved.catalogUrl;
      if (saved.workerUrl) state.settings.workerUrl = saved.workerUrl;
    } catch (_) {}
  }
  function asArray(value) {
    if (Array.isArray(value)) return value;
    if (value && typeof value === 'object') return Object.entries(value).map(([id, item]) => typeof item === 'object' ? { id, ...item } : { id, zip: item });
    return [];
  }
  function catalogItems(json) {
    if (Array.isArray(json)) return json;
    for (const key of ['modulos','modules','jogos','games','items','itens','catalogo','catalog','data']) {
      if (json && json[key] != null) { const values = asArray(json[key]); if (values.length) return values; }
    }
    return json && typeof json === 'object' ? Object.entries(json).filter(([,v]) => v && typeof v === 'object').map(([id,v]) => ({id,...v})) : [];
  }
  function normalizeItem(item, baseUrl) {
    const id = text(item.id || item.slug || item.codigo || item.gameId || item.jogoId).toLowerCase();
    const title = pick(item, ['titulo','title','nome','name','jogo','game']) || id;
    let zip = pick(item, ['zip','zipUrl','zip_url','urlZip','url_zip','arquivoZip','arquivo_zip','download','downloadUrl','download_url','urlDownload','moduloZip','moduleZip','module','moduleUrl','module_url','urlModulo','url_modulo','arquivoModulo','arquivo_modulo','zipFile','zip_file','fileName','filename','arquivo','file','path','caminho','link','href']);
    if (zip && !/^https?:\/\//i.test(zip)) {
      if (zip.startsWith('/')) zip = new URL(zip, new URL(baseUrl).origin).href;
      else if (zip.startsWith('modulos/')) zip = new URL('../' + zip, baseUrl).href;
      else zip = new URL(zip, baseUrl).href;
    }
    if (!zip && id) zip = new URL(`${id}.zip`, baseUrl).href;
    return { ...item, id, title, zipUrl: zip, aliases: Array.isArray(item.aliases) ? item.aliases : (Array.isArray(item.sinonimos) ? item.sinonimos : []) };
  }
  function workerPath(path = '') {
    const base = text(state.settings.workerUrl);
    if (!base) throw new Error('Worker do Meeple Explorer não configurado.');
    return new URL(String(path).replace(/^\//, ''), base.endsWith('/') ? base : base + '/').href;
  }
  async function checkWorker() {
    state.workerOnline = state.workerCompatible = state.indexEnabled = state.workerAIEnabled = false;
    state.workerModel = ''; state.workerVersion = '';
    try {
      const controller = new AbortController();
      const timer = setTimeout(() => controller.abort(), 8000);
      let response; try { response = await fetch(state.settings.workerUrl, { method: 'GET', mode: 'cors', cache: 'no-store', signal: controller.signal }); } finally { clearTimeout(timer); }
      const data = await safeJson(response);
      state.workerOnline = response.ok && (data.status === 'online' || data.service || data.ok === true);
      state.workerCompatible = ['5.4','5.5'].includes(String(data.version)) && data.searchEnabled === true;
      state.indexEnabled = String(data.version) === '5.5' && data.moduleIndexEnabled === true;
      state.workerAIEnabled = data.aiEnabled === true;
      state.workerModel = data.model || data.provider || '';
      state.workerVersion = String(data.version || '');
    } catch (error) { console.warn('[Meeple Explorer] Worker indisponível:', error); }
    return state.workerOnline;
  }
  async function loadCatalog() {
    const controller = new AbortController();
    const timer = setTimeout(() => controller.abort(), 8000);
    let response; try { response = await fetch(state.settings.catalogUrl, { cache: 'no-store', signal: controller.signal }); } finally { clearTimeout(timer); }
    if (!response.ok) throw new Error(`Catálogo Explorer indisponível (HTTP ${response.status}).`);
    const payload = await response.json();
    const baseUrl = new URL('.', state.settings.catalogUrl).href;
    const items = catalogItems(payload).map(item => normalizeItem(item, baseUrl)).filter(item => item.id && item.zipUrl);
    if (!items.length) throw new Error('O catálogo Explorer não contém módulos reconhecíveis.');
    state.catalog = items;
    for (const item of items) core()?.addGame({ id: item.id, title: item.title, aliases: [item.id, ...(item.aliases || [])], source: 'meeple-explorer-catalog' });
    return items;
  }
  function init() {
    if (state.initPromise) return state.initPromise;
    loadSettings();
    state.initPromise = Promise.allSettled([loadCatalog(), checkWorker()]).then(results => {
      const catalogResult = results[0];
      if (catalogResult.status === 'rejected') console.warn('[Meeple Explorer] Catálogo não carregado:', catalogResult.reason);
      if (!state.workerOnline) console.warn('[Meeple Explorer] Worker não respondeu ao teste inicial.');
      return { catalogCount: state.catalog.length, workerOnline: state.workerOnline, workerCompatible: state.workerCompatible, indexEnabled: state.indexEnabled, version: state.workerVersion };
    });
    return state.initPromise;
  }
  function openDB() {
    if (!('indexedDB' in window)) return Promise.reject(new Error('IndexedDB não disponível.'));
    if (!state.dbPromise) state.dbPromise = new Promise((resolve, reject) => {
      const request = indexedDB.open(DB_NAME, 1);
      request.onupgradeneeded = () => { if (!request.result.objectStoreNames.contains('modules')) request.result.createObjectStore('modules', { keyPath: 'id' }); };
      request.onsuccess = () => resolve(request.result); request.onerror = () => reject(request.error);
    });
    return state.dbPromise;
  }
  async function getCached(id) {
    try { const db = await openDB(); return await new Promise((resolve, reject) => { const request = db.transaction('modules').objectStore('modules').get(id); request.onsuccess = () => resolve(request.result || null); request.onerror = () => reject(request.error); }); }
    catch (_) { return null; }
  }
  async function putCached(data) {
    try { const db = await openDB(); await new Promise((resolve, reject) => { const tx = db.transaction('modules','readwrite'); tx.objectStore('modules').put(data); tx.oncomplete = resolve; tx.onerror = () => reject(tx.error); }); }
    catch (error) { console.warn('[Meeple Explorer] Cache local indisponível:', error); }
  }
  async function remoteModuleIndex(gameId) {
    if (!state.indexEnabled || !gameId) return null;
    try {
      const url = new URL(workerPath('module-index'));
      url.searchParams.set('gameId', String(gameId));
      const response = await fetch(url.href, { method: 'GET', mode: 'cors', cache: 'no-store' });
      if (!response.ok) return null;
      const data = await safeJson(response);
      return data.exists ? data : null;
    } catch (_) { return null; }
  }
  function extractText(html) {
    const doc = new DOMParser().parseFromString(String(html || ''), 'text/html');
    doc.querySelectorAll('script,style,noscript,svg,canvas,iframe,nav,footer,header,button').forEach(node => node.remove());
    return String(doc.body?.innerText || doc.body?.textContent || '').replace(/\u00a0/g,' ').replace(/[ \t]+/g,' ').replace(/\n{3,}/g,'\n\n').trim();
  }
  function structuredNodeText(node) {
    const clone = node.cloneNode(true);
    clone.querySelectorAll('script,style,noscript,svg,canvas,iframe,button,summary').forEach(n => n.remove());
    clone.querySelectorAll('table').forEach(table => {
      const rows = [...table.querySelectorAll('tr')].map(tr => [...tr.querySelectorAll('th,td')].map(cell => (cell.innerText || cell.textContent || '').replace(/\s+/g,' ').trim()).filter(Boolean)).filter(row => row.length);
      if (!rows.length) return;
      const headers = rows[0], hasHeader = !!table.querySelector('tr th');
      const lines = hasHeader && rows.length > 1 ? rows.slice(1).map(row => row.map((value,index) => headers[index] ? `${headers[index]}: ${value}` : value).join(' | ')) : rows.map((row,index) => `Linha ${index+1}: ${row.join(' | ')}`);
      table.replaceWith(clone.ownerDocument.createTextNode('\n' + lines.join('\n') + '\n'));
    });
    clone.querySelectorAll('li').forEach(li => { li.insertBefore(clone.ownerDocument.createTextNode('• '), li.firstChild); li.append(clone.ownerDocument.createTextNode('\n')); });
    clone.querySelectorAll('br').forEach(br => br.replaceWith(clone.ownerDocument.createTextNode('\n')));
    return String(clone.innerText || clone.textContent || '').replace(/\u00a0/g,' ').replace(/[ \t]+/g,' ').replace(/\n[ \t]+/g,'\n').replace(/\n{3,}/g,'\n\n').trim();
  }
  function makeDoc(game, title, body, manual, file, expansion, sectionId) {
    return { id: `${game.id}::${file}::${sectionId}`, gameId: game.id, game: game.title, title, text: body, manual: manual || 'Manual do jogo', manualFile: file, isExpansion: !!expansion, sectionId, url: '', isRemote: true };
  }
  function docsFromHTML(html, game, manualName, manualFile, isExpansion) {
    const doc = new DOMParser().parseFromString(String(html || ''), 'text/html');
    doc.querySelectorAll('script,style,noscript,svg,canvas,iframe,nav,footer,header,button').forEach(node => node.remove());
    const body = doc.body; if (!body) return [];
    const out = [];
    const topics = [...body.querySelectorAll('details.topic,section.chapter,article.chapter,[data-chapter]')];
    if (topics.length) topics.forEach((topic,index) => {
      const summary = topic.querySelector(':scope > summary') || topic.querySelector('summary');
      const title = (summary?.innerText || summary?.textContent || topic.getAttribute('data-title') || `Seção ${index+1}`).replace(/toque para expandir/ig,'').trim();
      const clone = topic.cloneNode(true); clone.querySelectorAll('summary').forEach(n => n.remove());
      const content = structuredNodeText(clone);
      if (content.length > 25) out.push(makeDoc(game,title,content,manualName,manualFile,isExpansion,topic.id || `${manualFile}::topic${index}`));
    });
    if (out.length) return out;
    const headings = [...body.querySelectorAll('h1,h2,h3,h4,[role="heading"]')];
    headings.forEach((heading,index) => {
      const title = (heading.innerText || heading.textContent || '').trim(); if (!title) return;
      const parts = []; let node = heading.nextElementSibling;
      while (node && !/^H[1-4]$/.test(node.tagName)) { const content = structuredNodeText(node); if (content) parts.push(content); node = node.nextElementSibling; }
      const content = parts.join('\n\n').trim();
      if (content.length > 25) out.push(makeDoc(game,title,content,manualName,manualFile,isExpansion,`${manualFile}::h${index}`));
    });
    if (!out.length) { const all = extractText(html); if (all.length > 40) out.push(makeDoc(game,manualName || 'Manual completo',all,manualName,manualFile,isExpansion,manualFile)); }
    return out;
  }
  function manifestToDocs(game, files) {
    const docs = [];
    const summary = game.resumo || game.descricao || game.description || game.mesa?.resumo || '';
    if (summary) docs.push(makeDoc(game,'Resumo do jogo',summary,'Ficha do jogo','game.json',false,'summary'));
    const sections = game.mesa?.secoes || game.secoes || game.regrasRapidas?.secoes || [];
    sections.forEach((section,index) => {
      const body = [section.resumo,section.texto,section.text,...(Array.isArray(section.itens)?section.itens:[]),...(Array.isArray(section.linhas)?section.linhas.flat():[])].filter(Boolean).join(' ');
      if (body.trim()) docs.push(makeDoc(game,section.titulo || section.title || section.busca || `Regra ${index+1}`,body,'Ficha rápida / regras estruturadas','game.json',false,`table-${index}`));
    });
    for (const manual of (Array.isArray(game.manuais) ? game.manuais : [])) {
      const name = manual.nome || manual.name || manual.arquivo || 'Manual';
      const file = manual.arquivo || manual.file || manual.path; if (!file || !files.has(file)) continue;
      docs.push(...docsFromHTML(new TextDecoder('utf-8').decode(files.get(file)),game,name,file,!!(manual.expansao || manual.expansion)));
    }
    if (!docs.length) for (const [name,raw] of files) if (/\.html?$/i.test(name)) docs.push(...docsFromHTML(new TextDecoder('utf-8').decode(raw),game,name,name,false));
    return docs;
  }
  async function loadRemoteModule(item) {
    const cached = await getCached(item.id);
    if (cached?.game && cached?.documents?.length) {
      core()?.registerModule({ game: cached.game, documents: cached.documents, zipUrl: item.zipUrl });
      state.loaded.add(item.id); return { loaded: true, cached: true, docs: cached.documents.length };
    }
    const response = await fetch(item.zipUrl, { cache: 'no-store' });
    if (!response.ok) throw new Error(`ZIP ${item.title}: HTTP ${response.status}.`);
    const entries = await window.MeepleZip.read(await response.arrayBuffer());
    const manifest = entries.get('game.json') || entries.get('module.json');
    if (!manifest) throw new Error(`O módulo ${item.title} não contém game.json na raiz.`);
    const game = JSON.parse(new TextDecoder('utf-8').decode(manifest));
    game.id = String(game.id || item.id).toLowerCase();
    game.title = game.title || game.titulo || game.nome || item.title;
    game.zipUrl = item.zipUrl;
    game.aliases = [...(game.aliases || []), ...(item.aliases || []), item.title, item.id];
    const documents = manifestToDocs(game, entries);
    if (!documents.length) throw new Error(`Não encontrei regras dentro do módulo ${item.title}.`);
    core()?.registerModule({ game, documents, zipUrl: item.zipUrl });
    state.loaded.add(item.id);
    await putCached({ id: item.id, game, documents, cachedAt: Date.now() });
    return { loaded: true, cached: false, docs: documents.length };
  }
  async function ensureGame(gameId) {
    await init();
    const id = String(gameId || '').toLowerCase();
    if (!id) return { available: false, reason: 'missing-game-id' };
    const item = state.catalog.find(entry => entry.id === id);
    if (!item) return { available: !!core()?.gameCatalog?.has?.(id), local: true };
    const hasLocalDocs = (core()?.documents || []).some(doc => String(doc.gameId || '') === id);
    if (hasLocalDocs || state.loaded.has(id)) return { available: true, local: true };
    const index = await remoteModuleIndex(id);
    if (index) {
      core()?.addGame({ id: item.id, title: item.title, aliases: [item.id, ...(item.aliases || [])], source: 'meeple-explorer-r2-index' });
      return { available: true, remoteIndex: true, index };
    }
    try { return { available: true, ...(await loadRemoteModule(item)) }; }
    catch (error) {
      console.warn(`[Meeple Explorer] Não consegui carregar ${item.title} localmente; a pesquisa externa ainda será tentada.`, error);
      core()?.addGame({ id: item.id, title: item.title, aliases: [item.id, ...(item.aliases || [])], source: 'meeple-explorer-catalog' });
      return { available: true, remoteIndex: false, loadError: error.message };
    }
  }
  function localEvidence(local, game) {
    return {
      status: local?.status || 'not_found', confidence: local?.confidence || 'baixa',
      answer: String(local?.answer || '').slice(0,2400),
      hits: (local?.hits || []).slice(0,8).map(hit => ({
        manual: hit.manual || 'Manual local', section: hit.section || hit.title || 'Seção',
        excerpt: String(hit.excerpt || hit.text || '').slice(0,1500), expansion: !!hit.isExpansion,
        url: hit.url || '', page: hit.page || null, ruleEvidenceId: hit.ruleEvidenceId || ''
      })), ruleValidation: local?.ruleValidation || null
    };
  }
  function passHistory(question, history) {
    const c = core();
    const explicit = c?.detectGame?.(question,'',[])?.id;
    return !explicit && !!c?.isContextDependentQuery?.(question) ? (history || []).slice(-4) : [];
  }
  async function search(question, game, local, history) {
    await init();
    if (!state.workerCompatible) await checkWorker();
    if (!state.workerCompatible) throw new Error('Worker do Meeple Explorer indisponível ou incompatível. O motor local continua disponível.');
    const gameObject = typeof game === 'object' && game ? game : null;
    const gameId = gameObject?.id || '';
    if (gameId) await ensureGame(gameId);
    const gameTitle = gameObject?.title || gameObject?.titulo || (typeof game === 'string' ? game : '') || 'Jogo de tabuleiro';
    const controller = new AbortController();
    const timeout = setTimeout(() => controller.abort(), 65000);
    try {
      const response = await fetch(state.settings.workerUrl, {
        method: 'POST', mode: 'cors', cache: 'no-store', signal: controller.signal,
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          query: String(question || '').slice(0,1200), game: gameTitle, gameId, language: 'pt-BR',
          comparisonGames: Array.isArray(gameObject?.games) ? gameObject.games.slice(0,4).map(item => ({ id: text(item.id), title: text(item.title || item.titulo) })).filter(item => item.id || item.title) : [],
          localEvidence: localEvidence(local, gameTitle),
          history: passHistory(question, history).map(item => ({ role: item.role, text: String(item.text || '').slice(0,650) }))
        })
      });
      const data = await safeJson(response);
      if (!response.ok) throw new Error(data.error || `Pesquisa do Meeple Explorer falhou (HTTP ${response.status}).`);
      if (!Array.isArray(data.sources) && !Array.isArray(data.results)) throw new Error('O Meeple Explorer não retornou fontes em formato utilizável.');
      state.workerAIEnabled = !!data.aiEnabled;
      return {
        ...data,
        sources: Array.isArray(data.sources) ? data.sources : (Array.isArray(data.results) ? data.results : []),
        searchQueries: Array.isArray(data.searchQueries) ? data.searchQueries : [],
        assessment: data.assessment || 'SEM CLASSIFICAÇÃO',
        explorerVersion: '5.9'
      };
    } catch (error) {
      if (error.name === 'AbortError') throw new Error('A consulta do Meeple Explorer passou de 65 segundos e foi interrompida.');
      if (error instanceof TypeError) throw new Error('Não consegui acessar o Worker do Meeple Explorer. Verifique CORS e publicação.');
      throw error;
    } finally { clearTimeout(timeout); }
  }
  window.MeepleExplorerBridge = {
    init, ready: init, ensureGame, search,
    getCatalog: () => state.catalog.slice(),
    getStatus: () => ({ catalogCount: state.catalog.length, workerOnline: state.workerOnline, workerCompatible: state.workerCompatible, indexEnabled: state.indexEnabled, aiEnabled: state.workerAIEnabled, model: state.workerModel }),
    getGame: id => state.catalog.find(item => item.id === String(id || '').toLowerCase()) || null
  };
  init();
})();
