/* Meeple Expert 3.4 — evidence-based board-game specialist and conversation engine.
   It ranks evidence from rulebooks; it does not generate unsupported rules. */
(function(root){
 'use strict';
 const DATA=root.MEEPLE_EXPERT_DATA||{};
 const BASE=DATA.knowledgeBase||{games:[],documents:[]};
 const SYN=root.MEEPLE_SYNONYMS||DATA.synonyms||{groups:[],slang:{}};
 const GLOSSARY=(root.MEEPLE_HOBBY_GLOSSARY||{}).entries||[];
 const GAME_DOSSIERS=(root.MEEPLE_GAME_DOSSIERS||{}).games||{};
 const FAQ_BANK=(root.MEEPLE_FAQ_BANK||{}).games||{};
 const SETUP_FACTS=(root.MEEPLE_SETUP_FACTS||{}).games||{};
 const PLAYER_SETUP=(root.MEEPLE_PLAYER_SETUP_MATRIX||{}).games||{};
 let FAQ_INDEX=new Map();
 const MEMORY_KEY='meepleExpertKnowledgeMemoryV1';
 const MEMORY_VERSION='3.8';
 const STOP=new Set(('a o as os um uma uns umas de da do das dos em na no nas nos por para com sob sobre ao aos e ou que se qual quais quanto quantos quantas como quando onde quem eu meu minha meus minhas voce voces ele ela eles elas isso isto esse essa esses essas este esta estes estas ser sao foi era pode posso podem devo deve devem tem tenho ter ha mais menos muito ja sim so tambem entao mas me te lhe seu sua vez vezes fazer faz fazem acontece acontecem fica ficam preciso poderia gostaria favor diga explique ai aqui la nele nela neles nelas').split(' '));
 const IMPORTANT=new Set(['nao','nunca','jamais','sem','antes','depois','durante','ate','apenas','somente','exceto','salvo','cada','qualquer','todos','todo','toda','nenhum','nenhuma','mais','menos','exatamente','pelo','menos']);
 const norm=s=>String(s??'').normalize('NFD').replace(/[\u0300-\u036f]/g,'').toLocaleLowerCase('pt-BR').replace(/&/g,' e ').replace(/[^a-z0-9]+/g,' ').replace(/\s+/g,' ').trim();
 const phraseSlang=Object.entries(SYN.slang||{}).filter(([k])=>String(k).includes(' ')).sort((a,b)=>b[0].length-a[0].length);
 const SLANG={...(SYN.slang||{}),vc:'voce',vcs:'voces',ce:'voce',tbm:'tambem',tb:'tambem',pq:'porque',porq:'porque',q:'que',oq:'o que',qdo:'quando',qnd:'quando',kd:'onde',cade:'onde',hj:'hoje',dps:'depois',dp:'depois',agr:'agora',to:'estou',ta:'esta',tava:'estava',n:'nao',naum:'nao',mt:'muito',mto:'muito',qnt:'quanto',qnts:'quantos',obg:'obrigado',jgo:'jogo',jgos:'jogos',regars:'regras',regrs:'regras',pontucao:'pontuacao',carcasone:'carcassonne',carcassone:'carcassonne',catam:'catan',harmonis:'harmonies',tikete:'ticket',azull:'azul',expanssao:'expansao',manuaal:'manual',bilhite:'bilhete'};
 function normalizeQuery(s){let v=norm(s);for(const [a,b] of phraseSlang){const na=norm(a);if(na&&(` ${v} `).includes(` ${na} `))v=` ${v} `.replace(` ${na} `,` ${norm(b)} `).trim();}return v.split(' ').map(w=>SLANG[w]||w).join(' ');}
 function stem(w){w=norm(w);if(w.length>8)w=w.replace(/(mente|amentos|imentos|amento|imento)$/,'');if(w.length>6)w=w.replace(/(oes|aes|eis)$/,'ao');if(w.length>5)w=w.replace(/(ando|endo|indo)$/,'');if(w.length>5)w=w.replace(/(aram|eram|iram|ados|adas|idos|idas)$/,'');if(w.length>5)w=w.replace(/(es|s)$/,'');return w;}
 function tokenize(s){return normalizeQuery(s).split(' ').filter(Boolean).map(stem).filter(w=>w&&(!STOP.has(w)||IMPORTANT.has(w)));}
 FAQ_INDEX=new Map(Object.entries(FAQ_BANK).map(([id,g])=>[id,(g.questions||[]).map(f=>({...f,tokens:new Set(tokenize(f.q))}))]));
 const groups=SYN.groups||[];
 const aliasEntries=[];
 const groupIndex=new Map();
 const GENERIC_CONCEPTS=new Set(['jogabilidade','regra','pedido_explicacao','erro_duvida','pergunta_possibilidade','pergunta_condicional','pergunta_ausencia','pergunta_quantidade','pergunta_tempo','pergunta_sequencia','pergunta_obrigatoriedade','pergunta_proibicao','pergunta_frequencia','pergunta_preferencia','pergunta_recurso_falta','pergunta_cartas_zeradas','pergunta_tabuleiro_cheio','pergunta_jogador_sem_pecas','pergunta_jogador_eliminado','pergunta_erro_jogada','pergunta_retroativo','pergunta_expansao','pergunta_edicao','pergunta_jogadores','pergunta_idade','pergunta_duracao','pergunta_complexidade','pergunta_dependencia_idioma','pergunta_componentes','pergunta_objetivo','pergunta_turno','pergunta_pontuacao','pergunta_final','pergunta_estrategia','pergunta_interacao','pergunta_sorte','pergunta_regras_oficiais']);
 const WEAK_GENERIC_ALIASES=new Set(['como funciona','como jogar','regra','regras','manual','explicacao','explicar','me explica','me explique','explica melhor','nao entendi','pode explicar','tem como','da pra','da para','consigo','e possivel','posso fazer','existe alguma maneira','ha como']);
 groups.forEach((g,gi)=>{
   const aliases=[g.canonical,...(g.aliases||[])];
   for(const alias of aliases){const a=norm(alias);if(!a)continue;const prev=groupIndex.get(a);if(!prev||String(g.canonical).length>String(prev.canonical).length)groupIndex.set(a,g);aliasEntries.push({alias:a,group:g,gi});}
 });
 aliasEntries.sort((a,b)=>b.alias.length-a.alias.length);
 const gameCatalog=new Map(),gameAlias=[];
 function addGame(game){if(!game||!game.id)return;const g={...game,id:String(game.id),title:game.title||game.titulo||game.nome||game.name||String(game.id)};gameCatalog.set(g.id,g);const aliases=[g.title,g.titulo,g.nome,g.name,g.id,...(g.aliases||[]),...(g.sinonimos||[])].filter(Boolean);for(const a of aliases){const alias=norm(a);if(alias&&!gameAlias.some(x=>x.id===g.id&&x.alias===alias))gameAlias.push({id:g.id,alias});}gameAlias.sort((a,b)=>b.alias.length-a.alias.length);}
 (BASE.games||[]).forEach(addGame);
 const documents=[...(BASE.documents||[])];
 let docIndex=[];let idf=new Map();
 function rebuildIndex(){
   docIndex=documents.map((d,i)=>{const title=norm(d.title||d.section||''),text=norm(d.text||''),all=title+' '+text,toks=tokenize(all),tf=new Map();toks.forEach(t=>tf.set(t,(tf.get(t)||0)+1));return {d,i,title,text,all,tf,len:toks.length||1};});
   const df=new Map();for(const x of docIndex)for(const t of x.tf.keys())df.set(t,(df.get(t)||0)+1);
   idf=new Map();const n=Math.max(1,docIndex.length);for(const [t,f] of df)idf.set(t,Math.log(1+(n-f+.5)/(f+.5)));
 }
 function registerModule(module){const game=module.game||module;addGame(game);if(root.MeepleRuleInteractions)root.MeepleRuleInteractions.registerModule(game);let changed=false;for(const d of module.documents||[]){const text=String(d.text||'');const noisy=(text.match(/"(?:type|html|blocks|chapter|ordered)"\s*:/g)||[]).length;if(noisy>=3||/^\s*[\[{].{0,120}"(?:type|html|blocks)"/s.test(text))continue;const key=String(game.id)+'|'+norm(d.title||d.section||'')+'|'+norm(text.slice(0,180));if(documents.some(x=>String(x.gameId)===String(game.id)&&String(x._dedupeKey||'')===key))continue;documents.push({...d,gameId:d.gameId||game.id,game:d.game||game.title||game.titulo||game.nome,isRemote:true,zipUrl:module.zipUrl||game.zipUrl||'',_dedupeKey:key});changed=true;}if(changed)rebuildIndex();}
 rebuildIndex();
 function detectIntent(q){const s=normalizeQuery(q);
  const rules=[
   ['voting',/(vota|voto|equipe aprovada|equipe rejeitada|aprovar equipe|rejeitar equipe|rejeitad|aprovad|maioria|empat|empate na votacao)/],
   ['trade',/(troca|trocar|negoci|comerc|banco|porto|taxa de troca|pagar|custo|recurso)/],
   ['strategy',/(estrateg|melhor jogada|melhor caminho|melhor forma de|melhor maneira de|planej|prioriz|recomend|o que devo fazer|como maximizar)/],
   ['scoring',/(pontu|ponto|placar|escore|score|bonus|desempate|vale quanto|quantos pontos|marcar pontos|contagem final|nao completar|nao cumprir|penalidade|perde pontos|perder pontos)/],
   ['setup',/(prepar|montag|setup|comecar a partida|inicio do jogo|arrumar a mesa|primeiro jogador)/],
   ['endgame',/(fim da partida|fim do jogo|termina a partida|termina o jogo|encerra a partida|encerra o jogo|ultima rodada|gatilho de fim|quando vence|quando acaba o jogo|quando acaba a partida)/],
   ['permission',/(posso|pode|permit|nao pode|nao posso|proibid|vedado|obrigad|tenho que|preciso fazer)/],
   ['purchase',/(compr|pegar|retirar|receber|obter|adquir|repor|mercado|comprar carta)/],
   ['turn',/(turno|minha vez|ordem de jogo|rodada|fase|passar a vez|acao extra)/],
   ['victory',/(vencer|ganhar|objetivo|condicao de vitoria|meta principal)/],
   ['cards',/(carta|baralho|mao|bilhete|deck|descarte|monte)/],
   ['movement',/(mover|moviment|rota|caminho|trilho|desloc|adjacente|alcance)/],
   ['exception',/(exce|caso especial|restri|limite|exceto|salvo|nao houver|esgot|acab|falta|sobra|sobrou|restante|sem recurso|ficar sem|nao tiver)/],
   ['components',/(component|peca|meeple|cubo|marcador|dado|tabuleiro|ficha)/],
   ['combat',/(combate|ataque|atacar|defesa|defender|dano|vida|captur)/],
   ['interaction',/(roubar|bloquear|adversario|oponente|conflito|atrapalhar|eliminar)/]
  ];for(const [k,re] of rules)if(re.test(s))return k;return 'general';
 }
 function levenshtein(a,b,lim=2){if(Math.abs(a.length-b.length)>lim)return lim+1;let p=Array.from({length:b.length+1},(_,i)=>i);for(let i=1;i<=a.length;i++){let c=[i],m=i;for(let j=1;j<=b.length;j++){c[j]=Math.min(c[j-1]+1,p[j]+1,p[j-1]+(a[i-1]===b[j-1]?0:1));m=Math.min(m,c[j]);}if(m>lim)return lim+1;p=c;}return p[b.length];}
 function isContextDependentQuery(text){
  const n=normalizeQuery(text);
  return /^(?:e\s+(?:se|para|com|no|na|quando|quantos|qual|nesse|nessa|no mesmo|na mesma|o caso|a jangada|o tubarao|a serpente|o kaiju|ele|ela|eles|elas)|entao\b|nesse caso\b|nessa situacao\b|nesse jogo\b|nessa partida\b|isso\b|essa regra\b|essa criatura\b|e depois\b|e antes\b|como assim\b|por que isso\b)/.test(n);
 }
 function detectGame(q,selected,history=[]){
  const findIn=text=>{
   const n=normalizeQuery(text),r=norm(text),found=[];
   if(/\b(?:pro|no|do|jogo|sobre o jogo) fica\b/.test(r))found.push('finca');
   // Preserve exact raw title matching alongside colloquial normalization. This is
   // important for English titles containing words that also exist in Portuguese
   // slang (for example, "to" -> "estou" in "Ticket to Ride Europa").
   for(const a of gameAlias){if(a.alias.length>2&&((` ${n} `).includes(` ${a.alias} `)||(` ${r} `).includes(` ${a.alias} `))&&!found.includes(a.id))found.push(a.id);}
   // Regras locais empacotadas também identificam o jogo, mesmo antes do módulo completo ser instalado.
   for(const pack of (root.MEEPLE_RULE_INTERACTION_PACKS?.packs||[])){
    const aliases=(pack.gameAliases||[]).map(norm).filter(Boolean);
    if(pack.gameId&&aliases.some(alias=>(` ${n} `).includes(` ${alias} `))&&!found.includes(pack.gameId))found.push(pack.gameId);
   }
   if(!found.length){const words=n.split(' ');for(const a of gameAlias){if(a.alias.length<5||a.alias.includes(' '))continue;if(words.some(w=>w.length>=5&&levenshtein(w,a.alias,1)<=1)&&!found.includes(a.id))found.push(a.id);}}
   return found;
  };
  const found=findIn(q);
  if(found.length>1){
   // O jogo escolhido no seletor é uma decisão explícita do usuário. Quando o
   // título/alias selecionado também aparece entre as correspondências, ele
   // deve prevalecer sobre colisões de aliases de outros jogos (ex.: Rummikub).
   const selectedId=String(selected||'');
   const selectedIsRegistered=selectedId&&(gameCatalog.has(selectedId)||(root.MEEPLE_RULE_INTERACTION_PACKS?.packs||[]).some(pack=>String(pack.gameId)===selectedId));
   if(selectedIsRegistered&&found.includes(selectedId))return {id:selectedId,fromSelection:true,matched:found.slice()};
   const ranked=found.sort((a,b)=>norm(gameCatalog.get(b)?.title||b).length-norm(gameCatalog.get(a)?.title||a).length);const first=ranked[0],second=ranked[1];if(norm(gameCatalog.get(first)?.title||first).length>=norm(gameCatalog.get(second)?.title||second).length+3)return {id:first};return {ambiguous:true,found:ranked};
  }
  if(found.length===1)return {id:found[0]};
  if(selected&&(gameCatalog.has(String(selected))||(root.MEEPLE_RULE_INTERACTION_PACKS?.packs||[]).some(pack=>String(pack.gameId)===String(selected))))return {id:String(selected)};
  if(isContextDependentQuery(q)){for(let i=(history||[]).length-1;i>=0;i--){const h=history[i];if(h?.role!=='user')continue;const prev=findIn(h.text||'');if(prev.length===1)return {id:prev[0],fromContext:true};if(prev.length>1)return {ambiguous:true,found:prev};}}
  return {id:null};
 }
 function matchConcepts(qNorm){const found=[];const seen=new Set();for(const e of aliasEntries){if(e.alias.length<4)continue;if(GENERIC_CONCEPTS.has(e.group.concept)&&WEAK_GENERIC_ALIASES.has(e.alias)&&e.alias!==norm(e.group.canonical))continue;if((` ${qNorm} `).includes(` ${e.alias} `)&&!seen.has(e.gi)){seen.add(e.gi);found.push({group:e.group,alias:e.alias});if(found.length>=8)break;}}return found;}
 function expandTokens(question){const q=normalizeQuery(question),base=tokenize(q),set=new Map();for(const t of base)if(!STOP.has(t)||IMPORTANT.has(t))set.set(t,1);
  const concepts=matchConcepts(q);
  for(const {group,alias} of concepts){for(const t of tokenize(group.canonical))set.set(t,Math.max(set.get(t)||0,1.6));
    // Search-language alternatives are lower-weighted: they widen recall without overriding the manual's wording.
    const aliasTerms=new Map();for(const a of group.aliases||[]){for(const t of tokenize(a)){if(t.length>2&&!STOP.has(t))aliasTerms.set(t,Math.max(aliasTerms.get(t)||0,0.38));}}
    for(const [t,w] of aliasTerms)if(!set.has(t))set.set(t,w);
    for(const t of tokenize(alias))set.set(t,Math.max(set.get(t)||0,1.15));
  }
  set.baseCount=Math.max(1,new Set(base.filter(t=>!STOP.has(t)||IMPORTANT.has(t))).size);set.concepts=concepts;set.baseTerms=base;
  // Typo correction uses only vocabulary words of the same length band, and keeps the original token.
  const vocab=wordVocabulary();for(const t of base){if(t.length<5||vocab.has(t))continue;let best=null,candidates=0;for(const v of vocab){if(Math.abs(v.length-t.length)>1)continue;if(levenshtein(t,v,1)===1){best=v;candidates++;if(candidates>1)break;}}if(best&&candidates===1)set.set(best,Math.max(set.get(best)||0,.62));}
  return set;}
 let cachedVocab=null;function wordVocabulary(){if(cachedVocab)return cachedVocab;cachedVocab=new Set();for(const g of groups){for(const p of [g.canonical,...(g.aliases||[])])for(const t of tokenize(p))if(t.length>=5)cachedVocab.add(t);}for(const g of gameCatalog.values())for(const a of [g.title,...(g.aliases||[])])for(const t of tokenize(a))if(t.length>=5)cachedVocab.add(t);return cachedVocab;}
 function removeMetaTemporalPhrases(value){
  // Expressões sobre como o assistente deve responder não descrevem a ordem de ações do jogo.
  return String(value||'')
   .replace(/\bantes de (?:responder(?: a pergunta)?|dar a resposta|consultar(?: o manual| as fontes)?|pesquisar|buscar|procurar|verificar|explicar|escrever)\b/g,' ')
   .replace(/\bdepois de (?:responder(?: a pergunta)?|dar a resposta|consultar(?: o manual| as fontes)?|pesquisar|buscar|procurar|verificar|explicar|escrever)\b/g,' ')
   .replace(/\bantes que eu (?:responda|consulte|pesquise|verifique|explique)\b/g,' ')
   .replace(/\bdepois que eu (?:responder|consultar|pesquisar|verificar|explicar)\b/g,' ')
   .replace(/\s+/g,' ').trim();
 }
 function splitScenarioParts(question){
  const raw=String(question||'').replace(/\s+/g,' ').trim();
  if(!raw)return [];
  const parts=raw.split(/(?<=\?)\s+(?=e se\b)|;\s*(?=e se\b)/i).map(x=>x.trim()).filter(x=>x.length>12);
  if(parts.length<2)return [raw];
  return parts.slice(0,4).map(part=>part.replace(/\?\s*(?:explique|indique|diga|apresente|mostre|compare|resuma)\b[\s\S]*$/i,'?').trim());
 }
 const PORTUGUESE_COUNTS={zero:0,um:1,uma:1,dois:2,duas:2,tres:3,quatro:4,cinco:5,seis:6,sete:7,oito:8,nove:9,dez:10};
 function countValue(token){const t=norm(token);if(/^\d+$/.test(t))return Number(t);return Object.prototype.hasOwnProperty.call(PORTUGUESE_COUNTS,t)?PORTUGUESE_COUNTS[t]:null;}
 function extractScenarioCounts(part){
  const n=norm(part);
  const num='(\\d+|zero|um|uma|dois|duas|tres|quatro|cinco|seis|sete|oito|nove|dez)';
  const minePatterns=[
   new RegExp('\\b(?:eu\\s+)?(?:tenho|tiver|tenha|possuo|estou com|fico com)\\s+(?:apenas\\s+|somente\\s+)?'+num+'\\s+(?:aventureiros?|sobreviventes?)(?:\\s+meus?)?\\b'),
   new RegExp('\\b'+num+'\\s+(?:aventureiros?|sobreviventes?)\\s+meus?\\b'),
   new RegExp('\\bmeus?\\s+(?:aventureiros?|sobreviventes?)\\s*[:=]?\\s*'+num+'\\b')
  ];
  const opponentPatterns=[
   new RegExp('\\b(?:o\\s+)?adversari[oa]\\s+(?:tiver|tem|tenha|possui|possuir|conta com|ficar com)\\s+(?:apenas\\s+|somente\\s+)?'+num+'\\b'),
   new RegExp('\\b'+num+'\\s+(?:aventureiros?|sobreviventes?)?\\s*adversari[oa]s?\\b'),
   new RegExp('\\b'+num+'\\s+(?:aventureiros?|sobreviventes?)\\s+do adversari[oa]\\b')
  ];
  const find=(patterns)=>{for(const re of patterns){const m=n.match(re);if(m)return countValue(m[1]);}return null;};
  return {mine:find(minePatterns),opponent:find(opponentPatterns)};
 }
 function resolveComparativePermission(question,game,result){
  const hits=result?.hits||[];
  const evidence=norm(hits.map(h=>`${h.section||''} ${h.text||''} ${h.excerpt||''}`).join(' '));
  const comparisonRule=/(pelo menos tantos .* quanto (?:qualquer|cada) outro jogador|pelo menos o mesmo numero .* quanto (?:qualquer|cada) outro jogador|at least as many .* as each other player|at least as many .* as any other player|numero igual ou maior .* cada adversario)/.test(evidence);
  if(!comparisonRule)return null;
  const parts=splitScenarioParts(question);
  const scenarios=parts.map(extractScenarioCounts);
  if(scenarios.length<1||scenarios.some(x=>x.mine===null||x.opponent===null))return null;
  const lines=scenarios.map((c,i)=>{
   const allowed=c.mine>=c.opponent;
   const verdict=allowed?'**Sim, você atende à condição.**':'**Não, você não atende à condição.**';
   const ownNoun=c.mine===1?'aventureiro':'aventureiros';
   const opponentNoun=c.opponent===1?'aventureiro':'aventureiros';
   const rationale=allowed
    ?`Você tem ${c.mine} ${ownNoun} e o adversário tem ${c.opponent} ${opponentNoun}. Sua quantidade é igual ou maior.`
    :`Você tem ${c.mine} ${ownNoun}, enquanto o adversário tem ${c.opponent} ${opponentNoun}. Sua quantidade é menor.`;
   return `**Cenário ${i+1}:** ${verdict} ${rationale}`;
  });
  const answer=`${lines.join('\n\n')}\n\n**Regra aplicada:** o trecho recuperado do manual diz que um jogador só pode mover a jangada se tiver a bordo pelo menos tantos aventureiros quanto cada outro jogador. Portanto, a comparação é feita entre a sua quantidade e a de cada adversário.\n\n**Onde conferir:** ${hits[0]?.section||'Seção relacionada do manual'} — ${hits[0]?.manual||'manual carregado'}.`;
  return {...result,status:result.status==='not_found'?'partial':result.status,confidence:'alta',answer,intent:'permission',interpretation:{...(result.interpretation||{}),scenarioCount:scenarios.length,comparisonApplied:true,sourceRuleVerified:true}};
 }
 function semanticQuestionText(value){
  const raw=String(value||'').replace(/\s+/g,' ').trim();
  const lastQuestion=raw.lastIndexOf('?');
  if(lastQuestion>=0){
   const trailing=raw.slice(lastQuestion+1);
   if(/^\s*(?:explique|indique|diga|apresente|mostre|compare|resuma|nao invente|nao presuma|nao chute|consulte|verifique|confira|cite|de exemplos|apresente exemplos)\b/i.test(norm(trailing)))return raw.slice(0,lastQuestion+1);
  }
  return raw.replace(/\s+(?:nao invente regras|nao presuma|nao chute|consulte o manual antes de responder|verifique o manual antes de responder)[\s\S]*$/i,'').trim();
 }
 function queryProfile(question){
  const q=normalizeQuery(semanticQuestionText(question)),terms=expandTokens(q),intent=detectIntent(q);
  const ruleQuestion=removeMetaTemporalPhrases(q);
  const temporal=/(antes|depois|durante|imediatamente|no inicio|no final|em seguida|apos)/.exec(ruleQuestion)?.[0]||'';
  return {q,terms,intent,concepts:terms.concepts||[],negative:/(\bnao\b|\bnunca\b|\bjamais\b|\bproibido\b|\bvedado\b|\bimpedido\b)/.test(q),temporal,quantity:(q.match(/\b\d+\b/g)||[]).map(Number),condition:/(se eu|caso|quando|desde que|a menos que|exceto|salvo|sem que)/.exec(q)?.[0]||'',questionType:/(quant[oa]s?|quanto)/.test(q)?'quantity':/(onde)/.test(q)?'location':/(quando)/.test(q)?'timing':/(quem)/.test(q)?'actor':/(por que|porque)/.test(q)?'reason':/(nao posso|nao pode|posso|pode|permitido|tem como|da para|da pra|consigo|e possivel|tenho que|sou obrigado)/.test(q)?'permission':/(se eu|caso|e se|o que acontece se)/.test(q)?'condition':/(como)/.test(q)?'procedure':'general'};
 }
 function detectPlayerCount(q,history=[]){
  const words={um:1,uma:1,dois:2,duas:2,tres:3,quatro:4,cinco:5,seis:6,sete:7,oito:8,nove:9,dez:10,once:11,doze:12};
  const parse=value=>{
   const n=normalizeQuery(value);
   const patterns=[
    /\b(\d{1,2})\s*(?:jogadores?|pessoas?|participantes?|players|p)\b/,
    /\b(?:somos|seremos|jogaremos|vamos jogar|vou jogar|vai jogar|jogando com|partida com|jogo com|mesa com|mesa de|para|pra|com|em|sejam)\s+(\d{1,2})\b/,
    /\b(?:somos|seremos|jogaremos|vamos jogar|vou jogar|vai jogar|jogando com|partida com|jogo com|mesa com|mesa de|para|pra|com|em|sejam)\s+(um|uma|dois|duas|tres|quatro|cinco|seis|sete|oito|nove|dez|once|doze)\b/,
    /\b(\d{1,2})\s*(?:p|pax)\b/
   ];
   for(const re of patterns){const m=n.match(re);if(m){const v=m[1];return /^\d+$/.test(v)?Number(v):words[v]||null;}}
   return null;
  };
  const direct=parse(q);if(direct)return direct;
  const short=normalizeQuery(q);
  const m=short.match(/^(?:e|e se|agora|entao|ta|ok)?\s*(\d{1,2})\s*\??$/);if(m)return Number(m[1]);
  const mw=short.match(/^(?:e|e se|agora|entao|ta|ok)?\s*(um|uma|dois|duas|tres|quatro|cinco|seis|sete|oito|nove|dez)\s*\??$/);if(mw)return words[mw[1]]||null;
  for(let i=(history||[]).length-1;i>=0;i--){const h=history[i];if(h?.role==='user'){const prev=parse(h.text||'');if(prev)return prev;}}
  return null;
 }
 function faqSectionBoost(question,gameId,sectionTitle){
  const arr=FAQ_INDEX.get(String(gameId));if(!arr?.length)return 0;
  const qTokens=new Set(tokenize(question).filter(t=>t.length>2));if(qTokens.size<2)return 0;
  const section=norm(sectionTitle);let best=0;
  for(const f of arr){if(norm(f.section)!==section)continue;let common=0;for(const t of f.tokens)if(qTokens.has(t))common++;
   const denom=Math.sqrt(Math.max(1,qTokens.size)*Math.max(1,f.tokens.size));const sim=common/denom;
   if(sim>best)best=sim;
  }
  return best>=.72?9:best>=.58?6:best>=.45?3.2:0;
 }
 function setupQuantityAnswer(question,game,history=[]){
  if(!game)return null;
  const matrix=PLAYER_SETUP[String(game.id)];
  const count=detectPlayerCount(question,history);
  const q=normalizeQuery(question);
  const prevUser=[...(history||[])].reverse().find(h=>h?.role==='user');
  const previousWasSetup=prevUser&&/(prepar|mont|setup|quantidade de pecas|componentes)/.test(normalizeQuery(prevUser.text||''));
  const setupLike=detectIntent(q)==='setup'||(count!==null&&/(quant|peca|componente|marcador|ficha|tabuleiro|distribu|cada jogador|cada pessoa|recebe|reserva|carta inicial|jogador|pessoa|participante)/.test(q))||(count!==null&&previousWasSetup);
  if(!setupLike)return null;
  const docs=documents.filter(d=>String(d.gameId)===String(game.id));
  const findDoc=label=>docs.find(d=>norm(d.title||'')===norm(label))||docs.find(d=>norm((d.title||'')+' '+(d.manual||'')).includes(norm(label)))||docs.find(d=>norm(d.title||'').includes(norm(label)));
  const sections=(matrix?.sections||SETUP_FACTS[String(game.id)]?.sourceSections||[]);
  let sourceDocs=sections.map(findDoc).filter(Boolean);
  if(!sourceDocs.length)sourceDocs=docs.filter(d=>/(prepar|component|montag|configur)/.test(norm(d.title||''))).slice(0,6);
  const hits=sourceDocs.slice(0,8).map(d=>({game:game.title,gameId:game.id,manual:d.manual||'Manual do jogo',section:d.title||'Preparação',text:d.text,excerpt:String(d.text||'').slice(0,900),sectionId:d.sectionId||d.id||'',source:'manual',score:35,matched:6,matchedCore:6,coverage:1,domainBoost:35}));
  const title=game.title||game.id;
  if(!matrix){
   if(!sourceDocs.length)return {status:'not_found',answer:`Ainda não tenho a seção de preparação de ${title} carregada. Carregue o módulo completo para eu conferir os componentes e a distribuição para cada participante.`,game,confidence:'baixa',intent:'setup',hits:[]};
   const snippets=sourceDocs.slice(0,4).map(d=>{const txt=paraphraseRuleText(d.text,430,queryProfile('preparação do jogo componentes por jogador'),d.title);return txt?`**${d.title}:** ${txt}`:'';}).filter(Boolean);
   return {status:'partial',answer:`Encontrei a preparação de ${title}${count?` para uma mesa de ${count}`:''}, mas o manual carregado não traz uma tabela que me permita calcular todas as quantidades para esse número de participantes.\n\n${snippets.join('\n\n')}\n\nNão vou inventar números que o texto não confirma.`,game,confidence:'media',intent:'setup',hits,sourceType:'manual-setup-generic',interpretation:{questionType:'setup',playerCount:count,source:'manual-local',paraphrased:true}};
  }
  const out=[];
  if(count===null){
   out.push(`Para montar **${title}**, preciso saber quantas pessoas vão jogar. Assim aplico a configuração correta sem misturar quantidades por pessoa com peças da mesa.`);
   if(matrix.min!==null||matrix.max!==null)out.push(`Faixa indicada no manual: ${matrix.min!==null?matrix.min:'não especificado'} a ${matrix.max!==null?matrix.max:'não especificado'} participantes${matrix.extended?`; para ${matrix.extended.min}–${matrix.extended.max}, é necessária a ${matrix.extended.name}`:''}.`);
   out.push('Pode responder apenas “somos 4”, “pra 3” ou “e com 5?”.');
   return {status:'need_player_count',answer:out.join('\n\n'),game,confidence:'alta',intent:'setup',hits,sourceType:'player-setup-matrix',interpretation:{questionType:'setup',playerCount:null,paraphrased:true}};
  }
  let supported=true,scope='supported',special='';
  if(matrix.extended&&count>=matrix.extended.min&&count<=matrix.extended.max){scope='expansion';special=`**Atenção:** para ${count} jogadores, é necessária a **${matrix.extended.name}**. O jogo básico cobre ${matrix.min}–${matrix.max}.`;}
  else if(matrix.min!==null&&count<matrix.min){supported=false;scope='below-range';special=`O manual começa em **${matrix.min} participantes**; não há uma preparação oficial confirmada para ${count}.`;}
  else if(matrix.max!==null&&count>matrix.max){supported=false;scope='above-range';special=`O manual cobre até **${matrix.max} participantes**; não vou extrapolar quantidades para ${count}.`;}
  if(matrix.countType==='unspecified'&&count>=1){supported=true;scope='limit-not-stated';}
  if(matrix.formula==='teams-over-max'&&count>6){supported=true;scope='teams';special='O manual permite passar de 6 participantes organizando equipes; o limite de 6 se refere ao jogo individual, pois há 6 cartelas de resposta.';}
  if(!supported){
   const extra=matrix.extended&&count>matrix.max?` Para ${count}, procure a ${matrix.extended.name}; ela é o material indicado para ampliar o jogo básico.`:'';
   const unsupportedMessage=game.id==='the-resistance'&&count<5?`O manual do The Resistance – modo básico não apresenta uma configuração para ${count} jogadores. A tabela oficial começa em 5 participantes.`:`Não consigo confirmar uma preparação oficial de **${title} para ${count} participantes** com o manual carregado. ${special}${extra}`;
   return {status:'partial',answer:`${unsupportedMessage}\n\nPosso explicar a configuração dentro da faixa documentada, mas não vou inventar peças, personagens ou quantidades.`,game,confidence:'media',intent:'setup',hits,sourceType:'player-setup-matrix',interpretation:{questionType:'setup',playerCount:count,scope,paraphrased:true}};
  }
  out.push(`Para jogar **${title} com ${count} ${count===1?'pessoa':'pessoas'}**, organize assim:`);
  if(matrix.perPlayer?.length && !(game.id==='times-up-party'&&[5,7].includes(count))){const per=matrix.formula==='teams-over-max'&&count>6?['Cada equipe recebe 1 cartela de respostas, 2 fichas cartonadas da mesma cor e 1 caneta especial.']:matrix.perPlayer;out.push((matrix.formula==='teams-over-max'&&count>6?'**Para cada equipe:**\n':'**Para cada participante:**\n')+per.map(x=>'• '+x).join('\n'));}
  if(matrix.shared?.length)out.push('**Preparação da mesa:**\n'+matrix.shared.map(x=>'• '+x).join('\n'));
  const countSteps=matrix.byCount?.[String(count)]||[];
  if(countSteps.length)out.push(`**O que muda nessa quantidade:**\n`+countSteps.map(x=>'• '+x).join('\n'));
  if(game.id==='finca'){
   const f=matrix.byCount[String(count)]||[];
   if(/fazendeir/.test(q)){const farms={2:5,3:4,4:3,5:3}[count];if(farms)out.push(`**Fazendeiros:** cada participante recebe **${farms} Fazendeiros** (ou ${farms} marcadores de Fazendeiro); no total, são **${farms*count} marcadores** para a mesa.`);}
   if(/carroc|burro/.test(q)){const carts={2:4,3:6,4:8,5:10}[count];if(carts)out.push(`**Carroças de Burro:** deixe **${carts} cartas** em uma pilha perto do moinho.`);}
   if(/alimento|comida|fruta/.test(q)){const remove={2:9,3:4,4:0,5:0}[count];out.push(remove?`**Alimentos:** retire **${remove} marcadores de cada um dos seis tipos**. Com ${count} pessoas, isso remove ${remove*6} peças ao todo.`:'**Alimentos:** não retire marcadores por causa da quantidade de jogadores; mantenha a reserva completa.');}
   if(/demanda/.test(q))out.push('**Fichas de Demanda:** use 40 em jogo, em 10 pilhas de 4; devolva as 2 restantes à caixa.');
  }
  if(matrix.formula==='detetive-cards'){
   const each=Math.floor(24/count),left=24%count;
   out.push(`**Distribuição das cartas:** depois de colocar 3 cartas no envelope secreto, restam 24. Com ${count} participantes, distribua ${each} cartas para cada um${left?`; ${left} participante(s) ficam com uma carta extra`:''}. O manual permite que alguns recebam mais quando a divisão não é exata.`);
  }
  if(matrix.formula==='per-player')out.push(`**Total no modo individual:** ${count*2} fichas HITSTER e ${count} cartas de música para iniciar as linhas do tempo. Se jogarem em equipes, conte uma distribuição por equipe.`);
  if(matrix.formula==='teams-over-max'&&count>6)out.push(`**Acima de 6 pessoas:** formem equipes, de preferência com tamanhos parecidos. Cada equipe recebe 1 cartela de respostas, 2 fichas cartonadas e 1 caneta. O número de equipes é que deve ficar dentro do limite de 6 cartelas.`);
  if(game.id==='terra-nova')out.push(`**Fichas bônus:** separe ${3+count} (3 mais uma por participante).`);
  if(matrix.notes?.length)out.push('**Atenção:**\n'+matrix.notes.map(x=>'• '+x).join('\n'));
  if(special)out.push(special);
  const refs=[...new Set(sourceDocs.map(d=>d.title).filter(Boolean))];
  if(refs.length)out.push(`**Seções do manual consultadas:** ${refs.join('; ')}.`);
  return {status:'confirmed',answer:out.join('\n\n'),game,confidence:'alta',intent:'setup',hits,sourceType:'player-setup-matrix',interpretation:{questionType:'setup',playerCount:count,scope,paraphrased:true,source:'manual-local'}};
 }
 function findRememberedAnswer(question,gameId){
  try{const q=normalizeQuery(question);const list=JSON.parse(localStorage.getItem(MEMORY_KEY)||'[]');
   const item=list.find(x=>x.version===MEMORY_VERSION&&x.q===q&&x.gameId===String(gameId));
   if(!item)return null;
   return {status:'confirmed',answer:item.answer,game:gameCatalog.get(String(gameId)),confidence:'alta',intent:'memory',hits:item.hits||[],sourceType:'local-memory',remembered:true};
  }catch(_){return null;}
 }
 function rememberAnswer(question,result){
  if(!result||result.status!=='confirmed'||result.confidence!=='alta'||!result.game?.id)return;
  try{const q=normalizeQuery(question);if(q.length<5)return;const list=JSON.parse(localStorage.getItem(MEMORY_KEY)||'[]');
   const item={version:MEMORY_VERSION,q,gameId:result.game.id,answer:result.answer,sections:(result.hits||[]).map(h=>h.section).filter(Boolean),hits:(result.hits||[]).slice(0,4).map(h=>({game:h.game,gameId:h.gameId,manual:h.manual,section:h.section,excerpt:String(h.excerpt||'').slice(0,360),source:'manual'})),savedAt:Date.now()};
   const next=[item,...list.filter(x=>!(x.version===MEMORY_VERSION&&x.q===q&&x.gameId===item.gameId))].slice(0,750);
   localStorage.setItem(MEMORY_KEY,JSON.stringify(next));
  }catch(_){/* storage disabled: built-in FAQ remains available */}
 }
 function getMemoryStats(){try{return JSON.parse(localStorage.getItem(MEMORY_KEY)||'[]').filter(x=>x.version===MEMORY_VERSION).length;}catch(_){return 0;}}
 function phraseMatches(docText,concepts){const hits=[];for(const {group} of concepts){let best='';const aliases=[group.canonical,...(group.aliases||[])];for(const a0 of aliases){const a=norm(a0);if(a.length<6)continue;if((` ${docText} `).includes(` ${a} `)){best=a;break;}}if(best)hits.push({concept:group.concept,alias:best});}return hits;}
 function scoreIndexed(x,profile){const {terms,intent,q,concepts}=profile;const title=x.title,all=x.all,tf=x.tf;const n=Math.max(1,docIndex.length),avgLen=docIndex.reduce((a,d)=>a+d.len,0)/n||1;let score=0,matched=0,titleHits=0,weightedMatched=0;
  for(const [t,w] of terms){const f=tf.get(t)||0;if(!f)continue;matched++;weightedMatched+=Math.max(0,w);const termIdf=idf.get(t)||.08;const denom=f+1.2*(1-.68+.68*x.len/avgLen);const bm25=termIdf*((f*2.2)/denom);const titleBoost=title.includes(t)?2.0:1;score+=bm25*w*titleBoost;if(title.includes(t))titleHits++;}
  const pHits=phraseMatches(all,concepts);score+=pHits.reduce((n,h)=>n+1.35,0);
  if(q.length>7&&title.includes(q))score+=4.5;
  const intentTitle={scoring:/pontua|ponto|escore|bonus|desempate|contagem/,setup:/prepar|montag|componente|distribu|inicio/,endgame:/fim|encerr|final|termin/,permission:/permiss|pode|proib|obrig|restri|limite/,purchase:/compr|bilhete|mercado|retirar|receb|cartas/,turn:/turno|vez|ordem|rodada|fase|acao/,victory:/vitoria|objetivo|ganhar|condicao/,cards:/carta|baralho|mao|bilhete|descarte/,movement:/rota|caminho|trilho|moviment|desloc|adjac/,exception:/exce|especial|limite|restri|caso/,strategy:/estrateg|dica|objetivo|pontua/,components:/component|peca|meeple|cubo|dado/,trade:/troca|comerc|custo|pagamento|recurso/,combat:/combate|ataque|defesa|dano/,interaction:/roub|bloque|disput|conflito/,voting:/vota|equipe|missao|aprov|rejeit/};
  if(intentTitle[intent]?.test(title))score+=1.1;
  if(profile.negative&&/(nao|nunca|proib|vedad|impedid|exceto|salvo)/.test(all))score+=.7;
  if(profile.temporal&&all.includes(profile.temporal))score+=.45;
  if(profile.condition&&all.includes(profile.condition))score+=.35;
  for(const num of profile.quantity){if(new RegExp(`\\b${num}\\b`).test(all))score+=.9;}
  const core=profile.terms.baseTerms||[];const coreSet=[...new Set(core.filter(t=>!STOP.has(t)||IMPORTANT.has(t)))];const matchedCore=coreSet.filter(t=>tf.has(t)).length;const effective=Math.min(coreSet.length,matchedCore+pHits.length*.7);const coverage=coreSet.length?Math.min(1,effective/coreSet.length):0;
  return {score,matched,titleHits,coverage,phraseHits:pHits.length,matchedCore,weightedMatched};
 }
 function sentenceExcerpt(text,profile,max=950){const clean=String(text||'').replace(/\s+/g,' ').trim();if(clean.length<=max)return clean;const sentences=clean.match(/[^.!?;]+[.!?;]?/g)||[clean];const ranked=sentences.map((s,i)=>{const toks=new Set(tokenize(s));let n=0;for(const [t,w] of profile.terms||[])if(toks.has(t))n+=w;const ns=profile.negative&&/(nao|nunca|proib|vedad|impedid|exceto|salvo)/.test(norm(s))?1.4:0;const ts=profile.temporal&&norm(s).includes(profile.temporal)?.5:0;return {s:s.trim(),i,n:n+ns+ts};}).filter(x=>x.s.length>18).sort((a,b)=>b.n-a.n||a.i-b.i);const chosen=[];let len=0;for(const x of ranked){if(len+x.s.length>max)continue;chosen.push(x);len+=x.s.length+1;if(len>=max*.78)break;}chosen.sort((a,b)=>a.i-b.i);return chosen.length?chosen.map(x=>x.s).join(' '):clean.slice(0,max)+'…';}
 function splitRuleUnits(text){
  const raw=String(text||'').replace(/\r/g,'\n').replace(/\s+/g,' ').trim();
  if(!raw)return [];
  // Preserve numbered steps and bullet fragments before splitting prose.
  const marked=raw.replace(/\s+(?=(?:\d{1,2}[.)]|[a-f][.)]|[A-Z][.)])\s)/g,'\n');
  const units=[];
  for(const block of marked.split(/\n+/)){
   const b=block.trim(); if(!b)continue;
   const parts=b.match(/[^.!?;]+[.!?;]?/g)||[b];
   for(const part of parts){const t=part.trim();if(t.length>18)units.push(t);}
  }
  return units;
 }
 function sentenceRelevance(sentence,profile,sectionTitle=''){
  const s=norm(sentence),title=norm(sectionTitle),tokens=new Set(tokenize(s));let score=0;
  for(const [t,w] of profile.terms||[])if(tokens.has(t))score+=w;
  for(const t of profile.terms?.baseTerms||[])if(t.length>3&&title.includes(t))score+=1.25;
  const intentPatterns={
   scoring:/\b(ponto|pontu|vale|ganha|recebe|descont|perde|bonus|escore)\b/,
   setup:/\b(prepar|coloque|distribu|embaral|receb|monte|posicion)\b/,
   endgame:/\b(termin|acaba|encerra|fim da partida|final da partida|quando nao houver|quando nao restar)\b/,
   permission:/\b(pode|podem|permit|proib|nao pode|obrig|deve|precisa|somente|apenas)\b/,
   purchase:/\b(compr|pegue|retire|receba|obtenha|cartas|bilhetes|mercado)\b/,
   turn:/\b(turno|vez|rodada|fase|acao|em seguida|depois)\b/,
   victory:/\b(vencer|ganhar|vence|vitoria|objetivo|maior pontuacao)\b/,
   cards:/\b(carta|cartas|baralho|mao|bilhete|descarte|monte)\b/,
   movement:/\b(mover|moviment|rota|caminho|trilho|desloc|adjacente|alcance)\b/,
   exception:/\b(se|quando|caso|exceto|salvo|esgot|acab|falta|sobra|restante|nao houver|sem recurso)\b/,
   voting:/\b(vot|equipe|missao|aprov|rejeit|maioria|empate)\b/,
   strategy:/\b(estrateg|planej|vantagem|risco|compensa|pontos|bloque)\b/,
   trade:/\b(troca|comerc|banco|porto|4:1|3:1|2:1|pagar|custo|recurso)\b/,
   combat:/\b(combate|ataque|defesa|dano|vida|captur)\b/,
   interaction:/\b(roub|bloque|advers|oponent|conflito|elimin)\b/
  };
  if(intentPatterns[profile.intent]?.test(s))score+=1.8;
  if(profile.negative&&/\b(nao|nunca|jamais|proib|vedad|exceto|salvo)\b/.test(s))score+=1.8;
  if(profile.temporal&&s.includes(profile.temporal))score+=1.3;
  if(profile.condition&&s.includes(profile.condition))score+=1.0;
  for(const num of profile.quantity||[])if(new RegExp(`\\b${num}\\b`).test(s))score+=2.2;
  // Direct statements of rules outrank flavour text and headings.
  if(/\b(pode|devem|deve|obrigatorio|nao pode|somente|apenas|quando|se|vale|pontos|por turno)\b/.test(s))score+=.55;
  if(s.length<45)score-=.2;
  return score;
 }
 function getRelevantUnits(text,profile,sectionTitle='',limit=4){
  const units=splitRuleUnits(text).map((text,index)=>({text,index,score:sentenceRelevance(text,profile,sectionTitle)}));
  const ranked=units.filter(x=>x.score>.15).sort((a,b)=>b.score-a.score||a.index-b.index);
  const chosen=[];let chars=0;
  for(const x of ranked){if(chosen.length>=limit)break;if(chars+x.text.length>1050)continue;
   const duplicate=chosen.some(y=>norm(y.text)===norm(x.text));if(duplicate)continue;
   chosen.push(x);chars+=x.text.length;
  }
  return chosen.sort((a,b)=>a.index-b.index);
 }
 function rewriteRuleSentence(sentence){
  let s=String(sentence||'').trim().replace(/\s+/g,' ');
  const rules=[
   [/^A equipe é aprovada se a maioria dos votos for favorável\. A equipe é rejeitada se a maioria votar contra; o empate também conta como rejeição\.?$/i,'Para a equipe passar, precisa receber mais votos favoráveis do que contrários. Empate não aprova: conta como rejeição.'],
   [/^(?:1\)\s*)?Dê a cada participante um tabuleiro de jogador.*?Todos os jogadores devem usar o mesmo lado\.?$/i,'Entregue um tabuleiro a cada pessoa e combinem que todos usarão o lado com a parede colorida. O lado cinza fica para a partida alternativa.'],
   [/^(?:2\)\s*)?Pegue 1 marcador de pontuação.*?trilha de pontuação\.?$/i,'Cada pessoa coloca seu marcador no zero da própria trilha de pontuação.'],
   [/^(?:3\)\s*)?Coloque os Expositores de Fábrica.*?Expositores de Fábrica\.?$/i,'Organize as fábricas em círculo no centro da mesa: são cinco para duas pessoas, sete para três e nove para quatro.'],
   [/^(?:4\)\s*)?Preencha o saco.*?saco\.?$/i,'Coloque no saco as cem peças, vinte de cada cor.'],
   [/^(?:5\)\s*)?O jogador que tiver visitado Portugal.*$/i,'Escolham o primeiro jogador conforme a regra temática do manual. Essa pessoa pega o marcador de primeiro jogador, coloca quatro peças aleatórias em cada fábrica e devolve à caixa os componentes que não serão usados.'],
   [/^(?:1\)\s*)?Dê a cada participante um tabuleiro de jogador \(A\)\.?$/i,'Entregue um tabuleiro individual a cada pessoa.'],
   [/^Vire o seu tabuleiro para o lado que contém a parede colorida\.?\s*(?:\(Ver Partida Alternativa[^)]*\)\.?)*$/i,'Vire todos os tabuleiros para o lado da parede colorida. O lado cinza é usado apenas na partida alternativa.'],
   [/^Todos os jogadores devem usar o mesmo lado\.?$/i,'Confiram se todos os tabuleiros estão virados para o mesmo lado.'],
   [/^(?:2\)\s*)?Pegue 1 marcador de pontuação \(B\) e coloque-o no espaço “0” da sua trilha de pontuação\.?$/i,'Cada pessoa coloca seu marcador no zero da própria trilha de pontuação.'],
   [/^(?:3\)\s*)?Coloque os Expositores de Fábrica \(C\) em um círculo ao redor do centro da mesa: Em uma partida com 2 jogadores, coloque 5 Expositores de Fábrica\. Em uma partida com 3 jogadores, coloque 7 Expositores de Fábrica\. Em uma partida com 4 jogadores, coloque 9 Expositores de Fábrica\.?$/i,'Organize as fábricas em círculo no centro da mesa. Use cinco fábricas com duas pessoas, sete com três e nove com quatro.'],
   [/^(?:4\)\s*)?Preencha o saco \(D\) com as 100 peças \(20 de cada cor\) \(E\)\.?$/i,'Coloque as cem peças no saco, sendo vinte de cada cor.'],
   [/^(?:5\)\s*)?O jogador que tiver visitado Portugal mais recentemente pega o marcador de primeiro jogador \(F\) e preenche cada Expositor de Fábrica com exatamente 4 peças retiradas aleatoriamente do saco\.?$/i,'A pessoa que visitou Portugal mais recentemente começa: pega o marcador de primeiro jogador e coloca quatro peças aleatórias em cada fábrica.'],
   [/^Montagem inicial para principiantes Cada jogador recebe uma tabela de custos de construção e todas as figuras da sua cor.*$/i,'Cada jogador pega a tabela de custos e todas as peças da sua cor.'],
   [/^Cada jogador coloca 2 estradas e 2 aldeias no tabuleiro de jogo conforme indicado na ilustração\.?$/i,'Na montagem inicial, cada pessoa coloca duas aldeias e duas estradas nos espaços indicados pelo manual.'],
   [/^Cada jogador recebe uma tabela de custos de construção e todas as figuras da sua cor.*$/i,'Cada pessoa pega a tabela de custos e todas as peças da sua cor.'],
   [/^Cada jogador recebe uma tabela de custos de construção e todas as figuras da sua cor.*$/i,'Cada pessoa pega a tabela de custos e todas as peças da sua cor.'],
   [/^Se participam apenas 3 jogadores, retiram-se do jogo todas as peças de cor vermelha\.?$/i,'Se a partida tiver três participantes, retire todas as peças vermelhas do jogo.'],
   [/^Por último, cada jogador recebe as suas primeiras cartas de matéria-prima.*$/i,'Para começar, cada pessoa recebe uma matéria-prima para cada terreno que toca sua aldeia inicial. Assim, a posição escolhida já determina os recursos com que você entra na partida.'],

   [/^Depois, cada um coloca as suas peças restantes à sua frente\.?$/i,'Deixe as demais construções reservadas à sua frente para usar durante a partida.'],
   [/^Por último, cada jogador recebe as suas primeiras cartas de matéria-prima.*$/i,'Para começar com recursos, cada pessoa pega uma carta de matéria-prima para cada terreno que toca a aldeia inicial indicada para sua cor.'],
   [/^Cada jogador escolhe uma cor, recebe 7 seguidores para sua reserva e coloca a oitava figura no espaço 0 do marcador de pontos\.?$/i,'Cada pessoa escolhe uma cor: sete seguidores ficam disponíveis para usar na partida, e a oitava peça vai para a casa zero do marcador de pontos.'],
   [/^Na primeira partida, o manual orienta deixar os abades na caixa\.?$/i,'Se for a primeira partida, deixe os abades fora da mesa.'],
   [/^Coloque a cartela inicial, identificada pelo verso mais escuro, no centro da mesa\.?$/i,'Ponham a peça inicial no centro da mesa; ela será o ponto de partida do mapa.'],
   [/^Embaralhe as demais cartelas e forme montes virados para baixo, ao alcance de todos\.?$/i,'Misture o restante das cartelas e forme pilhas viradas para baixo, acessíveis a todos.'],
   [/^Coloque o marcador de pontos próximo à área de jogo\.?$/i,'Deixe o marcador de pontos ao lado do mapa.'],
   [/^Em seguida, preencha o interior com os terrenos hexagonais e, sobre eles, coloque as fichas numeradas\.?$/i,'Depois, preencha o centro com os terrenos hexagonais e distribua as fichas numeradas sobre eles.'],
   [/^Em primeiro lugar, coloque a moldura formada pelas 6 peças de mar\.?$/i,'Comece montando o contorno do tabuleiro com as seis peças de mar.'],
   [/^Em seguida, preencha o interior com os terrenos hexagonais e, sobre eles, coloque as fichas numeradas\.?$/i,'Depois, preencha o centro com os terrenos hexagonais e distribua as fichas numeradas sobre eles.'],
   [/^Assegure-se de que os portos estão bem colocados\.?$/i,'Por fim, confira se os portos ficaram nas posições indicadas.'],
   [/^O jogador pode agora efetuar trocas comerciais, a fim de obter as cartas de matéria-prima de que necessita\.?$/i,'Nesta fase, o jogador ativo pode negociar para conseguir as matérias-primas que estão faltando.'],
   [/^O jogador pode trocar cartas de matéria-prima com todos os jogadores\.?$/i,'O jogador da vez pode negociar com qualquer outro participante.'],
   [/^Os restantes jogadores não podem realizar trocas comerciais entre si\.?$/i,'Quem não está no turno não pode negociar entre si; as trocas passam pelo jogador ativo.'],
   [/^Pode sempre trocar à razão de 4:1, devolvendo 4 cartas de matéria-prima iguais à pilha correspondente na provisão e recolhendo \(comprando\) em troca uma carta de matéria-prima à sua escolha\.?$/i,'Sem usar porto, a troca padrão com o banco é 4 por 1: entregue quatro cartas iguais e escolha uma matéria-prima para receber.'],
   [/^Num porto 3:1 trocam-se 3 cartas de matéria-prima iguais por uma carta de matéria-prima à escolha e num porto especial trocam-se 2 cartas da matéria-prima indicada no porto por uma carta de matéria-prima à escolha\.?$/i,'Um porto melhora a negociação: o porto comum permite trocar três por uma; o porto especial permite trocar duas cartas do tipo indicado por uma matéria-prima à sua escolha.'],
   [/^Um monastério é concluído quando fica completamente rodeado por oito cartelas\.?$/i,'O monastério só fica completo quando as oito posições ao redor dele estiverem preenchidas.'],
   [/^A cartela do próprio monastério também conta: são 9 pontos no total\.?$/i,'Na pontuação, conte também a cartela do monastério: completo, ele rende nove pontos.'],
   [/^Depois da pontuação, o monge retorna à reserva\.?$/i,'Depois de marcar esses pontos, você recupera o monge e pode usá-lo novamente.'],
   [/^Comprar Bilhetes Compre até 3 bilhetes e mantenha pelo menos 1\.?$/i,'Uma das ações disponíveis é comprar até três Bilhetes de Destino. Você precisa ficar com pelo menos um deles.'],
   [/^É obrigatório manter pelo menos 1 dos bilhetes comprados, mas você pode ficar com 2 ou com os 3\.?$/i,'Depois de comprar, você é obrigado a guardar pelo menos um; pode escolher ficar com dois ou com os três.'],
   [/^Depois de decidir mantê-los, não podem ser descartados em compras futuras\.?$/i,'Depois que você escolhe guardar um bilhete, não pode descartá-lo em uma compra posterior.'],
   [/^Não há limite para a quantidade de Bilhetes que um jogador pode acumular\.?$/i,'O manual não estabelece limite para a quantidade de Bilhetes de Destino que você pode manter.'],
   [/^No seu turno, você sempre pega e posiciona peças\.?$/i,'Em todo turno, a ação que não pode faltar é pegar peças do centro e colocá-las na sua paisagem.'],
   [/^As outras duas ações são opcionais\.?$/i,'As outras duas possibilidades são opcionais; você não precisa fazer as duas.'],
   [/^Uma peça pode ser colocada em qualquer espaço vazio\.?$/i,'Você pode escolher qualquer espaço que ainda esteja vazio para colocar a peça.'],
   [/^Nenhuma outra peça pode ser posicionada em cima de uma peça previamente empilhada\.?$/i,'Depois que uma pilha foi formada, você não pode continuar colocando peças sobre ela.'],
   [/^Uma peça não pode ser posicionada em um espaço ocupado por um Cubo de Animal\.?$/i,'Não coloque uma peça em um espaço onde já existe um Cubo de Animal.'],
   [/^A partida termina quando um jogador não consegue mais comprar e colocar uma cartela\.?$/i,'O fim chega quando alguém não consegue mais comprar e baixar uma nova cartela.'],
   [/^O objetivo é terminar a partida com a maior quantidade de pontos\.?$/i,'No final, vence quem tiver acumulado mais pontos.'],
   [/^A partida acaba após a rodada na qual pelo menos um jogador tiver completado uma fileira horizontal de 5 azulejos consecutivos em sua parede\.?$/i,'A rodada em que alguém completa uma linha horizontal de cinco azulejos é a última; o jogo termina depois da fase de parede dessa rodada.'],
   [/^Cada jogador recebe (.+) no início da partida\.?$/i,'No começo, todos recebem $1.'],
   [/^Cada jogador começa com (.+)\.?$/i,'Todo mundo inicia a partida com $1.'],
   [/^O jogador com mais (.+) vence\.?$/i,'No fim, ganha quem tiver a maior quantidade de $1.'],
   [/^O jogador que tiver (.+) recebe (.+) pontos\.?$/i,'Quem terminar com $1 ganha $2 pontos.'],
   [/^Quando (.+), o jogador deve (.+)\.?$/i,'Assim que $1 acontecer, você precisa $2.'],
   [/^Se (.+), o jogador pode (.+)\.?$/i,'Se $1 acontecer, você pode $2.'],
   [/^Se (.+), o jogador não pode (.+)\.?$/i,'Se $1 acontecer, essa jogada fica proibida: você não pode $2.'],
   [/^O objetivo é (.+)\.?$/i,'A ideia principal é $1.'],
   [/^O vencedor é o jogador que (.+)\.?$/i,'Vence quem $1.'],
   [/^No final da partida, (.+)\.?$/i,'Quando a partida terminar, $1.'],
   [/^Durante o seu turno, (.+)\.?$/i,'Na sua vez, $1.'],
   [/^No início de cada rodada, (.+)\.?$/i,'Toda rodada começa com esta etapa: $1.'],
   [/^Depois que (.+), (.+)\.?$/i,'Primeiro, $1. A partir daí, $2.'],
   [/^Não é possível (.+)\.?$/i,'Essa ação não é permitida: você não pode $1.'],
   [/^É obrigatório (.+)\.?$/i,'Você precisa fazer isso; não é uma escolha opcional: $1.']
  ];
  for(const [re,to] of rules)if(re.test(s))return s.replace(re,to);
  const generic=[
   [/\bdeverá\b/gi,'precisa'],[/\bdeverão\b/gi,'precisam'],[/\bdeve\b/gi,'precisa'],[/\bdevem\b/gi,'precisam'],
   [/\bé permitido\b/gi,'você pode'],[/\bnão é permitido\b/gi,'você não pode'],[/\bcaso\b/gi,'se'],[/\bno caso de\b/gi,'se houver'],
   [/\brealizar\b/gi,'fazer'],[/\befetuar\b/gi,'fazer'],[/\bao término de\b/gi,'quando terminar'],[/\bimediatamente após\b/gi,'logo depois de'],
   [/\bpor jogador\b/gi,'para cada jogador'],[/\brespectivamente\b/gi,'na mesma ordem']
  ];
  for(const [re,to] of generic)s=s.replace(re,to);
  s=s.replace(/^O jogador ativo /i,'No seu turno, ').replace(/^O jogador /i,'Você ').replace(/^Cada participante /i,'Cada jogador ');
  s=s.replace(/^Se um jogador /i,'Se você ').replace(/^Quando um jogador /i,'Quando você ');
  return s;
 }
 function paraphraseRuleText(text,max=1050,profile=null,sectionTitle=''){
  const p=profile||queryProfile('como funciona essa regra?');
  return getRelevantUnits(text,p,sectionTitle,5).map(x=>rewriteRuleSentence(x.text)).join(' ').slice(0,max).trim();
 }
 function answerLead(intent){
  const leads={scoring:'Na pontuação, funciona assim:',setup:'Para preparar essa parte, faça o seguinte:',endgame:'O fim da partida é definido por esta condição:',permission:'A regra permite o seguinte:',purchase:'Sobre pegar ou comprar:',turn:'No seu turno, a sequência é esta:',victory:'Para vencer, o objetivo é:',cards:'Sobre as cartas:',movement:'Sobre o movimento:',exception:'Quando essa situação acontece:',voting:'Na votação, a regra funciona assim:',strategy:'O que o manual permite afirmar sobre a estratégia:',trade:'Na negociação, funciona assim:',combat:'Sobre o combate:',interaction:'A interação entre jogadores funciona assim:',general:'A regra relevante diz, na prática:'};
  return leads[intent]||leads.general;
 }
 function composeRuleExplanation(units,intent,question){
  const clean=units.map(x=>String(x||'').trim()).filter(x=>x.length>18);
  if(!clean.length)return '';
  const classify=x=>{const n=norm(x);
   if(/\b(se|quando|caso|desde que|a menos que|sempre que)\b/.test(n))return 'condition';
   if(/\b(nao pode|proibido|somente|apenas|limite|obrigatorio|precisa|deve)\b/.test(n))return 'limit';
   if(/\b(pontos|pontua|ganha|vence|recebe|perde|desconta|vale)\b/.test(n))return 'result';
   if(/\b(pode|escolhe|compra|pega|coloca|move|troca|entrega|baixa|joga|usa)\b/.test(n))return 'action';
   return 'context';
  };
  const buckets={condition:[],limit:[],result:[],action:[],context:[]};
  for(const x of clean){const k=classify(x);if(!buckets[k].some(y=>norm(y)===norm(x)))buckets[k].push(x);}
  const uniq=a=>a.filter((x,i)=>a.findIndex(y=>norm(y)===norm(x))===i);
  const actions=uniq([...buckets.action,...buckets.context]).slice(0,2);
  const conditions=uniq(buckets.condition).slice(0,2);
  const limits=uniq(buckets.limit).slice(0,2);
  const results=uniq(buckets.result).slice(0,2);
  if(intent==='setup'||intent==='turn'){
   const ordered=uniq([...actions,...conditions,...limits,...results]).slice(0,4);
   return ordered.length?`A lógica é seguir esta sequência: ${ordered.join(' ')}${limits.length?' Preste atenção especialmente à condição ou ao limite indicado, porque é isso que define quando a ação pode acontecer.':''}`:'';
  }
  if(intent==='scoring'){
   const parts=[];if(actions.length)parts.push(`Primeiro identifique o que entra na contagem: ${actions[0]}`);if(results.length)parts.push(`O efeito na pontuação é este: ${results.join(' ')}`);if(conditions.length)parts.push(`Essa pontuação depende desta condição: ${conditions.join(' ')}`);if(limits.length)parts.push(`Não esqueça a restrição: ${limits.join(' ')}`);return parts.join('\n\n');
  }
  if(intent==='permission'||intent==='purchase'||intent==='movement'){
   const parts=[];if(conditions.length)parts.push(`A resposta depende da situação: ${conditions.join(' ')}`);if(actions.length)parts.push(`Na prática, a ação funciona assim: ${actions.join(' ')}`);if(limits.length)parts.push(`O limite importante é: ${limits.join(' ')}`);if(results.length)parts.push(`Se isso acontecer, o resultado é: ${results.join(' ')}`);return parts.join('\n\n');
  }
  const main=actions[0]||clean[0];const complement=[...conditions,...limits,...results,...actions.slice(1)].filter(x=>norm(x)!==norm(main)).slice(0,3);
  return `O ponto principal é este: ${main}${complement.length?'\n\nPara entender quando isso se aplica e o que muda, considere também: '+complement.join(' '):''}`;
 }
 function findRuleGuide(gameId,question,intent){
  const guides=root.MEEPLE_RULE_GUIDES||[];const q=norm(question);
  for(const guide of guides){
   if(guide.id!==gameId)continue;
   if(!(Array.isArray(guide.intent)?guide.intent.includes(intent):guide.intent===intent))continue;
   if(!guide.match||!guide.match.test(q))continue;
   const gameDocs=documents.filter(d=>String(d.gameId)===String(gameId)&&!d.isExpansion);
   const refs=(guide.sections||[]).map(label=>gameDocs.find(d=>norm(d.title||'')===norm(label))||gameDocs.find(d=>norm(d.title||'').includes(norm(label))));
   // Exige que todas as seções citadas estejam carregadas. Sem a fonte, não usa o texto pré-redigido.
   if(refs.length && refs.every(Boolean))return {...guide,docs:refs};
  }
  return null;
 }
 function buildLocalAnswer(question,game,hits,confidence,intent,profile){
  const title=game?.title||game?.titulo||'este jogo';
  if(!hits.length){
   if(profile?.questionType==='permission')return `Não achei uma passagem que confirme se essa jogada é permitida em ${title}. Para não te orientar errado, preciso de um detalhe: qual ação você quer fazer e em que momento do turno?`;
   if(profile?.questionType==='quantity')return `Não encontrei no conteúdo carregado um número que responda a essa pergunta sobre ${title}. Você está perguntando sobre cartas, peças, recursos ou jogadores?`;
   if(profile?.questionType==='condition')return `Não localizei a consequência dessa situação nas regras que estão carregadas de ${title}. Descreva o que aconteceu imediatamente antes e qual resultado você quer confirmar.`;
   return `Ainda não encontrei a regra específica de ${title} que responde à sua pergunta. Sei qual assunto procurar, mas o texto disponível não traz evidência suficiente. Diga o nome da peça, ação ou fase envolvida para eu restringir a busca.`;
  }
  const top=hits[0], p=profile||queryProfile(question);
  const dossier=GAME_DOSSIERS[String(game?.id||top.gameId||'')];
  // Antes de reaproveitar frases isoladas, procura uma explicação autoral
  // específica para este jogo e esta intenção, apoiada nas seções indicadas.
  const guide=findRuleGuide(String(game?.id||top.gameId||''),question,intent);
  if(guide){
   const refs=guide.docs.map(d=>d.title).filter(Boolean);
   return `${guide.answer}\n\n**Base consultada:** ${refs.join('; ')} — ${top.manual||'manual do jogo'}.`;
  }
  if(intent==='strategy'&&dossier?.strategy){return `**Minha leitura estratégica — não é uma regra adicional do manual**\n\n${dossier.strategy}\n\nEstou deduzindo essas sugestões a partir do objetivo, das ações e das condições de pontuação descritas no manual. A decisão ideal ainda depende da situação da mesa.\n\n**Base consultada:** ${top.section} — ${top.manual||'manual do jogo'}.`;}
  const evidence=getRelevantUnits(top.text||top.excerpt,p,top.section,5);
  let rewritten=evidence.map(x=>rewriteRuleSentence(x.text));
  // Combine exact game-rule patterns into a small, useful explanation instead of replaying the paragraph.
  const joined=rewritten.join(' ');
  const original=norm(top.text||top.excerpt);
  let answer='';
  if(top.gameId==='catan'&&intent==='trade'&&/comercio/.test(original)){
   const bits=[];
   if(/restantes jogadores nao podem realizar trocas/.test(original))bits.push('A negociação é centralizada no jogador da vez: os demais participantes não podem trocar cartas entre si enquanto aguardam.');
   if(/4\s*1/.test(original))bits.push('Com o banco, a taxa normal é 4 cartas iguais para receber 1 matéria-prima à sua escolha.');
   if(/3\s*1/.test(original))bits.push('Se você tiver acesso a um porto 3:1, entrega três cartas iguais para receber uma à escolha.');
   if(/porto especial|2 cartas da materia/.test(original))bits.push('Um porto específico pode ser ainda melhor: duas cartas do recurso indicado pelo porto valem uma carta à sua escolha.');
   answer=bits.join('\n\n');
  } else if(top.gameId==='carcassonne'&&/monasterio/.test(original)&&intent==='scoring'){
   const complete=/rodeado por oito cartelas/.test(original), points=(original.match(/9 pontos/)||[]).length>0, returns=/monge retorna/.test(original);
   answer=`No Carcassonne, o monastério pontua pela vizinhança: ele precisa ficar cercado pelas oito cartelas ao redor. A própria cartela do monastério entra na conta, então, quando o espaço ao redor estiver completo, são 9 pontos. ${returns?'Depois de pontuar, você recupera o monge para a sua reserva.':''}`;
  } else if(top.gameId==='ticket-to-ride-europa'&&/bilhete/.test(original)&&/(bilhete|destino)/.test(norm(question))){
   const max3=/ate 3 bilhetes|compre ate 3|3 bilhetes/.test(original), keep=/pelo menos 1/.test(original), noDiscard=/nao podem ser descartados/.test(original);
   answer=`Completar suas rotas não aparece no manual como uma proibição de comprar Bilhetes de Destino depois. Você pode escolher essa compra em um turno posterior, desde que ainda haja bilhetes na pilha e a partida não tenha terminado. Só não dá para fazer isso como ação extra no mesmo turno em que você já escolheu controlar uma rota: comprar bilhetes é uma ação própria. ${max3?'Quando escolher essa ação, compre até três bilhetes. ':''}${keep?'Depois, mantenha pelo menos um dos comprados — pode ficar com dois ou com os três. ':''}${noDiscard?'Os bilhetes que decidir guardar não podem ser descartados em compras futuras. ':''}O manual não estabelece um limite total de bilhetes acumulados.`;
  } else if(top.gameId==='the-resistance'&&intent==='voting'&&/empat|rejeit/.test(norm(question))){
   answer='No The Resistance, empate não aprova a equipe: conta como rejeição. O próximo jogador no sentido horário assume a liderança e propõe outra equipe. Se cinco equipes forem rejeitadas consecutivamente na mesma missão, os espiões vencem.';
  } else if(top.gameId==='carcassonne'&&/cidade|cidades/.test(norm(question))&&/cidades e cavaleiros/.test(norm(top.section))&&intent==='scoring'){
   answer='Em Carcassonne, uma cidade fechada vale 2 pontos por cartela que faz parte dela. Cada brasão dentro da cidade acrescenta mais 2 pontos. Então, para calcular, conte as cartelas da cidade e some os brasões; não conte apenas o tamanho do desenho externo.';
  } else if(top.gameId==='azul'&&intent==='scoring'&&/pontu/.test(norm(question))){
   const raw=norm(top.text||top.excerpt);
   if(/azulejos diretamente adjacentes/.test(raw)||/conectados horizontalmente/.test(raw))answer='No Azul, a pontuação da parede é calculada no momento em que a peça é colocada. Uma peça isolada rende 1 ponto. Se ela tocar outras, conte o conjunto contínuo na horizontal e, depois, o conjunto contínuo na vertical; o azulejo recém-colocado entra nas duas contagens. Some os resultados das duas direções. Ao final da fase, aplique também as penalidades das peças que ficaram na fileira do chão. Os bônus de linhas, colunas e cores completas só entram quando a partida termina.';
  } else if(top.gameId==='ticket-to-ride-europa'&&/balsa|tunel/.test(norm(question))&&/rotas especiais/.test(norm(top.section))){
   answer='As duas rotas especiais cobram de um jeito diferente.\n\nNa balsa, os símbolos de locomotiva impressos indicam quantas locomotivas você precisa pagar obrigatoriamente; os outros espaços são pagos com cartas de vagão da mesma cor.\n\nNo túnel, primeiro você baixa as cartas do custo normal e revela três cartas do baralho. Cada carta revelada que combinar com a cor usada — ou for uma locomotiva — aumenta o custo em mais uma carta. Se não conseguir ou não quiser completar esse adicional, recolhe as cartas que baixou e perde a ação sem construir a rota.';
  } else if(top.gameId==='harmonies'&&/empilh|pilha|cubos de animal|habitat/.test(norm(question))&&/posicionar e empilhar/.test(norm(top.section))){
   answer='Em Harmonies, você pode construir elementos da paisagem empilhando peças, mas há limites claros: uma peça pode ficar sobre uma ou duas peças já colocadas para formar árvores, construções ou montanhas. Depois que uma peça já está no topo de uma pilha, não se coloca outra por cima dela. E espaço ocupado por Cubo de Animal não pode receber peça. Portanto, planeje a altura da pilha antes de colocar o cubo, porque ele bloqueia aquele espaço.';
  } else if(top.gameId==='catan'&&intent==='setup'){
   answer='No Catan, a preparação para principiantes fica assim:\n\n1. Cada jogador pega a tabela de custos e todas as peças da sua cor.\n2. Cada pessoa coloca duas aldeias e duas estradas nos espaços indicados pelo esquema inicial; as peças restantes ficam na reserva à sua frente.\n3. Se forem apenas três jogadores, retire todas as peças vermelhas. Deixe os dados e as cartas especiais ao lado do tabuleiro; separe as matérias-primas por tipo e embaralhe as cartas de Desenvolvimento.\n4. Para começar, cada jogador recebe uma carta de matéria-prima para cada terreno que toca a aldeia inicial indicada para sua cor.\n5. As cartas de matéria-prima ficam escondidas na mão durante a partida.\n\nA posição da aldeia inicial é importante porque determina seus primeiros recursos.';
  } else if(top.gameId==='azul'&&intent==='setup'){
   answer='Para preparar Azul, faça o seguinte:\n\n1. Entregue um tabuleiro a cada pessoa e usem todos o lado colorido (o lado cinza é da partida alternativa).\n2. Cada jogador coloca seu marcador no zero da trilha.\n3. Organizem as fábricas em círculo no centro: cinco para duas pessoas, sete para três e nove para quatro.\n4. Coloquem no saco as cem peças, vinte de cada cor.\n5. O primeiro jogador pega o marcador e coloca quatro peças aleatórias em cada fábrica. Devolvam à caixa os componentes que não serão usados.';
  } else if(intent==='setup'){
   let prepText=String(top.text||top.excerpt||'').replace(/^Montagem inicial para principiantes\s*/i,'').replace(/^Montagem da mesa\s*/i,'');
   const setupVerbs=/^(\d+[.)]\s*)?(cada jogador|cada pessoa|na primeira partida|por [úu]ltimo|por fim|d[eê]|vire|pegue|coloque|embaralhe|distribua|separe|misture|posicione|disponha|monte|deixe|escolha|receba|em primeiro lugar|em seguida|assegure|depois|se participam|com tres jogadores|preencha|o jogador)/i;
   const steps=naturalSentences(prepText).filter(x=>setupVerbs.test(x)).map(rewriteRuleSentence).slice(0,6);
   if(steps.length)answer=`Para preparar ${title}, organize a mesa nesta ordem:\n\n${steps.map((x,i)=>`${i+1}. ${x}`).join('\n')}`;
  } else if(top.gameId==='finca'&&/escassez de alimentos ou carrocas/.test(norm(top.section))){
   answer='No Finca, a falta de estoque provoca uma reposição coletiva. Se não houver alimento suficiente do tipo que você precisa, todos devolvem à reserva todos os marcadores daquele alimento — inclusive você. Depois, o jogador ativo pega a quantidade prevista. A mesma lógica vale para as carroças de burro. Isso pode deixar os outros jogadores sem aquele recurso e até fazer você terminar com menos do que tinha antes.';
  } else if(top.gameId==='harmonies'&&intent==='turn'){
   answer='Em Harmonies, pegar e posicionar as três peças é a parte obrigatória do turno. Depois disso, você pode escolher uma carta de animal e também pode colocar um cubo de animal se tiver um habitat que corresponda ao padrão exigido. Ou seja: as peças são obrigatórias; as ações dos animais são opcionais.';
  } else if(top.gameId==='azul'&&/fileira do chao/.test(norm(top.section))){
   answer='No Azul, os azulejos que você pegou mas não consegue ou não quer encaixar na fileira de modelo vão para a fileira do chão. Eles trazem penalidade na fase de revestimento da parede. Se essa fileira já estiver cheia, os azulejos excedentes ficam fora da área, na tampa da caixa, conforme a regra do manual.';
  }
  if(!answer){
   const selectedUnits=evidence.slice(0,p.questionType==='procedure'?5:4).map(x=>rewriteRuleSentence(x.text));
   answer=composeRuleExplanation(selectedUnits,intent,question);
   if(!answer)answer=rewritten.slice(0,3).join(' ');
   if(confidence!=='alta')answer+='\n\nEncontrei uma passagem relacionada, mas ela não resolve todos os detalhes da sua pergunta. Não vou completar a regra por suposição; confira a seção indicada ou descreva melhor a situação.';
  }
  if(!answer.trim())answer=`Encontrei a seção “${top.section}” em ${title}, mas não consegui transformar o conteúdo dela em uma resposta segura. Vou deixar a referência para você conferir.`;
  answer+=`\n\n**Onde conferir:** ${top.section} — ${top.manual||'manual do jogo'}.`;
  return answer;
 }
 function socialReply(q,history=[]){const n=norm(q);
  if(/^(vamos jogar|bora jogar|vamos jogar hoje|bora jogar hoje|quer jogar|vamos brincar|vamos nessa)$/.test(n))
   return 'Bora! 😄 Posso acompanhar uma partida, explicar regras ou ajudar a escolher um jogo. Qual jogo está pensando em colocar na mesa?';
  if(/^(td joia|tudo joia|ta joia|esta joia|joia|tudo certo por ai|tudo bem por ai|como vai vc|como vai voce|e ai tudo bem|e ai td bem)$/.test(n))
   return 'Tudo joia por aqui! 😄 E por aí? Podemos conversar ou escolher um jogo para colocar na mesa.';
  if(/^(to bem|estou bem|td certo|tudo certo|to de boa|estou de boa|na paz)$/.test(n))
   return 'Que bom! 😄 Por aqui tudo certo também. Quer conversar sobre jogos ou está pensando em jogar alguma coisa?';
  if(['sim','claro','com certeza','acho que sim','bora','vamos'].includes(n))return 'Fechado! 😊 Me diz por onde você prefere continuar: uma dúvida de jogo, uma sugestão para jogar ou outro assunto.';
  if(['nao','acho que nao','hoje nao'].includes(n))return 'Tranquilo. Não precisa forçar o assunto. Podemos falar de outra coisa ou deixar para depois.';
  if(['talvez','mais ou menos','nao sei'].includes(n))return 'Tudo bem ficar em dúvida. O que está pesando mais para você decidir?';
  if(/^(oi+|ola+|opa|e ai|eai)/.test(n)){
   const time=n.match(/bom dia|boa tarde|boa noite/);
   if(time)return socialReply(time[0]+(n.includes('tudo bem')?' tudo bem?':''),history);
   return 'Oi! 😄 Bom te ver por aqui. Como estão as coisas? Quer falar de jogos ou veio resolver outro assunto?';
  }
  if(/^(bom dia|boa tarde|boa noite)/.test(n)){
   const hello=n.startsWith('bom dia')?'Bom dia! ☀️':n.startsWith('boa tarde')?'Boa tarde! 😄':'Boa noite! 🌙';
   if(/tudo bem|tudo bom|e voce|e vc/.test(n))return `${hello} Tudo certo por aqui e pronto para conversar. Como está seu dia?`;
   return `${hello} Como começou seu dia? Hoje você está no clima de jogar, descobrir um jogo novo ou só bater papo?`;
  }
  if(/como foi seu dia|como esta sendo seu dia/.test(n))return 'Eu não tenho um dia como uma pessoa, mas estou por aqui acompanhando a conversa. E o seu, foi tranquilo ou daqueles que parecem não acabar?';
  if(/meu dia (foi|esta sendo) (ruim|pesado|puxado|corrido|complicado)/.test(n))return 'Poxa, parece que o dia veio pesado. Quer desabafar um pouco ou prefere mudar de assunto para distrair a cabeça?';
  if(/meu dia (foi|esta sendo) (bom|otimo|legal|produtivo|tranquilo)/.test(n))return 'Aí sim! 😄 Teve alguma coisa boa em especial ou foi daqueles dias em que tudo simplesmente encaixa?';
  if(/to cansad|estou cansad|muito cansad|sem energia|esgotad/.test(n))return 'Parece que você está precisando respirar um pouco. Foi um dia puxado ou esse cansaço vem acumulando?';
  if(/to trabalhando|estou trabalhando|no trabalho|no servico/.test(n))return 'Entendi — então estamos no modo expediente. Quer uma ajuda rápida com alguma coisa do trabalho ou só uma pausa de dois minutos para conversar?';
  if(/voce gosta de jogos|vc gosta de jogos|qual seu jogo favorito|qual jogo voce prefere/.test(n))return 'Não tenho gosto pessoal como um jogador, mas consigo analisar como os jogos funcionam: mecânicas, interação, estratégia, ritmo e complexidade. Posso também comparar dois jogos sem confundir opinião com regra.';
  if(/o que voce sabe fazer|o que voce consegue fazer|como pode me ajudar|no que voce e bom/.test(n))return 'Meu foco é destrinchar jogos: explicar turnos, custos, exceções, pontuação e situações que combinam várias regras. Também converso sobre assuntos do dia a dia. Quando a pergunta depende de informação atual da Internet, eu sinalizo quando só consigo abrir uma pesquisa externa.';
  if(/to entediad|estou entediad|sem nada para fazer|nao tenho nada para fazer/.test(n))return 'Vamos espantar esse tédio. Você prefere uma sugestão de jogo, uma curiosidade de tabuleiro, um desafio rápido ou conversar sobre qualquer outro assunto?';
  if(/vamos conversar|bora conversar|quero conversar|puxa assunto/.test(n))return 'Bora! Uma pergunta: numa noite de jogos, você prefere aquela disputa em que dá para atrapalhar os outros ou uma competição mais estratégica, cada um montando seu próprio plano?';
  if(/nao entendi|nao saquei|fiquei perdido|estou perdido|to perdido|meio perdido|estou confuso|to confuso|nao sei o que fazer|o que eu faco agora|me ajuda/.test(n))return 'Sem problema — vamos por partes. Você está perdido numa regra, no que fazer durante o turno ou numa situação que aconteceu na mesa? Conte o que acabou de acontecer e eu tento localizar a regra certa.';
  if(/obrigad|valeu|agradeco|brigada/.test(n))return 'Imagina! 😄 Que bom que foi útil. Pode mandar a próxima — não precisa escrever formalmente.';
  if(/falou|ate mais|tchau|fui|ate logo/.test(n))return 'Até mais! Boa jogatina — e que os dados estejam do seu lado! 🎲';
  if(/quem e voce|o que voce faz|como funciona/.test(n))return 'Sou o Meeple Expert. Minha especialidade é usar os manuais carregados para explicar regras, cruzar condições e indicar a seção que sustenta a resposta. Não sou uma IA generativa: quando o material não prova algo, eu aviso em vez de inventar.';
  if(/tudo bem|tudo bom|como vai|como voce esta|como vc/.test(n))return 'Tudo certo por aqui! 😄 E por aí, como estão as coisas?';
  if(/que horas/.test(n)){const now=new Date();return `No seu dispositivo, agora são ${now.toLocaleTimeString('pt-BR',{hour:'2-digit',minute:'2-digit'})}.`;}
  if(/que dia e hoje|qual a data de hoje|que data e hoje/.test(n)){const now=new Date();return `Hoje é ${now.toLocaleDateString('pt-BR',{weekday:'long',day:'2-digit',month:'long',year:'numeric'})}.`;}
  if(/triste|chatead|decepcionad|estressad|ansios/.test(n))return 'Poxa, sinto que isso não está sendo fácil. Quer me contar um pouco mais ou prefere que eu ajude a pensar em um próximo passo?';
  if(/feliz|animad|empolgad|contente/.test(n))return 'Que bom! 😄 O que aconteceu de bom?';
  if(/bom|legal|bacana|massa|show|blz|beleza|suave/.test(n))return 'Boa! 😄 Quer continuar nesse assunto ou puxar outro?';
  return 'Opa, manda. Pode escrever do seu jeito — só me diga um pouco do contexto para eu não responder algo nada a ver.';
 }
 function isSocial(q,history=[]){const n=norm(q);if(n.length>180)return false;
  const gameDetail=/(regra|pontu|carta|bilhete|peca|tabuleiro|rodada|turno|acao|recurso|rota|dado|meeple|jogada|construi|compr|manual|jogo)/.test(n);
  if(gameDetail&&/(perdid|confus|nao entendi|nao saquei|me ajuda)/.test(n))return false;
  const brief=new Set(['sim','nao','talvez','pode ser','claro','com certeza','acho que sim','acho que nao','to bem','estou bem','mais ou menos','e voce','e vc','bora','vamos']);
  const last=[...history].reverse().find(m=>m.role==='assistant'&&m.text);if(brief.has(n)&&last&&/[?]/.test(last.text))return true;
  const socialPatterns=[
   /^(oi+|ola+|opa|e ai|eai)(\s+(bom dia|boa tarde|boa noite|td bem|tudo bem|td bom|tudo bom|td joia|tudo joia|tudo certo|e voce|e vc|por ai|meeple|meu amigo|tudo tranquilo))*$/,
   /^(bom dia|boa tarde|boa noite)(\s+(tudo bem|tudo bom|e voce|e vc|meeple|meu amigo|por ai))*$/,
   /^(vamos jogar|bora jogar|vamos jogar hoje|bora jogar hoje|quer jogar|vamos brincar|vamos nessa|td joia|tudo joia|ta joia|esta joia|joia|tudo certo por ai|tudo bem por ai|como vai vc|como vai voce|e ai tudo bem|e ai td bem|to bem|estou bem|td certo|tudo certo|to de boa|estou de boa|na paz)$/,
   /^(tudo bem|td bem|tudo bom|td bom|tudo joia|td joia|tudo certo|como vai|como vai voce|como voce esta|como vc ta|quem e voce|o que voce faz|como funciona|o que voce sabe fazer|o que voce consegue fazer|como pode me ajudar|no que voce e bom|voce gosta de jogos|vc gosta de jogos|qual seu jogo favorito|como foi seu dia|vamos conversar|bora conversar|quero conversar|puxa assunto|to entediado|estou entediado|sem nada para fazer|nao tenho nada para fazer|nao entendi|nao saquei|fiquei perdido|estou perdido|to perdido|estou confuso|to confuso|nao sei o que fazer|o que eu faco agora|me ajuda|obrigado|obrigada|valeu|falou|ate mais|tchau|fui|ate logo|beleza|blz|tranquilo|tudo tranquilo|que horas sao|que dia e hoje|qual a data de hoje|que data e hoje)$/
  ];
  if(socialPatterns.some(re=>re.test(n)))return true;
  return /(meu dia (foi|esta sendo)|to cansado|estou cansado|sem energia|estou trabalhando|to trabalhando|no trabalho|estou triste|to triste|estou feliz|to feliz|estou estressado|to estressado|estou (meio )?(perdido|confuso)|to (meio )?(perdido|confuso)|nao sei o que fazer agora|o que eu faco agora|me ajuda)/.test(n);
 }
 function isWholeGameQuestion(q){const n=norm(q);const asksOverview=/(me explica|me ensina|explica pra mim|explique|fale sobre|me fala sobre|resuma|resumo|qual a ideia|qual e a proposta|como joga|como jogar|me apresenta|o que acha de|vale a pena jogar|me conta sobre)/.test(n);const beginner=/\b(jogo|partida|nunca joguei|primeira vez|sou iniciante|do zero|comecar|comecando|visao geral|objetivo geral|regras principais)\b/.test(n);const specific=/(pontu|carta|bilhete|peca|turno|rodada|acao|recurso|rota|dado|compra|construi|moviment|preparacao|empilh|votacao|comerc|troca)/.test(n);return (asksOverview&&(beginner||!specific))||/(nunca joguei|sou iniciante|me ensina a jogar|primeira partida|como comecar a jogar)/.test(n);}
 function temporalEvidence(text, marker){
  const s=norm(text);
  const checks={
   antes:/\b(antes|previamente|primeiro|primeira etapa|no inicio|inicialmente)\b/,
   depois:/\b(depois|apos|em seguida|posteriormente|subsequente|na sequencia|mais tarde)\b/,
   durante:/\b(durante|enquanto|ao longo)\b/,
   imediatamente:/\b(imediatamente|logo depois|em seguida)\b/,
   'no inicio':/\b(no inicio|inicialmente|primeiro|primeira etapa)\b/,
   'no final':/\b(no final|ao final|no fim|finalmente)\b/,
   'em seguida':/\b(em seguida|depois|apos|posteriormente)\b/,
   apos:/\b(apos|depois|em seguida|posteriormente)\b/
  };
  return checks[marker] ? checks[marker].test(s) : true;
 }
 function permissionEvidence(text){
  const s=norm(text);
  return /\b(pode|podem|poder|permitido|permitida|proibido|proibida|nao pode|nao podem|obrigatorio|obrigatoria|deve|devem|necessario|necessaria|somente|apenas|precisa|precisam|tem que)\b/.test(s);
 }
 function gameRuleBoost(question,game,doc,profile){
  const q=norm(question),t=norm((doc.title||'')+' '+(doc.text||'')),id=String(game.id||'');
  if(id==='the-resistance'&&(/vot|empate|rejeit|equipe/.test(q))&&(/votacao para a equipe|equipe e aprovada|empate tambem conta/.test(t)))return 18;
  if(id==='finca'&&(/escassez|falta|acab|carroc|reserva|alimento/.test(q))&&(/escassez de alimentos ou carrocas/.test(norm(doc.title||''))))return 22;
  if(id==='catan'&&profile.intent==='trade'&&(/comercio|troca/.test(q))&&(/2\. comercio/.test(t)))return 18;
  if(id==='carcassonne'&&(/monaster|monge/.test(q))&&(/monasterios e monges/.test(norm(doc.title||''))))return 20;
  if(id==='carcassonne'&&(/cidade|cidades|brasao|muralha/.test(q))&&(/cidades e cavaleiros/.test(norm(doc.title||''))))return 20;
  if(id==='ticket-to-ride-europa'&&(/bilhete|destino/.test(q))&&(/comprar bilhetes de destino/.test(norm(doc.title||''))))return 18;
  if(id==='ticket-to-ride-europa'&&(/balsa|tunel/.test(q))&&(/rotas especiais balsas e tuneis/.test(norm(doc.title||''))))return 18;
  if(id==='azul'&&(/fileira do chao|chao|sobra|sobrar/.test(q))&&(/fileira do chao/.test(norm(doc.title||''))))return 20;
  if(id==='catan'&&profile.intent==='setup'&&/^preparacao$/.test(norm(doc.title||'')))return 25;
  if(profile.intent==='setup'&&/preparacao|montagem inicial|componentes e preparacao/.test(norm(doc.title||'')))return 17;
  if(id==='azul'&&profile.intent==='scoring'&&/pontuacao/.test(norm(doc.title||'')))return 18;
  if(id==='harmonies'&&(/turno|acao|obrigatorio|opcional/.test(q))&&(/como funciona um turno/.test(norm(doc.title||''))))return 15;
  return 0;
 }
 function searchGame(question,game,history=[]){
  let q=String(question||'').trim();const n=norm(q);
  if(/^(estou|to|tô)? ?(meio )?(perdido|confuso)|nao sei o que fazer|o que eu faco agora|me ajuda$/.test(n))return {status:'need_context',answer:`Vamos localizar isso sem chutar. Em ${game.title}, me diga em que fase ou momento você está e o que aconteceu logo antes. Se puder, descreva as peças/cartas envolvidas; aí procuro a regra correspondente.`,game,confidence:'baixa',hits:[]};
  if(/^(e |mas |entao |nesse caso|e se |e quando |e depois|isso |essa |esse |pode entao|e posso|e da para|e ai)/.test(n)){const prior=[...history].reverse().find(m=>m.role==='user'&&m.text);if(prior)q=prior.text+' '+question;}
  const profile=queryProfile(q),intent=profile.intent,exp=/expans|1912|variante|modo especial/.test(norm(q));
  const docs=docIndex.filter(x=>(x.d.gameId===game.id||x.d.game===game.title||x.d.game===game.titulo)&& (exp||!x.d.isExpansion)); 
  const scored=docs.map(x=>{const base=scoreIndexed(x,profile),ruleBoost=gameRuleBoost(q,game,x.d,profile),faqBoost=faqSectionBoost(q,game.id,x.d.title||'');const boost=ruleBoost+faqBoost;return {x,...base,score:base.score+boost,domainBoost:boost,faqBoost};}).filter(x=>x.score>=.45&&(x.matched>=1||x.phraseHits>0||x.titleHits>0||x.domainBoost>0)).sort((a,b)=>b.score-a.score);
  const meaningfulTerms=(profile.terms.baseTerms||[]).filter(t=>t.length>2&&!STOP.has(t));
  if(profile.intent==='general'&&meaningfulTerms.length<2&&(!scored[0]||scored[0].domainBoost===0))return {status:'need_context',answer:`Entendi que você quer uma orientação sobre ${game.title}, mas ainda não sei qual situação está acontecendo. Qual foi sua última jogada e o que você está tentando fazer agora?`,game,confidence:'baixa',hits:[]};
  const found=[],seen=new Set();for(const x of scored){const d=x.x.d,key=(d.manual||'')+'|'+(d.sectionId||d.title);if(seen.has(key))continue;seen.add(key);found.push({game:game.title,gameId:game.id,manual:d.manual||'Manual do jogo',section:d.title||d.section||'Trecho do manual',excerpt:sentenceExcerpt(d.text,profile),text:d.text,url:d.url||'',manualFile:d.manualFile||'',sectionId:d.sectionId||'',isExpansion:!!d.isExpansion,score:Math.round(x.score*100)/100,matched:x.matched,matchedCore:x.matchedCore,titleHits:x.titleHits,coverage:x.coverage,phraseHits:x.phraseHits,domainBoost:x.domainBoost||0,source:'manual'});if(found.length>=5)break;}
  const top=found[0];let confidence='baixa';if(top&&top.domainBoost>=15)confidence='alta';else if(top&&((top.coverage>=.66&&top.matchedCore>=2)||(top.coverage>=.8&&top.phraseHits>=1&&top.score>=10)||(top.titleHits>=2&&top.score>=10)||(top.phraseHits>=2&&top.score>=3)||(top.matchedCore>=3&&top.score>=4.5)))confidence='alta';else if(top&&((top.matchedCore>=1&&top.score>=1.05)||(top.phraseHits>=1&&top.score>=1.25)||(top.titleHits>=1&&top.score>=1.3)))confidence='media';
  // Não transformar uma seção apenas relacionada em resposta para perguntas de sequência ou permissão.
  // A evidência precisa conter um marcador que sustente a relação perguntada.
  let evidenceGap='';
  if(top&&confidence!=='baixa'&&profile.temporal&&!temporalEvidence(top.excerpt,profile.temporal)){
   confidence='baixa';evidenceGap=`Encontrei uma seção relacionada (“${top.section}”) no manual de ${game.title}, mas o trecho recuperado não confirma que a ação aconteça ${profile.temporal} do outro passo que você mencionou. Não vou presumir essa ordem. Confira o trecho relacionado abaixo ou me diga quais são exatamente as duas ações para eu procurar uma regra mais específica.`;
  }
  if(top&&confidence!=='baixa'&&profile.questionType==='permission'&&!permissionEvidence(top.excerpt)){
   confidence='baixa';evidenceGap=`Encontrei uma seção relacionada (“${top.section}”) no manual de ${game.title}, mas o trecho não declara claramente se a ação é permitida, proibida ou obrigatória. Prefiro não transformar uma referência próxima em uma resposta de sim ou não.`;
  }
  let hits=confidence==='baixa'?(evidenceGap?[{...top,evidenceRole:'related-not-confirming'}]:[]):found.slice(0,3);
  // Se existe uma explicação específica e todas as seções-fonte estão carregadas,
  // usa essas evidências reais em vez de deixar a resposta depender do melhor parágrafo isolado.
  const matchedGuide=!evidenceGap?findRuleGuide(game.id,question,intent):null;
  if(matchedGuide){
   confidence='alta';
   hits=matchedGuide.docs.map(d=>({game:game.title,gameId:game.id,manual:d.manual||'Manual do jogo',section:d.title||d.section||'Seção do manual',excerpt:sentenceExcerpt(d.text,profile,d.title,650),text:d.text,url:d.url||'',manualFile:d.manualFile||'',sectionId:d.sectionId||'',isExpansion:false,score:20,matched:3,matchedCore:3,titleHits:1,coverage:1,phraseHits:1,source:'manual'}));
  }
  const answer=evidenceGap?evidenceGap:buildLocalAnswer(question,game,hits,confidence,intent,profile);
  return {status:evidenceGap?'partial':(hits.length?(confidence==='alta'?'confirmed':'possible'):'not_found'),answer,game,confidence,intent,hits,normalizedQuery:profile.q,evidenceGap,interpretation:{questionType:profile.questionType,negative:profile.negative,temporal:profile.temporal,condition:profile.condition,quantities:profile.quantity,concepts:profile.concepts.map(x=>x.group.concept)}};
 }
 function isGlossaryQuestion(q){const n=norm(q);return /(o que e|oq e|significa|quer dizer|definicao|defina|explique|explica|mecanica|termo|como funciona esse conceito)/.test(n)||n.split(' ').length<=3;}
 function lookupGlossary(q){
  const n=norm(q);if(!isGlossaryQuestion(q))return null;
  const ranked=[];
  for(const entry of GLOSSARY){const terms=[entry.term,...(entry.aliases||[])].map(norm).filter(x=>x.length>=2).sort((a,b)=>b.length-a.length);
   const match=terms.find(t=>(` ${n} `).includes(` ${t} `));if(match)ranked.push({entry,match,length:match.length,score:match.length+(n.includes('o que e')||n.includes('significa')?3:0)});
  }
  ranked.sort((a,b)=>b.score-a.score);return ranked[0]||null;
 }
 function naturalSentences(text){
  let clean=String(text||'').replace(/\r/g,' ').replace(/\s+/g,' ').trim();
  clean=clean.replace(/\(ver as p[aá]gs?\.\s*[^)]*\)/gi,'').replace(/\(ver p[aá]g(?:ina)?s?\.\s*[^)]*\)/gi,'');
  clean=clean.replace(/\s+(?=\d{1,2}[.)]\s+[A-ZÁÀÂÃÉÊÍÓÔÕÚÇ])/gu,'\n');
  return clean.split(/\s+(?=[A-ZÁÀÂÃÉÊÍÓÔÕÚÇ])/u).length===0?[]:
   clean.split(/(?<=[.!?])\s+(?=[A-ZÁÀÂÃÉÊÍÓÔÕÚÇ])/u).flatMap(x=>x.split(/\n+/)).map(x=>x.trim()).filter(x=>x.length>20);
 }
 function gameOverview(game){
  const docs=documents.filter(d=>String(d.gameId)===String(game.id)&&!d.isExpansion);
  const dossier=GAME_DOSSIERS[String(game.id)];
  if(dossier){
   const sections=[];
   sections.push(`**A ideia central**\n${dossier.summary}`);
   sections.push(`**O que você faz na sua vez**\n${dossier.turn}`);
   sections.push(`**O que conta para vencer**\n${dossier.win}`);
   // Add a grounded first-game setup explanation from the actual preparation section.
   const preferred={catan:/^preparacao$/i,carcassonne:/componentes e preparacao/i,azul:/preparacao do jogo/i,finca:/preparacao/i,harmonies:/preparacao da partida/i,'ticket-to-ride-europa':/preparacao da partida/i,'the-resistance':/preparacao/i};
   const prep=docs.find(d=>preferred[game.id]?.test(norm(d.title||'')))||docs.find(d=>/preparacao|montagem inicial|antes de comecar/i.test(norm(d.title||'')));
   if(prep&&game.id==='catan'){
    // A preparação do Catan está num bloco longo. Expõe o processo completo,
    // em linguagem direta, em vez de capturar só as primeiras frases do manual.
    sections.push('**Para colocar a primeira partida na mesa**\n1. Cada pessoa recebe a tabela de custos e as peças da sua cor: 5 aldeias, 4 cidades e 15 estradas.\n2. Use o esquema para iniciantes: cada jogador coloca 2 aldeias e 2 estradas no tabuleiro; as peças restantes ficam reservadas à sua frente.\n3. Em uma partida com 3 pessoas, retire as peças vermelhas. Deixe os dados e as cartas especiais ao lado do tabuleiro.\n4. Separe as cartas de matérias-primas em pilhas por tipo e embaralhe as cartas de Desenvolvimento, deixando-as viradas para baixo.\n5. Cada jogador recebe uma carta de recurso para cada terreno adjacente à sua aldeia inicial indicada no esquema. Essas cartas ficam escondidas na mão.');
   } else if(prep){
    const prepText=String(prep.text||'').replace(/^Montagem inicial para principiantes\s*/i,'').replace(/^Montagem da mesa\s*/i,'');
    const rawSteps=naturalSentences(prepText).filter(x=>/(^cada jogador|^cada pessoa|^na primeira partida|^coloque|^embaralhe|^distribua|^separe|^misture|^posicione|^disponha|^monte|^deixe|^escolha|^receba|^em primeiro lugar|^em seguida|^assegure|^depois|^por [úu]ltimo|^\d+[.)]\s*|^d[eê]|^vire|^pegue|^preencha|^o jogador)/i.test(x)&&!/recomendamos|siga a montagem|p[aá]ginas? [0-9]|^se participam|^todos os jogadores/i.test(x));
    const steps=rawSteps.slice(0,6).map(rewriteRuleSentence).filter(Boolean);
    if(steps.length)sections.push(`**Para colocar a primeira partida na mesa**\n${steps.map((x,i)=>`${i+1}. ${x}`).join('\n')}`);
   }
   if(dossier.strategy)sections.push(`**Uma dica para a primeira partida — interpretação estratégica, não regra**\n${dossier.strategy}`);
   const refs=docs.filter(d=>/visao geral|introducao|objetivo|como funciona o turno|resumo do jogo|fim da partida|fim do jogo|preparacao|montagem inicial/i.test(d.title||'')).slice(0,6);
   return {status:'confirmed',answer:sections.join('\n\n'),game,confidence:'alta',intent:'overview',hits:refs.map(d=>({game:game.title,gameId:game.id,manual:d.manual||'Manual do jogo',section:d.title,text:d.text,excerpt:sentenceExcerpt(d.text,queryProfile('objetivo regras turno preparação primeira partida'),650),source:'manual'})),sourceType:'manual-dossier'};
  }
  const overview=docs.find(d=>/visao geral|introducao|resumo do jogo|objetivo do jogo/i.test(d.title||''))||docs[0];
  if(!overview)return {status:'not_found',answer:`O módulo de ${game.title} está carregado, mas não encontrei uma seção de visão geral no conteúdo disponível.`,game,confidence:'baixa',hits:[]};
  const intro=(overview.text||'').split(/Contexto histórico|Contexto historico/i)[0].trim();
  const answer=paraphraseRuleText(intro,700,queryProfile('objetivo e ideia principal do jogo'),overview.title);
  return {status:'confirmed',answer,game,confidence:'media',intent:'overview',hits:[{game:game.title,gameId:game.id,manual:overview.manual||'Manual do jogo',section:overview.title,text:overview.text,excerpt:sentenceExcerpt(intro,queryProfile('objetivo do jogo'),650),source:'manual'}]};
 }
 function findExplicitSection(gameId,question){
  const q=norm(question);if(!q)return null;
  const mentionsSection=/(?:secao|capitulo|parte de|parte do|topico|me explica melhor|me explique melhor|pode explicar|explique a secao|explique o topico|o que eu preciso fazer quando chega a parte de)/.test(q);
  if(!mentionsSection)return null;
  const stop=new Set(['parte','secao','capitulo','topico','como','funciona','explica','explique','preciso','fazer','quando','chega','chegar','jogo','manual','regra','regras','sobre','para','com','uma','uns','umas','dos','das','de','do','da','e','o','a','os','as']);
  const candidates=documents.filter(d=>String(d.gameId)===String(gameId)&&String(d.title||d.section||'').trim())
   .map(d=>{const raw=String(d.title||d.section||'').replace(/^\s*\d+[.)]?\s*/,'');const title=norm(raw);const terms=title.split(' ').filter(t=>t.length>=4&&!stop.has(t));const exact=title.length>=4&&(` ${q} `).includes(` ${title} `);const matched=terms.filter(t=>(` ${q} `).includes(` ${t} `));return {d,title,exact,terms,matched,raw};})
   .filter(x=>x.exact||x.matched.length>=2||x.matched.length===1&&x.terms.length===1)
   .sort((a,b)=>Number(b.exact)-Number(a.exact)||b.matched.length-a.matched.length||b.title.length-a.title.length||Number(!!a.d.isExpansion)-Number(!!b.d.isExpansion));
  if(!candidates.length)return null;
  // A single generic word such as “preparação” is not enough to pick among sections.
  const top=candidates[0];
  if(!top.exact&&top.matched.length===1){const sameScore=candidates.filter(x=>!x.exact&&x.matched.length===1);if(sameScore.length!==1)return null;}
  const wantsExpansion=/expans|mini expans|1912|variante/.test(q);
  if(wantsExpansion){const selected=candidates.find(x=>x.d.isExpansion)||top;return selected.d;}
  const tied=candidates.filter(x=>x.exact===top.exact&&x.matched.length===top.matched.length&&x.title.length===top.title.length);
  return (tied.find(x=>!x.d.isExpansion)||top).d;
 }
 function ask(question,selectedGame,history=[]){const original=String(question||'').trim();if(original.length<2)return {status:'not_found',answer:'Digite uma pergunta sobre um jogo.',hits:[]};if(isSocial(original,history))return {status:'greeting',answer:socialReply(original,history),hits:[],confidence:'alta'};
  // Primeiro identifica o jogo e tenta resolver regras estruturadas. O glossário vem depois:
  // termos genéricos como “espaço” ou “movimento” não podem sequestrar uma pergunta de regra.
  const resolved=detectGame(original,selectedGame,history);if(resolved.ambiguous)return {status:'ambiguous',ambiguous:true,answer:'Identifiquei mais de um jogo. Selecione o título correto para eu não misturar os manuais.',hits:[],games:resolved.found.map(id=>gameCatalog.get(id)?.title||id)};
  const game=resolved.id?(gameCatalog.get(resolved.id)||(root.MeepleRuleInteractions?.findPack({id:resolved.id})?{id:resolved.id,title:(root.MEEPLE_RULE_INTERACTION_PACKS?.packs||[]).find(p=>p.gameId===resolved.id)?.gameAliases?.[0]||resolved.id}:null)):null;
  if(game){const structuredInteraction=root.MeepleRuleInteractions?.resolve(original,game);if(structuredInteraction)return {...structuredInteraction,game};}
  // Regra oficial específica da carta Monopólio de Catan. A edição local carregada
  // explica quando jogar cartas de Desenvolvimento, mas não transcreve o efeito
  // individual desta carta; por isso a resposta aponta também para a fonte primária.
  if(game&&String(game.id).toLowerCase()==='catan'&&/\bmonopol\w*\b/.test(norm(original))){
   const localRule=documents.find(d=>d.gameId==='catan'&&/4\. casos especiais/i.test(String(d.title||'')));
   const officialUrl='https://www.catan.com/sites/default/files/2021-06/catan_base_rules_2020_200707.pdf';
   const officialHit={game:game.title,gameId:'catan',manual:'CATAN Game Rules & Almanac (fonte oficial)',section:'Development Cards — Monopoly',title:'CATAN — regra oficial da carta Monopoly',excerpt:'A carta manda anunciar um tipo de matéria-prima; os demais jogadores entregam todas as cartas desse tipo que tiverem na mão.',text:'A carta Monopoly (Monopólio) exige que o jogador anuncie um tipo de matéria-prima. Todos os outros jogadores entregam todas as cartas desse tipo que possuem.',url:officialUrl,page:5,score:100,matched:8,matchedCore:8,coverage:1,phraseHits:2,source:'official-publisher'};
   const hits=[officialHit];
   if(localRule)hits.push({game:game.title,gameId:'catan',manual:localRule.manual||'Manual local do Catan Plus',section:localRule.title,excerpt:'A carta de Desenvolvimento pode ser jogada em qualquer momento do seu turno, inclusive antes de lançar os dados. Não pode ser jogada no mesmo turno em que foi comprada. Cartas de Progresso são retiradas do jogo depois de usadas.',text:localRule.text||'',score:25,matched:4,matchedCore:4,coverage:1,phraseHits:1,source:'manual'});
   return {status:'confirmed',answer:'No Catan, a carta **Monopólio** funciona assim:\n\n1. Você anuncia um tipo de matéria-prima: madeira, argila, lã, cereal ou minério.\n2. **Todos os outros jogadores** devem entregar a você todas as cartas daquele tipo que tiverem na mão. Não é só um adversário escolhido: o efeito alcança todos os oponentes.\n3. Quem não tiver nenhuma carta daquele tipo não entrega nada. Você não precisa ter esse recurso na sua própria mão para escolher esse tipo.\n\n**Quando pode jogar:** no seu turno, em qualquer momento — inclusive antes de rolar os dados. Normalmente, só se joga uma carta de Desenvolvimento por turno, e não se pode jogar uma carta comprada naquele mesmo turno. A exceção é uma carta de Ponto de Vitória que complete os 10 pontos: ela pode ser revelada no próprio turno em que foi comprada. Depois de resolvida, a carta de Progresso sai do jogo.\n\n**Exemplo:** se você anunciar minério e três adversários tiverem, respectivamente, 2, 1 e 0 minérios, você recebe os 3 minérios dos dois primeiros; o terceiro não entrega nada.',game,confidence:'alta',intent:'cards',hits,sourceType:'official-card-rule',ruleValidation:{status:'confirmed',rules:['catan-monopoly'],sourceTitle:'CATAN Game Rules & Almanac (Catan Studio)',sourceUrl:officialUrl,sourcePages:[5],deterministic:true},interpretation:{questionType:'procedure',card:'Monopólio',gameEdition:'Catan base game rules 2020',source:'official-publisher'}};
  }
  // A pergunta que nomeia uma seção deve abrir o trecho daquele jogo antes
  // de qualquer termo do glossário que coincida por acaso com palavras do título.
  if(game){const section=findExplicitSection(game.id,original);if(section){const profile=queryProfile(section.title||section.section||original);const full=String(section.text||'').replace(/\s+/g,' ').trim();const excerpt=full.length<=1550?full:sentenceExcerpt(full,profile,1450);const hit={game:game.title,gameId:game.id,manual:section.manual||'Manual do jogo',section:section.title||section.section||'Seção do manual',excerpt,text:full,url:section.url||'',manualFile:section.manualFile||'',sectionId:section.sectionId||'',isExpansion:!!section.isExpansion,score:100,matched:8,matchedCore:8,coverage:1,phraseHits:2,source:'manual',evidenceRole:'explicit-section'};return {status:'confirmed',answer:`**${hit.section}**\n\n${excerpt}\n\nEsse trecho foi recuperado diretamente da seção correspondente do manual carregado.`,game,confidence:'alta',intent:'section',hits:[hit],sourceType:'explicit-section',interpretation:{questionType:'section',section:hit.section,expansion:hit.isExpansion,source:'manual-local'}};}}
  const glossaryHit=lookupGlossary(original);if(glossaryHit){const e=glossaryHit.entry;return {status:'glossary',answer:`**${e.label||e.term}**\n\n${e.definition}\n\nIsso é uma explicação geral da mecânica; a forma exata de aplicá-la depende das regras do jogo que você estiver jogando.`,hits:[],confidence:'alta',glossary:e.term};}
  if(!game)return {status:'need_game',answer:'Qual jogo você está usando? Selecione-o no contexto ou escreva o nome na pergunta. Assim consigo consultar o manual certo.',hits:[]};
  const remembered=findRememberedAnswer(original,game.id);if(remembered)return remembered;
  if(isWholeGameQuestion(original))return gameOverview(game);
  const playerSetup=setupQuantityAnswer(original,game,history);if(playerSetup)return playerSetup;
  // Specific, manually-grounded rule already present in this local knowledge base for the Catan 7 roll.
  if(String(game.id).toLowerCase()==='catan'&&/(?:\b7\b|sete)/.test(norm(original))&&/(?:tir|sai|rol|dado|lanc|jog|cair|resultado)/.test(norm(original))){const rule=documents.find(d=>d.gameId==='catan'&&/saiu o 7|ladrao entra em cena/i.test(String(d.title||'')+' '+String(d.text||'')));if(rule){const excerpt='Quando sai 7 nos dados, ninguém recebe matérias-primas. Todos os jogadores com mais de 7 cartas de matéria-prima descartam metade, arredondando para baixo. Depois, quem lançou os dados deve mover o ladrão para outro terreno e pode roubar uma carta, às cegas, de um jogador com aldeia ou cidade adjacente ao terreno escolhido. Em seguida, continua o turno normalmente, começando a fase de comércio.';const hit={game:game.title,gameId:'catan',manual:rule.manual||'Manual do jogo',section:rule.title||'Saiu o 7: o ladrão entra em cena',excerpt,text:rule.text||excerpt,sectionId:rule.sectionId||'',score:20,matched:5,coverage:1,source:'manual'};return {status:'confirmed',answer:'No Catan, quando você tira 7 nos dados, acontece o seguinte:\n\n1. Ninguém recebe matérias-primas nessa rodada.\n2. Cada jogador com mais de 7 cartas descarta metade, arredondando para baixo. Por exemplo: quem tem 9 descarta 4.\n3. Quem lançou os dados move o ladrão para outro terreno.\n4. Depois, pode roubar uma carta aleatória de um jogador com aldeia ou cidade adjacente ao terreno escolhido.\n5. Em seguida, continua o turno normalmente.\n\nA regra detalhada está indicada na seção de casos especiais do material de Catan carregado.',game,confidence:'alta',intent:'exception',hits:[hit],normalizedQuery:norm(original),interpretation:{questionType:'procedure',negative:false,quantities:[7],concepts:['rolagem','ladrão']}};}}
  const result=searchGame(original,game,history);
  const comparative=resolveComparativePermission(original,game,result);
  return comparative||result;
 }
 function rankWebResults(question,game,results){const profile=queryProfile(question);return (results||[]).map((r,i)=>{const d={title:r.title||'',text:r.content||r.snippet||''},x={title: norm(d.title),text:norm(d.text),all:norm(d.title+' '+d.text),tf:new Map(tokenize(d.title+' '+d.text).map(t=>[t,1])),len:tokenize(d.title+' '+d.text).length||1};const s=scoreIndexed(x,profile);return {...r,score:s.score,excerpt:sentenceExcerpt(r.content||r.snippet||r.title,profile,650),index:i+1};}).sort((a,b)=>b.score-a.score);}
 function getStats(){const faqTotal=Object.values(FAQ_BANK).reduce((n,g)=>n+(g.questions||[]).length,0);return {games:gameCatalog.size,manualSections:documents.length,synonymConcepts:groups.length,synonymAliases:groups.reduce((n,g)=>n+(g.aliases||[]).length,0),slangForms:Object.keys(SLANG).length,questionExamples:(DATA.questions?.questions||[]).length,faqTotal,faqPerGame:(Object.values(FAQ_BANK).length?Math.min(...Object.values(FAQ_BANK).map(g=>(g.questions||[]).length)):0),memoryAnswers:getMemoryStats(),glossaryEntries:GLOSSARY.length,gameDossiers:Object.keys(GAME_DOSSIERS).length,playerSetupGames:Object.keys(PLAYER_SETUP).length,knowledgeBytes:documents.reduce((n,d)=>n+String(d.text||'').length,0)};}
 root.MeepleExpertCore={ask,registerModule,addGame,documents,gameCatalog,detectGame,isContextDependentQuery,norm,tokenize,expandTokens,rankWebResults,getStats,buildLocalAnswer,paraphraseRuleText,socialReply,isSocial,lookupGlossary,gameOverview,detectIntent,queryProfile,semanticQuestionText,removeMetaTemporalPhrases,splitScenarioParts,extractScenarioCounts,resolveComparativePermission,scoreIndexed,rebuildIndex,searchGame,detectPlayerCount,setupQuantityAnswer,rememberAnswer,findRememberedAnswer,getMemoryStats,faqSectionBoost,ruleInteractionStats:()=>root.MeepleRuleInteractions?.stats()||{packs:0,ruleCount:0}};
})(window);
