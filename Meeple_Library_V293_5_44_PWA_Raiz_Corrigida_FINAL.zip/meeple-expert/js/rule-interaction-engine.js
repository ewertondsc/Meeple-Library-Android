/* Meeple Expert V5.8 — resolução contextual, comparação de criaturas e controle de jangadas.
   Só responde quando há pacote estruturado com fonte, citação literal e regra aplicável. */
(function(root){
  'use strict';
  const DATA = root.MEEPLE_RULE_INTERACTION_PACKS || { packs: [] };
  const packs = new Map();
  const norm = value => String(value || '').normalize('NFD').replace(/[\u0300-\u036f]/g,'').toLowerCase().replace(/[^a-z0-9]+/g,' ').replace(/\s+/g,' ').trim();

  function validatePack(pack){
    if(!pack || !pack.packId || !pack.source?.url || !Array.isArray(pack.evidence) || !Array.isArray(pack.rules)) return {ok:false,reason:'Estrutura incompleta.'};
    if(!/^https:\/\//i.test(pack.source.url)) return {ok:false,reason:'A fonte precisa usar HTTPS.'};
    const ids = new Set();
    for(const item of pack.evidence){
      if(!item.id || !item.quote || String(item.quote).length < 24 || !item.section || !Number.isInteger(Number(item.page)) || Number(item.page) < 1 || !item.fact || ids.has(item.id)) return {ok:false,reason:'Evidência sem ID, citação, seção, página, explicação ou com ID duplicado.'};
      ids.add(item.id);
    }
    for(const rule of pack.rules){
      if(!rule.id || !rule.creature || !Array.isArray(rule.effects) || !rule.effects.length || !rule.evidenceIds?.length) return {ok:false,reason:`Regra inválida: ${rule.id || 'sem id'}.`};
      const validOutcomes=new Set(['eliminate','push','displace','move','protect','ignore']);
      if(rule.evidenceIds.some(id=>!ids.has(id)) || rule.effects.some(effect=>!effect.element || !validOutcomes.has(effect.outcome) || (!effect.scope && !effect.destination) || !ids.has(effect.evidenceId))) return {ok:false,reason:`Regra ${rule.id} sem efeito tipado ou evidência correspondente.`};
    }
    for(const scoring of (pack.scoringRules||[])){
      if(!scoring.id || !scoring.intent || !scoring.evidenceIds?.length || scoring.evidenceIds.some(id=>!ids.has(id))) return {ok:false,reason:`Regra de pontuação inválida: ${scoring.id || 'sem id'}.`};
    }
    for(const raftRule of (pack.raftRules||[])){
      if(!raftRule.id || !raftRule.intent || !raftRule.controlCondition || !Array.isArray(raftRule.evidenceIds) || !raftRule.evidenceIds.length || raftRule.evidenceIds.some(id=>!ids.has(id))) return {ok:false,reason:`Regra de jangada inválida: ${raftRule.id || 'sem id'}.`};
    }
    for(const ability of (pack.abilities||[])){
      if(!ability.id || !Array.isArray(ability.allowedAgainst) || !ability.condition || !ability.effect || !ability.evidenceIds?.length || ability.evidenceIds.some(id=>!ids.has(id))) return {ok:false,reason:`Habilidade inválida: ${ability.id || 'sem id'}.`};
    }
    return {ok:true};
  }
  function registerPack(pack){
    const checked=validatePack(pack);
    if(!checked.ok) return checked;
    packs.set(pack.packId,pack);
    return {ok:true,packId:pack.packId};
  }
  (DATA.packs || []).forEach(registerPack);

  function findPack(game){
    if(!game) return null;
    const candidates=[game.id,game.title,game.name,game.titulo,...(game.aliases||[])].filter(Boolean).map(norm);
    for(const pack of packs.values()){
      const aliases=(pack.gameAliases||[]).map(norm);
      if(candidates.some(c=>aliases.some(a=>c===a || (c.length>8 && a.length>8 && (c.includes(a)||a.includes(c)))))) return pack;
    }
    return null;
  }
  function findCreatureRules(question,pack){
    const q=norm(question);
    return pack.rules.filter(rule => (rule.creatureAliases||[rule.creature]).some(alias=>{
      const a=norm(alias); return a && (` ${q} `).includes(` ${a} `);
    }));
  }
  function evidenceFor(pack, rules, includeTriggers=false){
    const ids=new Set(rules.flatMap(rule=>rule.evidenceIds||[]));
    if(includeTriggers) ids.add('creature-interaction-triggers');
    if(rules.some(rule=>rule.id==='shark')) ids.add('swimmer-definition');
    return pack.evidence.filter(item=>ids.has(item.id));
  }
  function sourceHit(pack, item){
    return {
      game:'Survive the Island', gameId:'survive-the-island',
      manual:pack.source.title+' ('+pack.edition+')', section:item.section,
      excerpt:item.fact+'\n\nCitação literal (fonte em inglês): “'+item.quote+'”',
      text:item.fact+' '+item.quote, url:pack.source.url,
      page:item.page, score:100, matched:4, matchedCore:4, coverage:1,
      source:'structured-official-rule-pack', ruleEvidenceId:item.id
    };
  }
  function buildCreatureDescription(rule, question){
    if(rule.id==='sea-serpent') return '**Serpente Marinha:** elimina as jangadas e todos os aventureiros no espaço, inclusive nadadores e passageiros embarcados.';
    if(rule.id==='shark') return '**Tubarão:** elimina somente nadadores — aventureiros em espaços de água que não estejam em jangadas. A jangada e seus passageiros não são afetados.';
    if(rule.id==='kaiju') return '**Kaiju:** elimina jangadas, empurra aventureiros para espaços adjacentes (não precisam ser o mesmo espaço) e desloca outras criaturas conforme suas regras de movimento.';
    return '';
  }
  function creatureMentionPosition(question,rule){
    const q=norm(question);
    const positions=(rule.creatureAliases||[rule.creature]).map(alias=>norm(alias)).filter(Boolean).map(alias=>q.indexOf(alias)).filter(x=>x>=0);
    return positions.length?Math.min(...positions):Infinity;
  }
  function creatureScenarioPosition(question,rule){
    const q=norm(question);
    const aliases=(rule.creatureAliases||[rule.creature]).map(norm).filter(Boolean);
    const action=/(entra|entrar|entrou|aparece|aparecer|apareceu|surge|surgir|surgiu|chega|chegar|chegou|move|movimenta|desloca|ocupa|interage|foi colocado|e colocado|colocada|esta no|estao no)/;
    const candidates=[];
    for(const alias of aliases){
      let from=0;
      while(true){
        const pos=q.indexOf(alias,from);if(pos<0)break;
        const nearby=q.slice(Math.max(0,pos-35),Math.min(q.length,pos+alias.length+35));
        if(action.test(nearby))candidates.push(pos);
        from=pos+alias.length;
      }
    }
    return candidates.length?Math.min(...candidates):Infinity;
  }
  function isCreatureComparison(question){
    const q=norm(question);
    return /\b(diferenca entre|diferenca do|compare|comparar|comparacao|comparativo|versus|vs|ao contrario de|ja o|por outro lado)\b/.test(q);
  }
  function hasConcreteCreatureScenario(question){
    const q=norm(question);
    const action=/(entra|entrar|aparece|aparecer|surge|surgir|chega|chegar|move|movimenta|desloca|ocupa|interage|vai para|vem para|e colocado|colocada|nada|nadando|esta no|estao no|ocupado|no mesmo espaco)/.test(q);
    const element=/(jangad|balsa|raft|nad|swimmer|aventureiro|passageiro|mesmo espaco|nesse espaco|espaco ocupado)/.test(q);
    return action&&element;
  }
  function parseCreatureScenario(question){
    const q=norm(question);
    const number='(\\d+|zero|um|uma|dois|duas|tres|quatro|cinco|seis|sete|oito|nove|dez)';
    const raftPassengers=firstCount(q,[
      new RegExp('\\b(?:jangada|balsa|raft)\\s+(?:ocupada\\s+)?com\\s+'+number+'\\s+aventureiros?\\b'),
      new RegExp('\\b'+number+'\\s+aventureiros?\\s+(?:a bordo|embarcados?|na jangada|na balsa)\\b')
    ]);
    const swimmers=firstCount(q,[
      new RegExp('\\b'+number+'\\s+nadadores?\\b'),
      new RegExp('\\b'+number+'\\s+aventureiros?\\s+nadando\\b')
    ]);
    return {
      hasRaft:/jangad|balsa|raft/.test(q),
      raftPassengers,
      hasSwimmer:/nad|swimmer/.test(q),
      swimmers: swimmers===null && /\bnadador\b/.test(q) ? 1 : swimmers,
      asksKaijuLocation:/kaiju (?:permanece|fica)|permanece no espaco|fica no espaco|onde fica o kaiju|kaiju continua/.test(q),
      asksPushDestination:/para onde|onde (?:vai|vao|ficam)|espacos adjacentes|espacos ao lado/.test(q)
    };
  }
  function buildCreatureScenario(rule,question,scenario){
    const parts=[];
    const q=norm(question);
    if(rule.id==='sea-serpent'){
      parts.push('**Serpente Marinha:** elimina as jangadas e todos os aventureiros no espaço, inclusive nadadores e passageiros embarcados.');
      if(scenario.hasRaft&&/jangada vazia/.test(q)){
        parts.push('**Jangada vazia + nadador:** o nadador é eliminado e a jangada vazia também é removida. A jangada vazia não funciona como proteção.');
        if(scenario.raftPassengers!==null){
          const label=scenario.raftPassengers===2?'dois':scenario.raftPassengers===1?'um':String(scenario.raftPassengers);
          parts.push(`**Jangada com ${label} aventureiros:** a jangada e os passageiros são eliminados. ${scenario.raftPassengers===2?'Os dois passageiros também são removidos.':''}`);
        }
      } else {
        if(scenario.hasRaft) parts.push(scenario.raftPassengers!==null?`**Jangada:** é removida do tabuleiro, junto com os ${scenario.raftPassengers} aventureiro${scenario.raftPassengers===1?'':'s'} que estavam a bordo.`:'**Jangada:** é removida do tabuleiro.');
        if(scenario.hasSwimmer) parts.push('**Nadador:** também é eliminado pela Serpente Marinha.');
      }
      if(scenario.hasRaft){
        parts.push('**A jangada não fica vazia:** ela é removida do tabuleiro e não pode ser movimentada depois.');
        const asksSameTurnMovement=/(mesmo turno|nesse turno|durante meu turno|durante o turno)/.test(q)&&/(jangad|mover|moviment|desloc)/.test(q);
        if(asksSameTurnMovement) parts.push('**Pode movimentá-la depois, no mesmo turno? Não.** A jangada foi eliminada. Se a interação ocorrer na fase 3 — Criaturas, a fase de Ação, quando jangadas são movidas, já aconteceu; após a fase Criaturas, começa o turno do próximo jogador.');
      }
    } else if(rule.id==='shark'){
      parts.push('**Tubarão no cenário descrito:** elimina somente os nadadores. Um nadador é um aventureiro em espaço de água que não esteja em uma jangada.');
      if(scenario.hasSwimmer) parts.push(scenario.swimmers===1?'**Nadador:** o aventureiro que está nadando é eliminado.':(scenario.swimmers===null?'**Nadadores:** os aventureiros que estão nadando são eliminados.':`**Nadadores (${scenario.swimmers}):** esses aventureiros são eliminados.`));
      if(scenario.hasRaft){
        parts.push(scenario.raftPassengers!==null
          ? `**Jangada:** permanece no tabuleiro. Seus ${scenario.raftPassengers} passageiro${scenario.raftPassengers===1?'':'s'} não são eliminados pelo Tubarão.`
          : '**Jangada:** permanece no tabuleiro, e os aventureiros embarcados não são eliminados pelo Tubarão.');
      }
      if(!scenario.hasSwimmer&&!scenario.hasRaft) parts.push('A regra de interação do Tubarão afeta apenas aventureiros que estejam nadando; não elimina aventureiros em terra.');
    } else if(rule.id==='kaiju'){
      parts.push('**Kaiju no cenário descrito:** elimina a jangada e empurra os aventureiros que estão no espaço para espaços adjacentes. O efeito sobre os aventureiros é empurrá-los, não eliminá-los diretamente.');
      parts.push('**Outras criaturas:** o Kaiju também desloca outras criaturas conforme suas próprias regras de movimento, quando houver alguma no espaço.');
      if(scenario.hasRaft){
        parts.push('**Jangada:** é eliminada e retirada do tabuleiro.');
        if(scenario.raftPassengers!==null) parts.push(`**Aventureiros embarcados (${scenario.raftPassengers}):** não são eliminados pelo Kaiju. Eles são empurrados para espaços adjacentes; não precisam ir todos para o mesmo espaço.`);
        else parts.push('**Passageiros:** os aventureiros que estavam a bordo são empurrados para espaços adjacentes; não precisam ir todos para o mesmo espaço.');
      }
      if(scenario.hasSwimmer){
        parts.push(scenario.swimmers===1?'**Nadador:** também é um aventureiro. Portanto, é empurrado para um espaço adjacente, não eliminado pelo Kaiju.':(scenario.swimmers===null?'**Nadadores:** também são aventureiros e são empurrados para espaços adjacentes, não eliminados pelo Kaiju.':`**Nadadores (${scenario.swimmers}):** também são aventureiros e são empurrados para espaços adjacentes, não eliminados pelo Kaiju.`));
      }
      if(scenario.asksPushDestination||scenario.hasRaft||scenario.hasSwimmer) parts.push('**Destino:** cada aventureiro empurrado vai para um espaço adjacente ao espaço do Kaiju. Eles não precisam ser colocados no mesmo espaço. O jogador ativo decide as escolhas e a ordem de resolução das interações durante a fase Criaturas.');
      if(scenario.asksKaijuLocation) parts.push('**O Kaiju permanece?** Neste cenário, sim: ao entrar em um espaço com elementos com os quais interage, ele encerra imediatamente seu movimento. Como não foi descrito outro Kaiju para deslocá-lo, permanece nesse espaço após resolver a interação.');
    }
    return parts.join('\n\n');
  }
  function buildCreatureComparison(rules){
    const order=['shark','sea-serpent','kaiju'];
    const relevant=rules.filter(rule=>order.includes(rule.id)).sort((a,b)=>order.indexOf(a.id)-order.indexOf(b.id));
    if(relevant.length<2)return '';
    const rows=relevant.map(rule=>{
      if(rule.id==='shark')return '| **Tubarão** | Elimina somente nadadores. Jangadas e passageiros ficam intactos. |';
      if(rule.id==='sea-serpent')return '| **Serpente Marinha** | Elimina jangadas e todos os aventureiros no espaço, inclusive passageiros e nadadores. |';
      return '| **Kaiju** | Elimina jangadas e empurra aventureiros para espaços adjacentes; também desloca outras criaturas conforme suas regras. |';
    });
    return `**Comparação entre as criaturas:**\n\n| Criatura | Efeito oficial |\n|---|---|\n${rows.join('\n')}`;
  }
  const COUNT_WORDS={zero:0,um:1,uma:1,dois:2,duas:2,tres:3,quatro:4,cinco:5,seis:6,sete:7,oito:8,nove:9,dez:10};
  function parseCount(value){const n=norm(value);if(/^\d+$/.test(n))return Number(n);return Object.prototype.hasOwnProperty.call(COUNT_WORDS,n)?COUNT_WORDS[n]:null;}
  function splitRaftScenarios(question){
    const raw=String(question||'').replace(/\s+/g,' ').trim();
    return raw.split(/\b(?:agora\s+(?:imagine|suponha|considere)|(?:imagine|suponha|considere)\s+que|e\s+se)\b/ig).map(x=>x.trim()).filter(x=>x.length>0);
  }
  function firstCount(text,patterns){
    for(const re of patterns){const m=text.match(re);if(m)return parseCount(m[1]);}
    return null;
  }
  function parseRaftScenario(text){
    const n=norm(text);
    const num='(\\d+|zero|um|uma|dois|duas|tres|quatro|cinco|seis|sete|oito|nove|dez)';
    const mine=firstCount(n,[
      new RegExp('\\b(?:eu\\s+)?(?:tenho|possuo|estou com|fico com)\\s+(?:apenas\\s+|somente\\s+)?'+num+'\\s+aventureiros?\\b'),
      new RegExp('\\b'+num+'\\s+aventureiros?\\s+meus?\\b'),
      new RegExp('\\bmeus?\\s+(?:aventureiros?)\\s*[:=]?\\s*'+num+'\\b')
    ]);
    const opponents=[];
    const opponentPatterns=[
      new RegExp('\\b'+num+'\\s+aventureiros?\\s+(?:de|do)\\s+(?:outro\\s+)?jogador\\b','g'),
      new RegExp('\\b'+num+'\\s+aventureiros?\\s+(?:de|do)\\s+adversari[oa]\\b','g'),
      new RegExp('\\b(?:meu|minha|o|a)?\\s*adversari[oa]\\s+(?:tem|possui|conta com|esta com)\\s+(?:apenas\\s+|somente\\s+)?'+num+'\\b','g'),
      new RegExp('\\b(?:outro jogador)\\s+(?:tem|possui|conta com)\\s+(?:apenas\\s+|somente\\s+)?'+num+'\\b','g')
    ];
    for(const re of opponentPatterns){for(const m of n.matchAll(re)){const v=parseCount(m[1]);if(v!==null)opponents.push(v);}}
    return {mine,opponents};
  }
  function resolveRaftControl(question,pack){
    const q=norm(question);
    const asksRaft=/jangad|balsa|raft/.test(q);
    const asksControl=/(control|comand|direito de mover|quem pode mover|quem pode movimentar|posso mover(?: a jangada| uma jangada| la| ela)?|pode mover(?: a jangada| uma jangada| jangada| la| ela)?|mover (?:a|uma|essa) jangada|movimentar (?:a|uma|essa) jangada|movimenta la|move la|pilotar)/.test(q);
    if(!asksRaft||!asksControl)return null;
    const rule=(pack.raftRules||[]).find(x=>x.id==='raft-control');
    if(!rule)return null;
    const evidence=pack.evidence.filter(item=>rule.evidenceIds.includes(item.id));
    if(evidence.length!==rule.evidenceIds.length)return null;
    const scenarios=splitRaftScenarios(question).map(parseRaftScenario).filter(x=>x.mine!==null&&x.opponents.length>0);
    const parts=[];
    if(scenarios.length){
      scenarios.forEach((scenario,index)=>{
        const highestOpponent=Math.max(...scenario.opponents);
        const controls=scenario.mine>=highestOpponent;
        const rivalLabel= scenario.opponents.length>1 ? `Os adversários informados têm ${scenario.opponents.join(' e ')} aventureiros` : `O adversário tem ${highestOpponent} aventureiro${highestOpponent===1?'':'s'}`;
        parts.push(`**Cenário ${index+1}: ${controls?'você pode controlar e mover a jangada.':'você não pode controlar nem mover a jangada.'}** Você tem ${scenario.mine} aventureiro${scenario.mine===1?'':'s'} a bordo. ${rivalLabel}. ${controls?'Sua quantidade é igual ou maior que a do adversário.':'Sua quantidade é menor que a do adversário.'}`);
      });
    }
    parts.push('**Regra oficial:** para mover uma jangada ocupada, você precisa ter a bordo pelo menos tantos aventureiros seus quanto o adversário. “Pelo menos” inclui empate: se ambos tiverem a mesma quantidade, a condição é atendida.');
    parts.push('**Controlar não é o mesmo que estar embarcado:** seus aventureiros podem estar a bordo sem que você tenha o direito de movimentar a jangada. O direito depende da comparação da quantidade de aventureiros a bordo.');
    parts.push('**Jangada vazia:** pode ser movimentada por qualquer jogador na sua fase de Ação, desde que vá para um espaço de água adjacente sem outra jangada.');
    if(!scenarios.length){
      parts.unshift('O manual não atribui o controle apenas por estar embarcado. Para decidir uma situação concreta, compare quantos aventureiros seus e do adversário estão a bordo.');
    }
    const answer=`**Regra confirmada no manual oficial de Survive the Island — edição 2024.**\n\n${parts.join('\n\n')}\n\n**Fonte:** livro de regras oficial, página 4 — “Action — Movements / Moving a Raft”.`;
    return {
      status:'confirmed',confidence:'alta',intent:'raft_control',answer,
      hits:evidence.map(item=>sourceHit(pack,item)),
      ruleValidation:{status:'confirmed',packId:pack.packId,edition:pack.edition,rules:['raft-control'],evidenceIds:evidence.map(x=>x.id),sourceTitle:pack.source.title,sourceUrl:pack.source.url,sourcePages:[4],deterministic:true},
      interpretation:{questionType:'raft_control',deterministicRuleMatch:true,validatedBy:'MeepleRuleInteractions',ruleIds:['raft-control'],scenarioCount:scenarios.length}
    };
  }

  function resolveScoring(question,pack){
    const q=norm(question);
    const asksEnd=/fim da partida|encerramento|terceiro vulcao|3(?:o|º)? vulcao|termina|acaba a partida/.test(q);
    const asksScore=/pontu|ponto|escore|score|pontuam|pontuar|valor dos aventureiros|pontuacao final/.test(q);
    if(!asksEnd&&!asksScore)return null;
    const ids=['adventurer-treasure-value','endgame-conditions','unrescued-score-zero','raft-not-rescued-example'];
    const evidence=pack.evidence.filter(item=>ids.includes(item.id));
    if(evidence.length!==ids.length)return null;
    const asksRaft=/jangad|balsa|raft/.test(q);
    const asksIsland=/ilha/.test(q);
    const rescueIsland=/ilha de resgate|rescue island|ilhas de resgate/.test(q);
    const mentionsThirdVolcano=/terceiro vulcao|3(?:o|º)? vulcao/.test(q);
    const mentionsNoAdventurers=/nao restam|nenhum aventureiro|sem aventureiros restantes|nao ha aventureiros/.test(q);
    const parts=[];
    if(asksEnd){
      parts.push('**Condições oficiais de encerramento:** a partida termina quando não restam aventureiros para resgatar ou quando o terceiro vulcão é revelado. O manual não apresenta o esgotamento das peças de ilha como uma terceira condição.');
    }
    if(asksScore){
      parts.push('**Como calcular:** some os valores de tesouro impressos na base de cada aventureiro que foi efetivamente salvo, chegando a uma Ilha de Resgate. A pontuação é a soma desses valores; aventureiros eliminados ou não resgatados não entram na soma.');
    }
    if(mentionsThirdVolcano||asksRaft){
      parts.push('**Os dois aventureiros na jangada:** não pontuam. O exemplo oficial do manual esclarece que os dois aventureiros que ainda estavam numa jangada quando o terceiro vulcão foi revelado foram eliminados porque não chegaram às Ilhas de Resgate. Se o terceiro vulcão já foi revelado, aventureiros que ainda não foram resgatados valem zero.');
    }
    if(asksIsland){
      if(rescueIsland){
        parts.push('**Aventureiro na Ilha de Resgate:** pontua pelo valor de tesouro indicado na base, pois já foi salvo.');
      } else {
        parts.push('**Aventureiro “na ilha”:** preciso distinguir os dois casos. Se estiver numa ilha comum da ilha de partida, ainda não foi resgatado e vale zero quando o terceiro vulcão encerra a partida. Se estiver numa **Ilha de Resgate**, foi salvo e seu valor de tesouro entra na soma. O manual diferencia as Ilhas de Resgate dos espaços da ilha que está afundando.');
      }
    }
    if(mentionsNoAdventurers){
      parts.push('A outra condição de encerramento ocorre quando não há mais aventureiros a resgatar.');
    }
    parts.push('**Desempate:** se houver empate na maior pontuação, todos os jogadores empatados compartilham a vitória.');
    const answer=`**Regra confirmada pelo manual oficial de Survive the Island — edição 2024.**\n\n${parts.join('\n\n')}\n\n**Fonte:** livro de regras oficial, página 5 — condições de fim de jogo e exemplo de pontuação.`;
    return {
      status:'confirmed',confidence:'alta',intent:asksScore?'scoring':'endgame',
      answer,
      hits:evidence.map(item=>sourceHit(pack,item)),
      ruleValidation:{status:'confirmed',packId:pack.packId,edition:pack.edition,rules:['endgame-and-scoring'],evidenceIds:evidence.map(x=>x.id),sourceTitle:pack.source.title,sourceUrl:pack.source.url,sourcePages:[5],deterministic:true},
      interpretation:{questionType:'scoring_and_endgame',deterministicRuleMatch:true,validatedBy:'MeepleRuleInteractions',ruleIds:['endgame-and-scoring']}
    };
  }

  function isStrategyRequest(question){
    const q=norm(question);
    return /\b(estrateg\w*|melhor jogada|melhor caminho|melhor forma de|melhor maneira de|planej\w*|prioriz\w*|recomend\w*|o que devo fazer|qual seria a melhor|como maximizar)\b/.test(q);
  }
  function resolveStrategy(question,pack){
    if(!isStrategyRequest(question)) return null;
    const q=norm(question);
    const ids=['adventurer-treasure-value','adventurer-values-hidden-after-setup','raft-capacity','action-movement-budget','adventurer-on-foot-movement','adventurer-swimming-movement','swimming-once-per-turn','board-raft-on-shared-space','raft-movement','raft-control','shark-interaction','swimmer-definition'];
    const evidence=pack.evidence.filter(item=>ids.includes(item.id));
    if(evidence.length!==ids.length) return null;
    const mentionsShark=/tubara|shark/.test(q);
    const mentionsRaft=/jangad|balsa|raft/.test(q);
    const mentionsHighValue=/(?:valor|vale|valor de tesouro)\s+(?:de\s+)?5\b|\b5\s+ pontos\b/.test(q);
    const parts=[];
    parts.push('**Leitura estratégica — inferência, não regra adicional do manual:** com os dados fornecidos, não dá para determinar uma rota ótima porque faltam as posições exatas dos aventureiros, da jangada, do Tubarão e da Ilha de Resgate, além dos movimentos ainda disponíveis.');
    if(mentionsHighValue){
      parts.push('**Aventureiro de valor 5:** trate-o como prioridade de resgate se houver uma sequência legal e segura. Isso é uma decisão estratégica baseada no maior valor conhecido, não uma prioridade imposta pelo manual. Os valores dos dois outros aventureiros também importam para comparar o ganho total. O manual informa que os valores ficam na base e não podem ser consultados novamente depois que a partida começa; é necessário tê-los memorizado na preparação.');
    }
    if(mentionsShark){
      parts.push('**Risco do Tubarão:** evite mandar um aventureiro nadando para um espaço ocupado pelo Tubarão. O Tubarão elimina somente nadadores — aventureiros em espaços de água que não estejam em jangadas. Passageiros a bordo de uma jangada não são nadadores para essa regra.');
    }
    if(mentionsRaft){
      parts.push('**Uso da jangada:** verifique se ela está vazia ou se você a controla. Uma jangada vazia pode ser movida; uma ocupada só pode ser movida por quem tem a bordo pelo menos tantos aventureiros próprios quanto cada adversário. Ela se move para um espaço de água adjacente sem outra jangada. Cada jangada comporta até três aventureiros; quando um aventureiro chega ao mesmo espaço de uma jangada com vaga, embarca imediatamente.');
    }
    parts.push('**Movimentos disponíveis:** na fase de Ação, você pode fazer até três movimentos de um espaço, divididos livremente entre seus aventureiros e jangadas. A natação só pode ser usada uma vez por aventureiro em cada turno. Ao andar a pé, os pontos inicial e final devem ser uma peça da ilha, uma jangada ou uma Ilha de Resgate.');
    parts.push('**Plano provisório:** se a jangada puder ser alcançada por um movimento permitido sem colocar um nadador no espaço do Tubarão, use-a como rota protegida para aproximar os aventureiros da Ilha de Resgate. Se não houver essa sequência segura, não force a travessia a nado pelo espaço do Tubarão. Com os valores dos outros aventureiros e as distâncias desconhecidos, não é possível provar que salvar primeiro o aventureiro de valor 5 maximiza a pontuação total.');
    parts.push('**Para calcular a melhor jogada exata:** preciso ver a posição dos três aventureiros, do Tubarão, da jangada e da Ilha de Resgate no tabuleiro, saber se a jangada está vazia ou ocupada e quantos movimentos da fase de Ação ainda restam.');
    const answer=`${parts.join('\n\n')}\n\n**Base factual:** manual oficial da edição 2024, páginas 1, 2, 4 e 6. As recomendações acima são inferências estratégicas feitas a partir dessas regras, não regras oficiais.`;
    return {
      status:'partial',confidence:'media',intent:'strategy',answer,
      hits:evidence.map(item=>sourceHit(pack,item)),
      strategyGuard:true,
      sourceType:'manual-grounded-strategy',
      interpretation:{questionType:'strategy',strategyInference:true,deterministicRuleMatch:false,hasShark:mentionsShark,hasRaft:mentionsRaft,knownValueFive:mentionsHighValue,requiresBoardGeometry:true,missingBoardState:['posições/adjacências','estado e controle da jangada','movimentos restantes','valores dos outros aventureiros']}
    };
  }
  function resolve(question,game){
    const pack=findPack(game);
    if(!pack) return null;
    const q=norm(question);
    const strategy=resolveStrategy(question,pack);if(strategy)return strategy;
    const raft=resolveRaftControl(question,pack);if(raft)return raft;
    const scoring=resolveScoring(question,pack);if(scoring)return scoring;
    const allMentionedRules=findCreatureRules(question,pack).sort((a,b)=>creatureMentionPosition(question,a)-creatureMentionPosition(question,b));
    const mentionsCreature=/serpente|tubara|kaiju|criatura|repelente/.test(q);
    const comparisonAsked=isCreatureComparison(question);
    const concreteScenario=hasConcreteCreatureScenario(question);
    const asksInteraction=/jangad|nad|nadar|agua|espaco|ataque|interag|elimin|captur|entrar|entra|mesmo espaco|a bordo|passageir|repelente|o que acontece|se um aventureiro|diferenc|compar/.test(q);
    const asksStrategy=/estrateg|melhor jogada|como ganhar|como vencer|prioridade|plano|tatic|recomenda|o que devo fazer|chances de ganhar/.test(q);
    if(!allMentionedRules.length || !mentionsCreature || !asksInteraction || asksStrategy) return null;
    const scenarioRules=concreteScenario?allMentionedRules.map(rule=>({rule,pos:creatureScenarioPosition(question,rule)})).filter(x=>Number.isFinite(x.pos)).sort((a,b)=>a.pos-b.pos):[];
    const primaryRule=(concreteScenario&&allMentionedRules.length>1) ? (scenarioRules[0]?.rule || allMentionedRules[0]) : (allMentionedRules.length===1 ? allMentionedRules[0] : null);
    const focusedRules=primaryRule?[primaryRule]:allMentionedRules;
    const comparisonRules=(comparisonAsked&&primaryRule)?allMentionedRules:[];
    const evidenceRules=[...new Map([...focusedRules,...comparisonRules].map(rule=>[rule.id,rule])).values()];
    const scenario=parseCreatureScenario(question);
    const repellentAsked=/repelente|repellent/.test(q);
    const evidence=evidenceFor(pack,evidenceRules,true);
    if(evidenceRules.some(rule=>rule.id==='kaiju')){
      for(const id of ['creature-movement-stop','active-player-creature-choices']){
        const item=pack.evidence.find(x=>x.id===id);
        if(item&&!evidence.some(e=>e.id===id))evidence.push(item);
      }
    }
    if(focusedRules.some(rule=>rule.id==='sea-serpent')&&/(mesmo turno|nesse turno|durante meu turno|durante o turno)/.test(q)){
      const turnEvidence=pack.evidence.find(item=>item.id==='turn-structure');
      if(turnEvidence&&!evidence.some(item=>item.id===turnEvidence.id))evidence.push(turnEvidence);
    }
    if(repellentAsked){
      const ability=pack.abilities?.find(item=>item.id==='repellent');
      if(ability){for(const id of ability.evidenceIds){const item=pack.evidence.find(x=>x.id===id);if(item&&!evidence.some(e=>e.id===id))evidence.push(item);}}
    }
    const parts=focusedRules.map(rule=>concreteScenario?buildCreatureScenario(rule,question,scenario):buildCreatureDescription(rule,question)).filter(Boolean);
    if(comparisonRules.length){const comparison=buildCreatureComparison(comparisonRules);if(comparison)parts.push(comparison);}
    if(repellentAsked && evidenceRules.some(rule=>rule.id==='sea-serpent')) parts.push('**Repelente:** o manual lista o uso contra Tubarão ou Kaiju quando um aventureiro seu está no mesmo espaço. A Serpente Marinha não aparece entre os alvos permitidos; portanto, não afirme que o Repelente a remove.');
    else if(repellentAsked && evidenceRules.some(rule=>['shark','kaiju'].includes(rule.id))) parts.push('**Repelente:** pode ser usado quando um aventureiro seu está no mesmo espaço que um Tubarão ou Kaiju. Ao usar a habilidade, os aventureiros e/ou jangadas naquele espaço são poupados.');
    if(!parts.length)return null;
    const answer=`**Resposta baseada no livro de regras oficial da edição 2024.**\n\n${parts.join('\n\n')}\n\n**Quando a interação acontece:** quando a criatura entra no espaço ocupado pelos elementos, quando esses elementos entram no espaço da criatura ou quando a criatura é colocada ali pelo efeito de uma peça.\n\n**Fonte:** ${pack.source.citation}, páginas ${[...new Set(evidence.map(x=>x.page))].sort((a,b)=>a-b).join(' e ')} — ${pack.source.publisher}.`;
    return {
      status:'confirmed',confidence:'alta',intent:'interaction',answer,hits:evidence.map(item=>sourceHit(pack,item)),
      ruleValidation:{status:'confirmed',packId:pack.packId,edition:pack.edition,rules:focusedRules.map(rule=>rule.id),comparisonRules:comparisonRules.map(rule=>rule.id),evidenceIds:evidence.map(item=>item.id),sourceTitle:pack.source.title,sourceUrl:pack.source.url,sourcePages:[...new Set(evidence.map(x=>x.page))],deterministic:true},
      interpretation:{questionType:'interaction',deterministicRuleMatch:true,validatedBy:'MeepleRuleInteractions',primaryCreature:primaryRule?.id||null,ruleIds:focusedRules.map(rule=>rule.id),comparisonRuleIds:comparisonRules.map(rule=>rule.id),scenarioElements:{hasRaft:scenario.hasRaft,raftPassengers:scenario.raftPassengers,hasSwimmer:scenario.hasSwimmer,swimmers:scenario.swimmers},comparisonAsked}
    };
  }
  function registerModule(game){
    if(!game) return {ok:false,reason:'Módulo sem metadados.'};
    const supplied=game.ruleInteractionPack || game.ruleInteractionsPack || game.rules?.interactionPack;
    if(!supplied) return {ok:true,skipped:true};
    return registerPack(supplied);
  }
  function stats(){return {packs:packs.size,packIds:[...packs.keys()],evidenceCount:[...packs.values()].reduce((n,p)=>n+p.evidence.length,0),ruleCount:[...packs.values()].reduce((n,p)=>n+p.rules.length,0),raftRuleCount:[...packs.values()].reduce((n,p)=>n+(p.raftRules||[]).length,0)};}
  root.MeepleRuleInteractions={validatePack,registerPack,registerModule,findPack,resolve,stats};
})(window);
