/* Meeple Expert V5.8 — pacotes de regras estruturadas, com proveniência explícita.
   Os fatos abaixo foram transcritos do livro de regras oficial de Survive the Island (Zygomatic/Asmodee, 2024).
   Não generalizar este pacote para Escape from Atlantis ou outras edições. */
(function(root){
  'use strict';
  root.MEEPLE_RULE_INTERACTION_PACKS = {
    schemaVersion: 1,
    packs: [{
      packId: 'survive-the-island-official-2024',
      gameId: 'survive-the-island',
      gameAliases: ['Survive the Island', 'Survive: The Island', 'Survive The Island 2024'],
      edition: 'Edição base de 2024 (Zygomatic / Asmodee)',
      languageOfSource: 'en',
      source: {
        title: 'Survive the Island — Official Rulebook',
        publisher: 'Zygomatic / Asmodee',
        officialGamePage: 'https://www.zygomatic-games.com/game/survive-the-island/',
        url: 'https://cdn.svc.asmodee.net/production-asmodeeca/uploads/2024/07/ZYGSTI01EN_RULES_20240227-low.pdf',
        citation: 'Livro de regras oficial, edição 2024',
        verifiedAt: '2026-11-16'
      },
      evidence: [
        { id: 'creature-interaction-triggers', page: 6, section: 'Creatures: Movements and Interactions', quote: 'These interactions occur when: 1. The Creature moves onto a space occupied with these Elements. 2. These Elements are moved onto a space occupied by the Creature. 3. The Creature comes into play through the effect of a Creature tile (see page 8) and is placed on a space occupied by these Elements.', fact: 'As interações são resolvidas quando a criatura entra no espaço, quando elementos entram no espaço da criatura ou quando a criatura surge ali por efeito de uma peça.' },
        { id: 'creature-movement-stop', page: 6, section: 'Creatures: Movements and Interactions — Movement stop', quote: 'A Creature immediately ends its movement if it enters a space occupied by one or more Elements it interacts with.', fact: 'Uma criatura encerra imediatamente seu movimento quando entra em um espaço ocupado por um ou mais elementos com os quais interage.' },
        { id: 'active-player-creature-choices', page: 7, section: 'FAQ — Creature movement and Kaiju interactions', quote: 'The active player makes all those choices and decides on the order in which to apply the interactions.', fact: 'Durante a fase Criaturas, o jogador ativo faz as escolhas de movimento e decide a ordem em que aplica as interações.' },
        { id: 'sea-serpent-interaction', page: 6, section: 'Creatures: Movements and Interactions — Sea Serpent', quote: 'Interaction: Eliminates Rafts and all Adventurers (including Swimmers).', fact: 'A Serpente Marinha elimina jangadas e todos os aventureiros no espaço, inclusive nadadores.' },
        { id: 'turn-structure', page: 3, section: 'How to Play — Player Turn', quote: 'A player’s turn consists of 3 phases: 1. Action — Move Adventurers and/or Rafts and use tile Abilities. 2. Rising Waters — Remove a tile from the board and look at the back. 3. Creatures — Roll the die and move a Creature. Once the 3 phases are completed, the next player’s turn can begin.', fact: 'O turno tem três fases, nesta ordem: Ação (movimentar aventureiros e/ou jangadas), Águas Subindo e Criaturas. Depois que as três fases terminam, começa o turno do próximo jogador.' },
        { id: 'shark-interaction', page: 6, section: 'Creatures: Movements and Interactions — Shark', quote: 'Interaction: Eliminates Swimmers.', fact: 'O Tubarão elimina somente nadadores.' },
        { id: 'kaiju-interaction', page: 6, section: 'Creatures: Movements and Interactions — Kaiju', quote: 'Interaction: Eliminates Rafts, pushes Adventurers onto any adjacent spaces (not necessarily the same), and displaces Creatures according to their Movement rules.', fact: 'O Kaiju elimina jangadas, empurra aventureiros para espaços adjacentes (que não precisam ser o mesmo) e desloca criaturas conforme as regras de movimento delas.' },
        { id: 'swimmer-definition', page: 6, section: 'Player Aid Anatomy', quote: 'A swimmer is an Adventurer on a Water space (not on a Raft).', fact: 'Nadador é um aventureiro em um espaço de água que não esteja em uma jangada.' },
        { id: 'raft-movement', page: 4, section: 'Action — Movements — Moving a Raft', quote: 'Move an empty Raft or a Raft you control to an adjacent Water space with no Raft.', fact: 'Durante a fase de Ação, pode-se mover uma jangada vazia ou uma jangada que o jogador controla para um espaço de água adjacente sem outra jangada.' },
        { id: 'raft-control', page: 4, section: 'Action — Movements — Moving a Raft', quote: 'To control a Raft, you must have at least as many of your Adventurers on board as your opponents.', fact: 'Para controlar uma jangada, o jogador precisa ter a bordo pelo menos tantos aventureiros seus quanto os aventureiros dos adversários.' },
        { id: 'repellent-use', page: 8, section: 'Tiles with Abilities — Repellent', quote: 'You can use this Ability any time when one of your Adventurers is on the same space as a Shark or a Kaiju. Remove the Creature from the board.', fact: 'O Repelente pode ser usado quando um aventureiro seu está no mesmo espaço que um Tubarão ou Kaiju; remove essa criatura do tabuleiro.' },
        { id: 'repellent-faq', page: 7, section: 'FAQ — Repellent', quote: 'No! All the Adventurers and/or Rafts sharing the Creature’s space are spared and remain on that space.', fact: 'Quando o Repelente é usado, aventureiros e/ou jangadas que compartilham o espaço da criatura são poupados e permanecem ali.' },
        { id: 'adventurer-treasure-value', page: 2, section: 'Goal of the Game', quote: 'Each Adventurer carries a treasure, whose value is indicated on its base.', fact: 'Cada aventureiro carrega um tesouro, cujo valor está indicado na base da peça.' },
        { id: 'adventurer-values-hidden-after-setup', page: 2, section: 'Setup — placing Adventurers', quote: 'Once the game starts, you can no longer look at the treasure value written underneath your Adventurer meeples! Try to memorize them as you place them.', fact: 'Depois que a partida começa, os jogadores não podem voltar a olhar o valor de tesouro na base dos aventureiros; devem memorizar os valores durante a colocação.' },
        { id: 'raft-capacity', page: 1, section: 'Components', quote: '12 Raft meeples, containing up to 3 Adventurer meeples each', fact: 'Cada jangada comporta até três aventureiros.' },
        { id: 'action-movement-budget', page: 4, section: 'Action — Movements', quote: 'During the Action phase, if you still have Adventurers to save, you can perform up to 3 one-space movements, freely divided among Rafts and your Adventurers.', fact: 'Durante a fase de Ação, se ainda houver aventureiros a salvar, o jogador pode realizar até três movimentos de um espaço, distribuídos livremente entre jangadas e aventureiros.' },
        { id: 'adventurer-on-foot-movement', page: 4, section: 'Action — Movements — Moving an Adventurer on foot', quote: 'The Adventurer’s starting AND ending points are either an Island tile, a Raft or a Rescue Island.', fact: 'Ao andar a pé, o ponto inicial e o final do aventureiro devem ser uma peça da ilha, uma jangada ou uma Ilha de Resgate.' },
        { id: 'adventurer-swimming-movement', page: 4, section: 'Action — Movements — Moving an Adventurer by swimming', quote: 'The Adventurer’s starting OR ending point is a Water space.', fact: 'Ao nadar, o ponto inicial ou o final do movimento do aventureiro é um espaço de água.' },
        { id: 'swimming-once-per-turn', page: 4, section: 'Action — Movements — Moving an Adventurer by swimming', quote: 'Each Adventurer meeple can be moved by swimming only once per turn.', fact: 'Cada aventureiro só pode ser movimentado por natação uma vez por turno.' },
        { id: 'board-raft-on-shared-space', page: 4, section: 'Action — Movements — Moving a Raft', quote: 'When an Adventurer is on the same space as a Raft, place it immediately aboard if there is still room left.', fact: 'Quando um aventureiro fica no mesmo espaço que uma jangada, coloque-o imediatamente a bordo se ainda houver espaço.' },
        { id: 'endgame-conditions', page: 5, section: 'End of the Game', quote: 'The game ends when no Adventurers are left to be rescued or when a 3rd Volcano is revealed.', fact: 'A partida termina quando não restam aventureiros para resgatar ou quando o terceiro vulcão é revelado.' },
        { id: 'unrescued-score-zero', page: 5, section: 'End of the Game', quote: 'If the eruption of the 3rd Volcano triggers the end of the game, you score 0 points for the Adventurers you could not rescue.', fact: 'Se a erupção do terceiro vulcão encerrar a partida, os aventureiros que não puderam ser resgatados valem zero pontos.' },
        { id: 'raft-not-rescued-example', page: 5, section: 'End of the Game — Final score example', quote: 'When the 3rd Volcano is revealed, her 2 remaining Adventurers on a Raft are eliminated because she didn’t get the chance to lead them to the Rescue Islands.', fact: 'No exemplo oficial, os dois aventureiros restantes numa jangada são eliminados quando o terceiro vulcão é revelado porque não chegaram às Ilhas de Resgate.' }
      ],
      scoringRules: [{
        id: 'endgame-and-scoring',
        intent: 'scoring_and_endgame',
        evidenceIds: ['adventurer-treasure-value','endgame-conditions','unrescued-score-zero','raft-not-rescued-example']
      }],
      raftRules: [{
        id: 'raft-control',
        intent: 'raft_control',
        controlCondition: 'player_adventurers_on_board_at_least_as_many_as_opponents',
        emptyRaftMovable: true,
        evidenceIds: ['raft-movement','raft-control']
      }],
      rules: [
        {
          id: 'sea-serpent', creature: 'Serpente Marinha', creatureAliases: ['serpente marinha','serpente','sea serpent'],
          movement: { spaces: ['water'], range: 1 },
          effects: [
            { element: 'raft', outcome: 'eliminate', scope: 'all_in_interaction_space', evidenceId: 'sea-serpent-interaction' },
            { element: 'adventurer', outcome: 'eliminate', scope: 'all_in_interaction_space_including_swimmers_and_raft_passengers', evidenceId: 'sea-serpent-interaction' }
          ],
          evidenceIds: ['creature-interaction-triggers','sea-serpent-interaction']
        },
        {
          id: 'shark', creature: 'Tubarão', creatureAliases: ['tubarao','shark'],
          movement: { spaces: ['water'], range: '1-2' },
          effects: [
            { element: 'swimmer', outcome: 'eliminate', scope: 'only_adventurers_in_water_not_on_rafts', evidenceId: 'shark-interaction' }
          ],
          unaffected: ['raft','raft_passenger'], evidenceIds: ['creature-interaction-triggers','shark-interaction','swimmer-definition']
        },
        {
          id: 'kaiju', creature: 'Kaiju', creatureAliases: ['kaiju'],
          movement: { spaces: ['water','land'], range: '1-2' },
          effects: [
            { element: 'raft', outcome: 'eliminate', scope: 'all_in_interaction_space', evidenceId: 'kaiju-interaction' },
            { element: 'adventurer', outcome: 'push', destination: 'any_adjacent_space', evidenceId: 'kaiju-interaction' },
            { element: 'creature', outcome: 'displace', destination: 'according_to_its_movement_rules', evidenceId: 'kaiju-interaction' }
          ],
          evidenceIds: ['creature-interaction-triggers','kaiju-interaction']
        }
      ],
      abilities: [{
        id: 'repellent', aliases: ['repelente','repellent'],
        allowedAgainst: ['shark','kaiju'], notAllowedAgainst: ['sea-serpent'],
        condition: 'one_of_your_adventurers_same_space_as_shark_or_kaiju',
        effect: 'remove_creature_and_spare_adventurers_and_rafts_in_its_space',
        evidenceIds: ['repellent-use','repellent-faq']
      }]
    }]
  };
})(window);
