MEEPLE LIBRARY V293.5.5 — MEEPLE EXPERT 5.9

INTEGRAÇÃO
- Mantém a interface, o histórico, o seletor de jogos e o fluxo de conversa do Meeple AI da V293.5.4.
- Incorpora a base semântica, sinônimos, FAQ, guias, dossiês, glossário e matriz de preparação do Meeple Expert 5.9.
- O Expert recupera e classifica evidências; o Worker atual do Meeple AI continua responsável pela síntese em linguagem natural e pela pesquisa externa.
- Ao consultar um jogo que possui módulo instalado na Biblioteca, a versão desse módulo é sincronizada para o índice Expert daquele jogo. Os dados dos demais jogos não são removidos.
- A interface Meeple AI foi redesenhada para desktop e celular.
- O cache do PWA foi versionado novamente e os scripts Expert entraram no pré-cache offline.

PRESERVAÇÃO DE DADOS
- Nenhum dado do navegador é apagado ou migrado neste pacote.
- Conversas, módulos e preferências existentes continuam nos mesmos armazenamentos e na mesma origem do site.
- Publique no mesmo domínio/origem e mantenha o mesmo caminho/base usados pela instalação anterior. Não limpe os dados do Chrome nem o IndexedDB.

ARQUIVOS
- meeple-expert/data/: conjuntos de dados executáveis do Expert 5.9.
- meeple-expert/js/: motor de interação por regras e motor semântico.
- O app standalone do Expert não foi incluído para evitar uma segunda interface e uma segunda camada de armazenamento.

VALIDAÇÃO
- Os scripts foram verificados sintaticamente com Node.js.
- O motor Expert foi carregado isoladamente e testado com perguntas sobre Azul e Catan.
