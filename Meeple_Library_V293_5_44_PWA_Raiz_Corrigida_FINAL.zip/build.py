#!/usr/bin/env python3
"""Rode depois de adicionar/alterar manuais: python3 build.py
Cada jogo = pasta em manuais/<id>/ com meta.json (fonte única dos dados) + arquivos .html (+ manual-original.pdf opcional).

FASE 1 (só leitura): verifica tudo. Se houver ERRO, aborta sem alterar nenhum arquivo.
FASE 2: injeta tema/ferramentas/busca nos manuais, gera library.json, files.json e a versão do cache, e confere o resultado.

Opções:
  --verificar          só a fase 1 (não altera nada)
  --permitir-remover   aceita que um jogo ou campo da versão anterior tenha saído de propósito
  --sem-teste          pula a verificação (não recomendado)"""
import json,os,re,sys,hashlib,glob,html as _html,unicodedata
R=os.path.dirname(os.path.abspath(__file__))
THEME='<!--app-theme--><script>(function(){try{var t=JSON.parse(localStorage.getItem("theme"));if(t==="dark"||t==="light")document.documentElement.setAttribute("data-theme",t)}catch(e){}})()</script><!--/app-theme-->'
BACK='''<!--app--><a class="appback" href="../../index.html">‹ Biblioteca</a><div class="reader-tools" aria-label="Ferramentas de leitura"><div class="reader-actions"><button type="button" id="fontDown" aria-label="Diminuir texto">A−</button><button type="button" id="fontUp" aria-label="Aumentar texto">A+</button><button type="button" id="openAll">Abrir tudo</button><button type="button" id="closeAll">Fechar tudo</button><button type="button" id="goTop" aria-label="Voltar ao topo">↑</button></div><div class="read-progress"><span id="readProgress"></span></div></div><style>.appback{display:inline-block;margin:10px 0 4px;color:var(--ac);text-decoration:none;font:700 .92rem sans-serif}.reader-tools{position:sticky;top:env(safe-area-inset-top,0px);z-index:8;background:var(--bg);padding:6px 0 9px}.reader-actions{display:flex;gap:6px;flex-wrap:wrap}.reader-actions button{border:1px solid var(--ln);background:var(--sf);color:var(--tx);border-radius:9px;padding:7px 10px;font:600 .78rem sans-serif}.read-progress{height:3px;background:var(--ln);border-radius:9px;margin-top:8px;overflow:hidden}.read-progress span{display:block;height:100%;width:0;background:var(--ac)}body{font-size:var(--reader-size,16px)}.bar{top:calc(env(safe-area-inset-top,0px) + var(--tools-h,0px))!important}html{scroll-padding-top:calc(var(--tools-h,0px) + 70px)!important}</style><script>(function(){var k='readerFontSize',v=16;try{v=Number(localStorage.getItem(k))||16}catch(e){}function toolsH(){var t=document.querySelector('.reader-tools');if(t)document.documentElement.style.setProperty('--tools-h',t.offsetHeight+'px')}function apply(){document.documentElement.style.setProperty('--reader-size',v+'px');try{localStorage.setItem(k,v)}catch(e){}toolsH()}apply();document.addEventListener('click',function(e){var id=e.target.id;if(id==='fontDown'){v=Math.max(13,v-1);apply()}if(id==='fontUp'){v=Math.min(22,v+1);apply()}if(id==='openAll'||id==='closeAll')document.querySelectorAll('details').forEach(function(d){d.open=id==='openAll'});if(id==='goTop')window.scrollTo({top:0,behavior:'smooth'})});function progress(){var max=document.documentElement.scrollHeight-window.innerHeight,p=max>0?window.scrollY/max*100:0,el=document.getElementById('readProgress');if(el)el.style.width=Math.min(100,p)+'%'}window.addEventListener('scroll',progress,{passive:true});window.addEventListener('resize',function(){toolsH();progress()});window.addEventListener('load',toolsH);progress()})()</script><!--/app-->'''
QS="<!--app-q--><script>(function(){var p=new URLSearchParams(location.search).get('q'),i=document.getElementById('q');if(p&&i){i.value=p;i.dispatchEvent(new Event('input'))}})()</script><!--/app-q-->"
def strip(h):
    h=re.sub(r'<!--app-theme-->.*?<!--/app-theme-->','',h,flags=re.S)
    h=re.sub(r'<!--app-->.*?(?:<!--/app-->|progress\(\)\}\)\(\)</script>)','',h,flags=re.S)
    h=re.sub(r'<!--app-q-->.*?(?:<!--/app-q-->|</script>)','',h,flags=re.S)
    return re.sub(r'<!--/app-->|<!--/app-q-->','',h)   # marcadores de fechamento que sobraram (evita acumular a cada build)

ARGS=set(sys.argv[1:]);erros=[];avisos=[]
def E(g,m): erros.append((g,m))
def W(g,m): avisos.append((g,m))
IMGEXT=('.jpg','.jpeg','.png','.webp','.gif','.svg','.avif');FONTES=('manual','caixa','varejo','estimativa')
NIVEIS=['Leve','Médio-leve','Médio','Médio-pesado','Pesado']
norm=lambda s:re.sub(r'[\u0300-\u036f]','',unicodedata.normalize('NFD',s or '')).lower()
def texto(h):
    h=re.sub(r'<(script|style)[^>]*>.*?</\1>','',h,flags=re.S)
    return re.sub(r'\s+',' ',_html.unescape(re.sub(r'<[^>]+>',' ',h)))
def tipo_real(p):
    try: h=open(p,'rb').read(12)
    except OSError: return None
    if h[:3]==b'\xff\xd8\xff': return 'jpg'
    if h[:8]==b'\x89PNG\r\n\x1a\n': return 'png'
    if h[:4]==b'RIFF' and h[8:12]==b'WEBP': return 'webp'
    if h[:6] in (b'GIF87a',b'GIF89a'): return 'gif'
    return None
def ler(p): return open(p,encoding='utf-8').read()

# ================= FASE 1: verificação (só leitura) =================
try: ANTES={g['id']:g for g in json.load(open(R+'/library.json',encoding='utf-8'))}
except Exception: ANTES={}
metas=[]
for pasta in sorted(glob.glob(R+'/manuais/*/')):
    gid=os.path.basename(pasta.rstrip('/\\'));mp=pasta+'meta.json'
    if not os.path.exists(mp): E(gid,'a pasta existe mas não tem meta.json (o jogo não entraria na biblioteca)');continue
    try: m=json.load(open(mp,encoding='utf-8'))
    except Exception as x: E(gid,'meta.json inválido: %s'%x);continue
    m['id']=gid;metas.append((pasta.rstrip('/\\'),m))
ids=[m['id'] for _,m in metas]
for gid in ANTES:
    if gid not in ids and '--permitir-remover' not in ARGS: E('geral','o jogo "%s" estava na biblioteca e sumiu (se foi proposital, use --permitir-remover)'%gid)
titulos=[m.get('titulo') for _,m in metas]
for t in set(titulos):
    if t and titulos.count(t)>1: E('geral','título repetido: "%s"'%t)
for need in ('index.html','manifest.webmanifest','icon-192.png','icon-512.png','icon-180.png','icon-maskable-512.png','offline.html','sw.js'):
    if not os.path.exists(os.path.join(R,need)): E('geral','arquivo obrigatório ausente: '+need)
sem_pdf=[]
for d,m in metas:
    g=m['id'];man=m.get('manuais') or []
    # ---- campos básicos ----
    for k in ('titulo','capa'):
        if not m.get(k): E(g,'falta "%s" no meta.json'%k)
    if not m.get('categorias'): E(g,'falta "categorias"')
    if not man: E(g,'"manuais" vazio')
    # ---- capa ----
    if m.get('capa'):
        cp=os.path.join(d,m['capa'])
        if not os.path.exists(cp): E(g,'a capa não existe: %s'%m['capa'])
        else:
            tr=tipo_real(cp)
            if tr is None and not cp.lower().endswith('.svg'): E(g,'a capa não é uma imagem válida (arquivo corrompido?): %s'%m['capa'])
            elif tr and cp.lower().endswith(('.jpg','.jpeg')) and tr!='jpg': W(g,'a capa %s é na verdade %s com extensão .jpg (funciona, mas é mais pesada; converta para JPEG)'%(m['capa'],tr.upper()))
            if os.path.getsize(cp)>600_000: W(g,'a capa pesa %.1f MB; use uma menor (até ~300 KB)'%(os.path.getsize(cp)/1e6))
    # ---- ficha padronizada (documentada no LEIA-ME.txt) ----
    for k in ('jogadoresMin','jogadoresMax','duracaoMin','duracaoMax','complexidadeNivel'):
        if not isinstance(m.get(k),int) or isinstance(m.get(k),bool): E(g,'campo obrigatório ausente ou inválido: %s'%k)
    if all(isinstance(m.get(k),int) for k in ('jogadoresMin','jogadoresMax','duracaoMin','duracaoMax','complexidadeNivel')):
        if m['jogadoresMin']>m['jogadoresMax'] or m['duracaoMin']>m['duracaoMax'] or not 1<=m['complexidadeNivel']<=5: E(g,'valores incoerentes (mínimo > máximo, ou complexidade fora de 1 a 5)')
        jx=m.get('jogadoresMaxExpansao')
        if jx is not None and (not isinstance(jx,int) or jx<=m['jogadoresMax']): E(g,'jogadoresMaxExpansao deve ser um número maior que jogadoresMax')
        if m.get('jogadoresTexto'):
            nums=[int(x) for x in re.findall(r'\d+',m['jogadoresTexto'])]
            if m['jogadoresMin'] not in nums or (jx or m['jogadoresMax']) not in nums: E(g,'jogadoresTexto ("%s") não bate com jogadoresMin/jogadoresMax'%m['jogadoresTexto'])
    if m.get('duracaoFonte') not in FONTES: E(g,'duracaoFonte deve ser um de %s (atual: %r)'%('/'.join(FONTES),m.get('duracaoFonte')))
    if not m.get('idade'): W(g,'sem "idade" no meta.json')
    else:
        if not isinstance(m['idade'],int): E(g,'idade deve ser um número')
        if m.get('idadeFonte') not in FONTES: E(g,'idadeFonte deve ser um de %s (atual: %r)'%('/'.join(FONTES),m.get('idadeFonte')))
    fr=m.get('fichaRapida') or {}
    for k in ('mecanicas','dicas','erros'):
        if not fr.get(k): E(g,'a ficha rápida está sem "%s" (fichaRapida.%s)'%(k,k))
    cur=m.get('curiosidades') or []
    if not cur: W(g,'sem curiosidades')
    for c in cur:
        if not(c.get('titulo') and c.get('texto')): E(g,'curiosidade sem título ou texto')
        if not c.get('fonte'): W(g,'curiosidade "%s" sem fonte'%c.get('titulo'))
        elif not re.match(r'https?://',c['fonte']): E(g,'fonte da curiosidade "%s" não é um link http(s)'%c.get('titulo'))
    # ---- manuais (HTML) ----
    textos={};referenciadas=set()
    for x in man:
        arq=x.get('arquivo')
        if not x.get('nome') or not arq: E(g,'manual sem "nome" ou "arquivo" no meta.json');continue
        p=os.path.join(d,arq);tag='%s/%s'%(g,arq)
        if not os.path.exists(p): E(g,'o manual "%s" não existe'%arq);continue
        h=ler(p);textos[arq]=norm(texto(h))
        if re.search(r'expans|1912|5-6',arq,re.I) and not x.get('expansao'): W(tag,'o nome do arquivo sugere expansão; se for, adicione "expansao": true ao manual no meta.json (a Meeple IA prioriza o jogo base)')
        if len(h)<2000: E(tag,'manual quase vazio (%d caracteres)'%len(h))
        if len(h)>700_000: W(tag,'manual muito grande (%.0f KB); considere dividir ou reduzir'%(len(h)/1024))
        if not re.search(r'<h1[ >]',h): E(tag,'sem título <h1>')
        topicos=re.findall(r'<details class="[^"]*\btopic\b[^"]*"',h)
        if not topicos: E(tag,'sem capítulos (details.topic): a busca global e o Assistente Meeple não indexariam este manual')
        elif 'class="topic-body"' not in h: E(tag,'capítulos sem topic-body: a busca global e o Assistente Meeple não leriam o texto')
        if len(re.findall(r'<details\b',h))!=len(re.findall(r'</details>',h)): E(tag,'tags <details> desbalanceadas (abre %d, fecha %d)'%(len(re.findall(r'<details\b',h)),len(re.findall(r'</details>',h))))
        ids_=re.findall(r'\sid="([^"]+)"',h);dup=sorted({i for i in ids_ if ids_.count(i)>1})
        if dup: E(tag,'ids repetidos: %s'%', '.join(dup[:5]))
        for im in re.findall(r'<img\b[^>]*>',h):
            if not re.search(r'(?<![\w-])alt="[^"]*"',im): W(tag,'imagem sem texto alternativo (alt): %s'%im[:70])
            if re.search(r'\bsrc=""',im): E(tag,'imagem com src vazio')
        for ref in sorted(set(re.findall(r'(?:src|href)="([^"]+)"',h))):
            if re.match(r'(https?:|mailto:|tel:|data:|#|javascript:)',ref): continue
            alvo=os.path.normpath(os.path.join(d,ref.split('#')[0].split('?')[0]))
            if not os.path.exists(alvo): E(tag,'arquivo referenciado não existe: %s'%ref)
            else:
                referenciadas.add(alvo)
                if alvo.lower().endswith(('.jpg','.jpeg','.png','.webp','.gif')) and tipo_real(alvo) is None: E(tag,'imagem ilegível ou corrompida: %s'%ref)
                elif alvo.lower().endswith(IMGEXT) and os.path.getsize(alvo)>2_500_000: W(tag,'imagem muito pesada (%.1f MB): %s'%(os.path.getsize(alvo)/1e6,ref))
    # ---- manuais na pasta que não estão listados no meta.json (não apareceriam no app) ----
    listados={x.get('arquivo') for x in man}
    for f in sorted(glob.glob(d+'/*.html')):
        if os.path.basename(f) not in listados: W(g,'o arquivo %s está na pasta mas não está em "manuais" no meta.json (não aparece no app nem no Assistente Meeple)'%os.path.basename(f))
    # ---- arquivos soltos (imagens que nenhum manual usa) ----
    usadas=referenciadas|{os.path.normpath(os.path.join(d,m['capa']))} if m.get('capa') else referenciadas
    orfas=[os.path.relpath(p,d) for p in glob.glob(d+'/**/*',recursive=True) if os.path.isfile(p) and p.lower().endswith(IMGEXT) and os.path.normpath(p) not in usadas]
    if orfas: W(g,'%d imagem(ns) que nenhum manual usa (pode apagar): %s%s'%(len(orfas),', '.join(sorted(orfas)[:3]),'…' if len(orfas)>3 else ''))
    if not os.path.exists(os.path.join(d,'manual-original.pdf')): sem_pdf.append(g)
    # ---- consulta rápida ----
    ms=m.get('mesa')
    if not ms or not ms.get('secoes'): W(g,'sem conteúdo de consulta rápida (seções em "mesa" no meta.json)')
    else:
        for s in ms['secoes']:
            t=s.get('tipo');nome=s.get('titulo') or '?'
            if t not in('passos','lista','texto','tabela'): E(g,'consulta rápida: tipo inválido na seção "%s"'%nome)
            elif t=='tabela':
                if not s.get('cabecalho') or not s.get('linhas') or any(len(r)!=len(s['cabecalho']) for r in s['linhas']): E(g,'consulta rápida: tabela "%s" com colunas inconsistentes'%nome)
            elif not s.get('itens'): E(g,'consulta rápida: a seção "%s" está sem itens'%nome)
            arq=s.get('manual') or (man[0].get('arquivo') if man else None)
            if arq and arq not in textos and s.get('manual'): E(g,'consulta rápida: a seção "%s" aponta para o manual "%s", que não existe'%(nome,arq))
            elif s.get('busca') and arq in textos and norm(s['busca']) not in textos[arq]: W(g,'consulta rápida: o link "Ver no manual" da seção "%s" busca "%s", que não aparece em %s'%(nome,s['busca'],arq))
if sem_pdf: W('geral','%d jogo(s) sem manual-original.pdf (opcional): %s'%(len(sem_pdf),', '.join(sem_pdf)))
if '--sem-teste' not in ARGS:
    for g,m in avisos: print('AVISO [%s] %s'%(g,m))
    if erros:
        print()
        for g,m in erros: print('ERRO  [%s] %s'%(g,m))
        print('\n%d erro(s) e %d aviso(s). NADA foi alterado. Corrija e rode novamente.'%(len(erros),len(avisos)));sys.exit(1)
    if '--verificar' in ARGS:
        print('\nVerificação OK: %d jogo(s), 0 erros, %d aviso(s). Nada foi alterado.'%(len(metas),len(avisos)));sys.exit(0)

# ================= FASE 2: geração =================
lib=[]
for d,m in metas:
    m['jogadores']=m.get('jogadoresTexto') or (('%d a %d jogadores'%(m['jogadoresMin'],m['jogadoresMax'])) if m['jogadoresMin']!=m['jogadoresMax'] else '%d jogadores'%m['jogadoresMin'])
    m.setdefault('fichaRapida',{})['duracao']=('%d min'%m['duracaoMin']) if m['duracaoMin']==m['duracaoMax'] else '%d–%d min'%(m['duracaoMin'],m['duracaoMax'])
    m['fichaRapida']['complexidade']=NIVEIS[m['complexidadeNivel']-1]
    pdf=os.path.join(d,'manual-original.pdf')
    if os.path.exists(pdf): m['pdfOriginal']={'arquivo':'manual-original.pdf','nome':'Manual original em PDF','tamanho':'%.1f MB'%(os.path.getsize(pdf)/1e6)}
    else: m.pop('pdfOriginal',None)
    lib.append(m)
CORE=['./','index.html','library.json','manifest.webmanifest','icon-192.png','icon-512.png','icon-180.png','icon-maskable-512.png','offline.html'];JOGOS={}
for g in lib:
    base='manuais/'+g['id']+'/';nuc=[base+g['capa']]+[base+x['arquivo'] for x in g['manuais']];ass=[]
    for p in sorted(glob.glob(R+'/'+base+'**/*',recursive=True)):
        r=os.path.relpath(p,R).replace(os.sep,'/')
        if not os.path.isfile(p) or p.endswith(('meta.json','.pdf')) or r in nuc: continue
        (ass if r.lower().endswith(IMGEXT) else nuc).append(r)   # só imagens ficam sob demanda; css/js/fontes vão no cache inicial
    g['arquivos']=ass;g['tamanhoOfflineKB']=round(sum(os.path.getsize(R+'/'+a) for a in ass)/1024)
    CORE+=nuc;JOGOS[g['id']]=ass
# ---- conferência contra a versão anterior (evita perder dados em silêncio) ----
if '--permitir-remover' not in ARGS and '--sem-teste' not in ARGS:
    for g in lib:
        antes=ANTES.get(g['id'])
        if antes:
            sumiu=[k for k in antes if k not in g and k not in('pdfOriginal',)]
            if sumiu: print('ERRO  [%s] estes campos existiam no library.json anterior e sumiram: %s. Coloque-os no meta.json (ou use --permitir-remover).'%(g['id'],', '.join(sumiu)));print('\nNADA foi alterado.');sys.exit(1)
# ---- gravação ----
for d,m in metas:
    for x in m['manuais']:
        p=os.path.join(d,x['arquivo']);h=strip(ler(p))
        h=re.sub(r'(<head[^>]*>)',lambda k:k.group(1)+THEME,h,count=1)
        h=re.sub(r'(<body[^>]*>)',lambda k:k.group(1)+BACK,h,count=1)
        h=h.replace('</body>',QS+'</body>',1)
        open(p,'w',encoding='utf-8').write(h)
print('\nFicha padronizada (confira antes de publicar):')
print('  %-27s %-38s %-26s %-22s %s'%('jogo','jogadores','duração (fonte)','idade (fonte)','complexidade'))
for g in lib: print('  %-27s %-38s %-26s %-22s %s'%(g['id'],g['jogadores'][:38],g['fichaRapida']['duracao']+' ('+g['duracaoFonte']+')',(str(g['idade'])+'+ ('+g['idadeFonte']+')') if g.get('idade') else '—',g['fichaRapida']['complexidade']))
json.dump(lib,open(R+'/library.json','w',encoding='utf-8'),ensure_ascii=False,indent=1)
json.dump({'core':CORE,'games':JOGOS},open(R+'/files.json','w'))
def md5(lst):
    h=hashlib.md5()
    for f in sorted(set(lst)):
        q=os.path.join(R,f)
        if os.path.isfile(q): h.update(f.encode());h.update(open(q,'rb').read())
    return h.hexdigest()[:10]
sw=open(R+'/sw.js').read()
sw=re.sub(r"var BUILD='[^']*'","var BUILD='"+md5(CORE)+"'",sw,count=1)
sw=re.sub(r"var IMG='[^']*'","var IMG='"+md5([a for v in JOGOS.values() for a in v])+"'",sw,count=1)
open(R+'/sw.js','w').write(sw)
# ---- conferência final do que foi gerado ----
falt=[f for f in CORE+[a for v in JOGOS.values() for a in v] if f!='./' and not os.path.exists(os.path.join(R,f))]
if falt or len(json.load(open(R+'/library.json',encoding='utf-8')))!=len(metas):
    print('ERRO  geração inconsistente: %s'%(falt[:5] or 'library.json com número errado de jogos'));sys.exit(2)
nuc=sum(os.path.getsize(R+'/'+f) for f in CORE if os.path.isfile(R+'/'+f))/1e6;sob=sum(g['tamanhoOfflineKB'] for g in lib)/1024
print('Cache inicial (leve): %d arquivos, %.1f MB · Imagens sob demanda: %d arquivos, %.1f MB'%(len(CORE),nuc,sum(len(v) for v in JOGOS.values()),sob))
print('%d jogo(s). %d aviso(s). Pronto.'%(len(lib),len(avisos)))
